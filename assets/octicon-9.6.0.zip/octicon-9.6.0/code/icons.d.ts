/* THIS FILE IS GENERATED. DO NOT EDIT IT. */
import {CreateElement, VNode} from 'vue';
import {Icon} from '@tomoeed/j-icon';

declare const Alert: Icon<[0, 0, 16, 16], 16, 16>;
declare const Archive: Icon<[0, 0, 14, 16], 14, 16>;
declare const ArrowBoth: Icon<[0, 0, 20, 16], 20, 16>;
declare const ArrowDown: Icon<[0, 0, 10, 16], 10, 16>;
declare const ArrowLeft: Icon<[0, 0, 10, 16], 10, 16>;
declare const ArrowRight: Icon<[0, 0, 10, 16], 10, 16>;
declare const ArrowSmallDown: Icon<[0, 0, 6, 16], 6, 16>;
declare const ArrowSmallLeft: Icon<[0, 0, 6, 16], 6, 16>;
declare const ArrowSmallRight: Icon<[0, 0, 6, 16], 6, 16>;
declare const ArrowSmallUp: Icon<[0, 0, 6, 16], 6, 16>;
declare const ArrowUp: Icon<[0, 0, 10, 16], 10, 16>;
declare const Beaker: Icon<[0, 0, 16, 16], 16, 16>;
declare const Bell: Icon<[0, 0, 15, 16], 15, 16>;
declare const Bold: Icon<[0, 0, 10, 16], 10, 16>;
declare const Book: Icon<[0, 0, 16, 16], 16, 16>;
declare const Bookmark: Icon<[0, 0, 10, 16], 10, 16>;
declare const Briefcase: Icon<[0, 0, 14, 16], 14, 16>;
declare const Broadcast: Icon<[0, 0, 16, 16], 16, 16>;
declare const Browser: Icon<[0, 0, 14, 16], 14, 16>;
declare const Bug: Icon<[0, 0, 16, 16], 16, 16>;
declare const Calendar: Icon<[0, 0, 14, 16], 14, 16>;
declare const Check: Icon<[0, 0, 12, 16], 12, 16>;
declare const Checklist: Icon<[0, 0, 16, 16], 16, 16>;
declare const ChevronDown: Icon<[0, 0, 10, 16], 10, 16>;
declare const ChevronLeft: Icon<[0, 0, 8, 16], 8, 16>;
declare const ChevronRight: Icon<[0, 0, 8, 16], 8, 16>;
declare const ChevronUp: Icon<[0, 0, 10, 16], 10, 16>;
declare const CircleSlash: Icon<[0, 0, 14, 16], 14, 16>;
declare const CircuitBoard: Icon<[0, 0, 14, 16], 14, 16>;
declare const Clippy: Icon<[0, 0, 14, 16], 14, 16>;
declare const Clock: Icon<[0, 0, 14, 16], 14, 16>;
declare const CloudDownload: Icon<[0, 0, 16, 16], 16, 16>;
declare const CloudUpload: Icon<[0, 0, 16, 16], 16, 16>;
declare const Code: Icon<[0, 0, 14, 16], 14, 16>;
declare const CommentDiscussion: Icon<[0, 0, 16, 16], 16, 16>;
declare const Comment: Icon<[0, 0, 16, 16], 16, 16>;
declare const CreditCard: Icon<[0, 0, 16, 16], 16, 16>;
declare const Dash: Icon<[0, 0, 8, 16], 8, 16>;
declare const Dashboard: Icon<[0, 0, 16, 16], 16, 16>;
declare const Database: Icon<[0, 0, 12, 16], 12, 16>;
declare const Dependent: Icon<[0, 0, 16, 16], 16, 16>;
declare const DesktopDownload: Icon<[0, 0, 16, 16], 16, 16>;
declare const DeviceCameraVideo: Icon<[0, 0, 16, 16], 16, 16>;
declare const DeviceCamera: Icon<[0, 0, 16, 16], 16, 16>;
declare const DeviceDesktop: Icon<[0, 0, 16, 16], 16, 16>;
declare const DeviceMobile: Icon<[0, 0, 10, 16], 10, 16>;
declare const DiffAdded: Icon<[0, 0, 14, 16], 14, 16>;
declare const DiffIgnored: Icon<[0, 0, 14, 16], 14, 16>;
declare const DiffModified: Icon<[0, 0, 14, 16], 14, 16>;
declare const DiffRemoved: Icon<[0, 0, 14, 16], 14, 16>;
declare const DiffRenamed: Icon<[0, 0, 14, 16], 14, 16>;
declare const Diff: Icon<[0, 0, 13, 16], 13, 16>;
declare const Ellipsis: Icon<[0, 0, 12, 16], 12, 16>;
declare const EyeClosed: Icon<[0, 0, 16, 14], 16, 14>;
declare const Eye: Icon<[0, 0, 16, 16], 16, 16>;
declare const FileBinary: Icon<[0, 0, 12, 16], 12, 16>;
declare const FileCode: Icon<[0, 0, 12, 16], 12, 16>;
declare const FileDirectory: Icon<[0, 0, 14, 16], 14, 16>;
declare const FileMedia: Icon<[0, 0, 12, 16], 12, 16>;
declare const FilePdf: Icon<[0, 0, 12, 16], 12, 16>;
declare const FileSubmodule: Icon<[0, 0, 14, 16], 14, 16>;
declare const FileSymlinkDirectory: Icon<[0, 0, 14, 16], 14, 16>;
declare const FileSymlinkFile: Icon<[0, 0, 12, 16], 12, 16>;
declare const FileZip: Icon<[0, 0, 12, 16], 12, 16>;
declare const File: Icon<[0, 0, 12, 16], 12, 16>;
declare const Flame: Icon<[0, 0, 12, 16], 12, 16>;
declare const FoldDown: Icon<[0, 0, 14, 16], 14, 16>;
declare const FoldUp: Icon<[0, 0, 14, 16], 14, 16>;
declare const Fold: Icon<[0, 0, 14, 16], 14, 16>;
declare const Gear: Icon<[0, 0, 14, 16], 14, 16>;
declare const Gift: Icon<[0, 0, 14, 16], 14, 16>;
declare const GistSecret: Icon<[0, 0, 14, 16], 14, 16>;
declare const Gist: Icon<[0, 0, 12, 16], 12, 16>;
declare const GitBranch: Icon<[0, 0, 10, 16], 10, 16>;
declare const GitCommit: Icon<[0, 0, 14, 16], 14, 16>;
declare const GitCompare: Icon<[0, 0, 14, 16], 14, 16>;
declare const GitMerge: Icon<[0, 0, 12, 16], 12, 16>;
declare const GitPullRequest: Icon<[0, 0, 12, 16], 12, 16>;
declare const GithubAction: Icon<[0, 0, 16, 16], 16, 16>;
declare const Globe: Icon<[0, 0, 14, 16], 14, 16>;
declare const Grabber: Icon<[0, 0, 8, 16], 8, 16>;
declare const Graph: Icon<[0, 0, 16, 16], 16, 16>;
declare const HeartOutline: Icon<[0, 0, 12, 16], 12, 16>;
declare const Heart: Icon<[0, 0, 12, 16], 12, 16>;
declare const History: Icon<[0, 0, 14, 16], 14, 16>;
declare const Home: Icon<[0, 0, 16, 16], 16, 16>;
declare const HorizontalRule: Icon<[0, 0, 10, 16], 10, 16>;
declare const Hubot: Icon<[0, 0, 14, 16], 14, 16>;
declare const Inbox: Icon<[0, 0, 14, 16], 14, 16>;
declare const Infinity: Icon<[0, 0, 16, 16], 16, 16>;
declare const Info: Icon<[0, 0, 14, 16], 14, 16>;
declare const InternalRepo: Icon<[0, 0, 13, 16], 13, 16>;
declare const IssueClosed: Icon<[0, 0, 16, 16], 16, 16>;
declare const IssueOpened: Icon<[0, 0, 14, 16], 14, 16>;
declare const IssueReopened: Icon<[0, 0, 14, 16], 14, 16>;
declare const Italic: Icon<[0, 0, 6, 16], 6, 16>;
declare const Jersey: Icon<[0, 0, 14, 16], 14, 16>;
declare const KebabHorizontal: Icon<[0, 0, 13, 16], 13, 16>;
declare const KebabVertical: Icon<[0, 0, 3, 16], 3, 16>;
declare const Key: Icon<[0, 0, 14, 16], 14, 16>;
declare const Keyboard: Icon<[0, 0, 16, 16], 16, 16>;
declare const Law: Icon<[0, 0, 14, 16], 14, 16>;
declare const LightBulb: Icon<[0, 0, 12, 16], 12, 16>;
declare const LineArrowDown: Icon<[0, 0, 16, 16], 16, 16>;
declare const LineArrowLeft: Icon<[0, 0, 16, 16], 16, 16>;
declare const LineArrowRight: Icon<[0, 0, 16, 16], 16, 16>;
declare const LineArrowUp: Icon<[0, 0, 16, 16], 16, 16>;
declare const LinkExternal: Icon<[0, 0, 12, 16], 12, 16>;
declare const Link: Icon<[0, 0, 16, 16], 16, 16>;
declare const ListOrdered: Icon<[0, 0, 13, 16], 13, 16>;
declare const ListUnordered: Icon<[0, 0, 12, 16], 12, 16>;
declare const Location: Icon<[0, 0, 12, 16], 12, 16>;
declare const Lock: Icon<[0, 0, 12, 16], 12, 16>;
declare const LogoGist: Icon<[0, 0, 25, 16], 25, 16>;
declare const LogoGithub: Icon<[0, 0, 45, 16], 45, 16>;
declare const MailRead: Icon<[0, 0, 14, 16], 14, 16>;
declare const Mail: Icon<[0, 0, 14, 16], 14, 16>;
declare const MarkGithub: Icon<[0, 0, 16, 16], 16, 16>;
declare const Markdown: Icon<[0, 0, 16, 16], 16, 16>;
declare const Megaphone: Icon<[0, 0, 16, 16], 16, 16>;
declare const Mention: Icon<[0, 0, 14, 16], 14, 16>;
declare const Milestone: Icon<[0, 0, 14, 16], 14, 16>;
declare const Mirror: Icon<[0, 0, 16, 16], 16, 16>;
declare const MortarBoard: Icon<[0, 0, 16, 16], 16, 16>;
declare const Mute: Icon<[0, 0, 16, 16], 16, 16>;
declare const NoNewline: Icon<[0, 0, 16, 16], 16, 16>;
declare const Note: Icon<[0, 0, 14, 16], 14, 16>;
declare const Octoface: Icon<[0, 0, 16, 16], 16, 16>;
declare const Organization: Icon<[0, 0, 16, 16], 16, 16>;
declare const Package: Icon<[0, 0, 16, 16], 16, 16>;
declare const Paintcan: Icon<[0, 0, 12, 16], 12, 16>;
declare const Pencil: Icon<[0, 0, 14, 16], 14, 16>;
declare const Person: Icon<[0, 0, 12, 16], 12, 16>;
declare const Pin: Icon<[0, 0, 16, 16], 16, 16>;
declare const Play: Icon<[0, 0, 14, 16], 14, 16>;
declare const Plug: Icon<[0, 0, 14, 16], 14, 16>;
declare const PlusSmall: Icon<[0, 0, 7, 16], 7, 16>;
declare const Plus: Icon<[0, 0, 12, 16], 12, 16>;
declare const PrimitiveDotStroke: Icon<[0, 0, 8, 16], 8, 16>;
declare const PrimitiveDot: Icon<[0, 0, 8, 16], 8, 16>;
declare const PrimitiveSquare: Icon<[0, 0, 8, 16], 8, 16>;
declare const Project: Icon<[0, 0, 15, 16], 15, 16>;
declare const Pulse: Icon<[0, 0, 14, 16], 14, 16>;
declare const Question: Icon<[0, 0, 14, 16], 14, 16>;
declare const Quote: Icon<[0, 0, 14, 16], 14, 16>;
declare const RadioTower: Icon<[0, 0, 16, 16], 16, 16>;
declare const Reply: Icon<[0, 0, 14, 16], 14, 16>;
declare const RepoClone: Icon<[0, 0, 16, 16], 16, 16>;
declare const RepoForcePush: Icon<[0, 0, 12, 16], 12, 16>;
declare const RepoForked: Icon<[0, 0, 10, 16], 10, 16>;
declare const RepoPull: Icon<[0, 0, 16, 16], 16, 16>;
declare const RepoPush: Icon<[0, 0, 12, 16], 12, 16>;
declare const RepoTemplatePrivate: Icon<[0, 0, 14, 16], 14, 16>;
declare const RepoTemplate: Icon<[0, 0, 14, 16], 14, 16>;
declare const Repo: Icon<[0, 0, 12, 16], 12, 16>;
declare const Report: Icon<[0, 0, 16, 16], 16, 16>;
declare const RequestChanges: Icon<[0, 0, 16, 16], 16, 16>;
declare const Rocket: Icon<[0, 0, 16, 16], 16, 16>;
declare const Rss: Icon<[0, 0, 10, 16], 10, 16>;
declare const Ruby: Icon<[0, 0, 16, 16], 16, 16>;
declare const Saved: Icon<[0, 0, 16, 16], 16, 16>;
declare const ScreenFull: Icon<[0, 0, 14, 16], 14, 16>;
declare const ScreenNormal: Icon<[0, 0, 14, 16], 14, 16>;
declare const Search: Icon<[0, 0, 16, 16], 16, 16>;
declare const Server: Icon<[0, 0, 12, 16], 12, 16>;
declare const Settings: Icon<[0, 0, 16, 16], 16, 16>;
declare const ShieldCheck: Icon<[0, 0, 16, 16], 16, 16>;
declare const ShieldLock: Icon<[0, 0, 14, 16], 14, 16>;
declare const ShieldX: Icon<[0, 0, 16, 16], 16, 16>;
declare const Shield: Icon<[0, 0, 14, 16], 14, 16>;
declare const SignIn: Icon<[0, 0, 14, 16], 14, 16>;
declare const SignOut: Icon<[0, 0, 16, 17], 16, 17>;
declare const Skip: Icon<[0, 0, 16, 16], 16, 16>;
declare const Smiley: Icon<[0, 0, 16, 16], 16, 16>;
declare const Squirrel: Icon<[0, 0, 16, 16], 16, 16>;
declare const Star: Icon<[0, 0, 14, 16], 14, 16>;
declare const Stop: Icon<[0, 0, 14, 16], 14, 16>;
declare const Sync: Icon<[0, 0, 12, 16], 12, 16>;
declare const Tag: Icon<[0, 0, 15, 16], 15, 16>;
declare const Tasklist: Icon<[0, 0, 16, 16], 16, 16>;
declare const Telescope: Icon<[0, 0, 14, 16], 14, 16>;
declare const Terminal: Icon<[0, 0, 14, 16], 14, 16>;
declare const TextSize: Icon<[0, 0, 18, 16], 18, 16>;
declare const ThreeBars: Icon<[0, 0, 12, 16], 12, 16>;
declare const Thumbsdown: Icon<[0, 0, 16, 16], 16, 16>;
declare const Thumbsup: Icon<[0, 0, 16, 16], 16, 16>;
declare const Tools: Icon<[0, 0, 16, 16], 16, 16>;
declare const Trashcan: Icon<[0, 0, 12, 16], 12, 16>;
declare const TriangleDown: Icon<[0, 0, 12, 16], 12, 16>;
declare const TriangleLeft: Icon<[0, 0, 6, 16], 6, 16>;
declare const TriangleRight: Icon<[0, 0, 6, 16], 6, 16>;
declare const TriangleUp: Icon<[0, 0, 12, 16], 12, 16>;
declare const Unfold: Icon<[0, 0, 14, 16], 14, 16>;
declare const Unmute: Icon<[0, 0, 16, 16], 16, 16>;
declare const Unsaved: Icon<[0, 0, 16, 16], 16, 16>;
declare const Unverified: Icon<[0, 0, 16, 16], 16, 16>;
declare const Verified: Icon<[0, 0, 16, 16], 16, 16>;
declare const Versions: Icon<[0, 0, 14, 16], 14, 16>;
declare const Watch: Icon<[0, 0, 12, 16], 12, 16>;
declare const WorkflowAll: Icon<[0, 0, 16, 16], 16, 16>;
declare const Workflow: Icon<[0, 0, 16, 16], 16, 16>;
declare const X: Icon<[0, 0, 12, 16], 12, 16>;
declare const Zap: Icon<[0, 0, 10, 16], 10, 16>;

type Icons = {
    'alert': Icon<[0, 0, 16, 16], 16, 16>,
    'archive': Icon<[0, 0, 14, 16], 14, 16>,
    'arrow-both': Icon<[0, 0, 20, 16], 20, 16>,
    'arrow-down': Icon<[0, 0, 10, 16], 10, 16>,
    'arrow-left': Icon<[0, 0, 10, 16], 10, 16>,
    'arrow-right': Icon<[0, 0, 10, 16], 10, 16>,
    'arrow-small-down': Icon<[0, 0, 6, 16], 6, 16>,
    'arrow-small-left': Icon<[0, 0, 6, 16], 6, 16>,
    'arrow-small-right': Icon<[0, 0, 6, 16], 6, 16>,
    'arrow-small-up': Icon<[0, 0, 6, 16], 6, 16>,
    'arrow-up': Icon<[0, 0, 10, 16], 10, 16>,
    'beaker': Icon<[0, 0, 16, 16], 16, 16>,
    'bell': Icon<[0, 0, 15, 16], 15, 16>,
    'bold': Icon<[0, 0, 10, 16], 10, 16>,
    'book': Icon<[0, 0, 16, 16], 16, 16>,
    'bookmark': Icon<[0, 0, 10, 16], 10, 16>,
    'briefcase': Icon<[0, 0, 14, 16], 14, 16>,
    'broadcast': Icon<[0, 0, 16, 16], 16, 16>,
    'browser': Icon<[0, 0, 14, 16], 14, 16>,
    'bug': Icon<[0, 0, 16, 16], 16, 16>,
    'calendar': Icon<[0, 0, 14, 16], 14, 16>,
    'check': Icon<[0, 0, 12, 16], 12, 16>,
    'checklist': Icon<[0, 0, 16, 16], 16, 16>,
    'chevron-down': Icon<[0, 0, 10, 16], 10, 16>,
    'chevron-left': Icon<[0, 0, 8, 16], 8, 16>,
    'chevron-right': Icon<[0, 0, 8, 16], 8, 16>,
    'chevron-up': Icon<[0, 0, 10, 16], 10, 16>,
    'circle-slash': Icon<[0, 0, 14, 16], 14, 16>,
    'circuit-board': Icon<[0, 0, 14, 16], 14, 16>,
    'clippy': Icon<[0, 0, 14, 16], 14, 16>,
    'clock': Icon<[0, 0, 14, 16], 14, 16>,
    'cloud-download': Icon<[0, 0, 16, 16], 16, 16>,
    'cloud-upload': Icon<[0, 0, 16, 16], 16, 16>,
    'code': Icon<[0, 0, 14, 16], 14, 16>,
    'comment-discussion': Icon<[0, 0, 16, 16], 16, 16>,
    'comment': Icon<[0, 0, 16, 16], 16, 16>,
    'credit-card': Icon<[0, 0, 16, 16], 16, 16>,
    'dash': Icon<[0, 0, 8, 16], 8, 16>,
    'dashboard': Icon<[0, 0, 16, 16], 16, 16>,
    'database': Icon<[0, 0, 12, 16], 12, 16>,
    'dependent': Icon<[0, 0, 16, 16], 16, 16>,
    'desktop-download': Icon<[0, 0, 16, 16], 16, 16>,
    'device-camera-video': Icon<[0, 0, 16, 16], 16, 16>,
    'device-camera': Icon<[0, 0, 16, 16], 16, 16>,
    'device-desktop': Icon<[0, 0, 16, 16], 16, 16>,
    'device-mobile': Icon<[0, 0, 10, 16], 10, 16>,
    'diff-added': Icon<[0, 0, 14, 16], 14, 16>,
    'diff-ignored': Icon<[0, 0, 14, 16], 14, 16>,
    'diff-modified': Icon<[0, 0, 14, 16], 14, 16>,
    'diff-removed': Icon<[0, 0, 14, 16], 14, 16>,
    'diff-renamed': Icon<[0, 0, 14, 16], 14, 16>,
    'diff': Icon<[0, 0, 13, 16], 13, 16>,
    'ellipsis': Icon<[0, 0, 12, 16], 12, 16>,
    'eye-closed': Icon<[0, 0, 16, 14], 16, 14>,
    'eye': Icon<[0, 0, 16, 16], 16, 16>,
    'file-binary': Icon<[0, 0, 12, 16], 12, 16>,
    'file-code': Icon<[0, 0, 12, 16], 12, 16>,
    'file-directory': Icon<[0, 0, 14, 16], 14, 16>,
    'file-media': Icon<[0, 0, 12, 16], 12, 16>,
    'file-pdf': Icon<[0, 0, 12, 16], 12, 16>,
    'file-submodule': Icon<[0, 0, 14, 16], 14, 16>,
    'file-symlink-directory': Icon<[0, 0, 14, 16], 14, 16>,
    'file-symlink-file': Icon<[0, 0, 12, 16], 12, 16>,
    'file-zip': Icon<[0, 0, 12, 16], 12, 16>,
    'file': Icon<[0, 0, 12, 16], 12, 16>,
    'flame': Icon<[0, 0, 12, 16], 12, 16>,
    'fold-down': Icon<[0, 0, 14, 16], 14, 16>,
    'fold-up': Icon<[0, 0, 14, 16], 14, 16>,
    'fold': Icon<[0, 0, 14, 16], 14, 16>,
    'gear': Icon<[0, 0, 14, 16], 14, 16>,
    'gift': Icon<[0, 0, 14, 16], 14, 16>,
    'gist-secret': Icon<[0, 0, 14, 16], 14, 16>,
    'gist': Icon<[0, 0, 12, 16], 12, 16>,
    'git-branch': Icon<[0, 0, 10, 16], 10, 16>,
    'git-commit': Icon<[0, 0, 14, 16], 14, 16>,
    'git-compare': Icon<[0, 0, 14, 16], 14, 16>,
    'git-merge': Icon<[0, 0, 12, 16], 12, 16>,
    'git-pull-request': Icon<[0, 0, 12, 16], 12, 16>,
    'github-action': Icon<[0, 0, 16, 16], 16, 16>,
    'globe': Icon<[0, 0, 14, 16], 14, 16>,
    'grabber': Icon<[0, 0, 8, 16], 8, 16>,
    'graph': Icon<[0, 0, 16, 16], 16, 16>,
    'heart-outline': Icon<[0, 0, 12, 16], 12, 16>,
    'heart': Icon<[0, 0, 12, 16], 12, 16>,
    'history': Icon<[0, 0, 14, 16], 14, 16>,
    'home': Icon<[0, 0, 16, 16], 16, 16>,
    'horizontal-rule': Icon<[0, 0, 10, 16], 10, 16>,
    'hubot': Icon<[0, 0, 14, 16], 14, 16>,
    'inbox': Icon<[0, 0, 14, 16], 14, 16>,
    'infinity': Icon<[0, 0, 16, 16], 16, 16>,
    'info': Icon<[0, 0, 14, 16], 14, 16>,
    'internal-repo': Icon<[0, 0, 13, 16], 13, 16>,
    'issue-closed': Icon<[0, 0, 16, 16], 16, 16>,
    'issue-opened': Icon<[0, 0, 14, 16], 14, 16>,
    'issue-reopened': Icon<[0, 0, 14, 16], 14, 16>,
    'italic': Icon<[0, 0, 6, 16], 6, 16>,
    'jersey': Icon<[0, 0, 14, 16], 14, 16>,
    'kebab-horizontal': Icon<[0, 0, 13, 16], 13, 16>,
    'kebab-vertical': Icon<[0, 0, 3, 16], 3, 16>,
    'key': Icon<[0, 0, 14, 16], 14, 16>,
    'keyboard': Icon<[0, 0, 16, 16], 16, 16>,
    'law': Icon<[0, 0, 14, 16], 14, 16>,
    'light-bulb': Icon<[0, 0, 12, 16], 12, 16>,
    'line-arrow-down': Icon<[0, 0, 16, 16], 16, 16>,
    'line-arrow-left': Icon<[0, 0, 16, 16], 16, 16>,
    'line-arrow-right': Icon<[0, 0, 16, 16], 16, 16>,
    'line-arrow-up': Icon<[0, 0, 16, 16], 16, 16>,
    'link-external': Icon<[0, 0, 12, 16], 12, 16>,
    'link': Icon<[0, 0, 16, 16], 16, 16>,
    'list-ordered': Icon<[0, 0, 13, 16], 13, 16>,
    'list-unordered': Icon<[0, 0, 12, 16], 12, 16>,
    'location': Icon<[0, 0, 12, 16], 12, 16>,
    'lock': Icon<[0, 0, 12, 16], 12, 16>,
    'logo-gist': Icon<[0, 0, 25, 16], 25, 16>,
    'logo-github': Icon<[0, 0, 45, 16], 45, 16>,
    'mail-read': Icon<[0, 0, 14, 16], 14, 16>,
    'mail': Icon<[0, 0, 14, 16], 14, 16>,
    'mark-github': Icon<[0, 0, 16, 16], 16, 16>,
    'markdown': Icon<[0, 0, 16, 16], 16, 16>,
    'megaphone': Icon<[0, 0, 16, 16], 16, 16>,
    'mention': Icon<[0, 0, 14, 16], 14, 16>,
    'milestone': Icon<[0, 0, 14, 16], 14, 16>,
    'mirror': Icon<[0, 0, 16, 16], 16, 16>,
    'mortar-board': Icon<[0, 0, 16, 16], 16, 16>,
    'mute': Icon<[0, 0, 16, 16], 16, 16>,
    'no-newline': Icon<[0, 0, 16, 16], 16, 16>,
    'note': Icon<[0, 0, 14, 16], 14, 16>,
    'octoface': Icon<[0, 0, 16, 16], 16, 16>,
    'organization': Icon<[0, 0, 16, 16], 16, 16>,
    'package': Icon<[0, 0, 16, 16], 16, 16>,
    'paintcan': Icon<[0, 0, 12, 16], 12, 16>,
    'pencil': Icon<[0, 0, 14, 16], 14, 16>,
    'person': Icon<[0, 0, 12, 16], 12, 16>,
    'pin': Icon<[0, 0, 16, 16], 16, 16>,
    'play': Icon<[0, 0, 14, 16], 14, 16>,
    'plug': Icon<[0, 0, 14, 16], 14, 16>,
    'plus-small': Icon<[0, 0, 7, 16], 7, 16>,
    'plus': Icon<[0, 0, 12, 16], 12, 16>,
    'primitive-dot-stroke': Icon<[0, 0, 8, 16], 8, 16>,
    'primitive-dot': Icon<[0, 0, 8, 16], 8, 16>,
    'primitive-square': Icon<[0, 0, 8, 16], 8, 16>,
    'project': Icon<[0, 0, 15, 16], 15, 16>,
    'pulse': Icon<[0, 0, 14, 16], 14, 16>,
    'question': Icon<[0, 0, 14, 16], 14, 16>,
    'quote': Icon<[0, 0, 14, 16], 14, 16>,
    'radio-tower': Icon<[0, 0, 16, 16], 16, 16>,
    'reply': Icon<[0, 0, 14, 16], 14, 16>,
    'repo-clone': Icon<[0, 0, 16, 16], 16, 16>,
    'repo-force-push': Icon<[0, 0, 12, 16], 12, 16>,
    'repo-forked': Icon<[0, 0, 10, 16], 10, 16>,
    'repo-pull': Icon<[0, 0, 16, 16], 16, 16>,
    'repo-push': Icon<[0, 0, 12, 16], 12, 16>,
    'repo-template-private': Icon<[0, 0, 14, 16], 14, 16>,
    'repo-template': Icon<[0, 0, 14, 16], 14, 16>,
    'repo': Icon<[0, 0, 12, 16], 12, 16>,
    'report': Icon<[0, 0, 16, 16], 16, 16>,
    'request-changes': Icon<[0, 0, 16, 16], 16, 16>,
    'rocket': Icon<[0, 0, 16, 16], 16, 16>,
    'rss': Icon<[0, 0, 10, 16], 10, 16>,
    'ruby': Icon<[0, 0, 16, 16], 16, 16>,
    'saved': Icon<[0, 0, 16, 16], 16, 16>,
    'screen-full': Icon<[0, 0, 14, 16], 14, 16>,
    'screen-normal': Icon<[0, 0, 14, 16], 14, 16>,
    'search': Icon<[0, 0, 16, 16], 16, 16>,
    'server': Icon<[0, 0, 12, 16], 12, 16>,
    'settings': Icon<[0, 0, 16, 16], 16, 16>,
    'shield-check': Icon<[0, 0, 16, 16], 16, 16>,
    'shield-lock': Icon<[0, 0, 14, 16], 14, 16>,
    'shield-x': Icon<[0, 0, 16, 16], 16, 16>,
    'shield': Icon<[0, 0, 14, 16], 14, 16>,
    'sign-in': Icon<[0, 0, 14, 16], 14, 16>,
    'sign-out': Icon<[0, 0, 16, 17], 16, 17>,
    'skip': Icon<[0, 0, 16, 16], 16, 16>,
    'smiley': Icon<[0, 0, 16, 16], 16, 16>,
    'squirrel': Icon<[0, 0, 16, 16], 16, 16>,
    'star': Icon<[0, 0, 14, 16], 14, 16>,
    'stop': Icon<[0, 0, 14, 16], 14, 16>,
    'sync': Icon<[0, 0, 12, 16], 12, 16>,
    'tag': Icon<[0, 0, 15, 16], 15, 16>,
    'tasklist': Icon<[0, 0, 16, 16], 16, 16>,
    'telescope': Icon<[0, 0, 14, 16], 14, 16>,
    'terminal': Icon<[0, 0, 14, 16], 14, 16>,
    'text-size': Icon<[0, 0, 18, 16], 18, 16>,
    'three-bars': Icon<[0, 0, 12, 16], 12, 16>,
    'thumbsdown': Icon<[0, 0, 16, 16], 16, 16>,
    'thumbsup': Icon<[0, 0, 16, 16], 16, 16>,
    'tools': Icon<[0, 0, 16, 16], 16, 16>,
    'trashcan': Icon<[0, 0, 12, 16], 12, 16>,
    'triangle-down': Icon<[0, 0, 12, 16], 12, 16>,
    'triangle-left': Icon<[0, 0, 6, 16], 6, 16>,
    'triangle-right': Icon<[0, 0, 6, 16], 6, 16>,
    'triangle-up': Icon<[0, 0, 12, 16], 12, 16>,
    'unfold': Icon<[0, 0, 14, 16], 14, 16>,
    'unmute': Icon<[0, 0, 16, 16], 16, 16>,
    'unsaved': Icon<[0, 0, 16, 16], 16, 16>,
    'unverified': Icon<[0, 0, 16, 16], 16, 16>,
    'verified': Icon<[0, 0, 16, 16], 16, 16>,
    'versions': Icon<[0, 0, 14, 16], 14, 16>,
    'watch': Icon<[0, 0, 12, 16], 12, 16>,
    'workflow-all': Icon<[0, 0, 16, 16], 16, 16>,
    'workflow': Icon<[0, 0, 16, 16], 16, 16>,
    'x': Icon<[0, 0, 12, 16], 12, 16>,
    'zap': Icon<[0, 0, 10, 16], 10, 16>
};

declare const icons: Icons;

export default icons;
export {
    Alert,
    Archive,
    ArrowBoth,
    ArrowDown,
    ArrowLeft,
    ArrowRight,
    ArrowSmallDown,
    ArrowSmallLeft,
    ArrowSmallRight,
    ArrowSmallUp,
    ArrowUp,
    Beaker,
    Bell,
    Bold,
    Book,
    Bookmark,
    Briefcase,
    Broadcast,
    Browser,
    Bug,
    Calendar,
    Check,
    Checklist,
    ChevronDown,
    ChevronLeft,
    ChevronRight,
    ChevronUp,
    CircleSlash,
    CircuitBoard,
    Clippy,
    Clock,
    CloudDownload,
    CloudUpload,
    Code,
    CommentDiscussion,
    Comment,
    CreditCard,
    Dash,
    Dashboard,
    Database,
    Dependent,
    DesktopDownload,
    DeviceCameraVideo,
    DeviceCamera,
    DeviceDesktop,
    DeviceMobile,
    DiffAdded,
    DiffIgnored,
    DiffModified,
    DiffRemoved,
    DiffRenamed,
    Diff,
    Ellipsis,
    EyeClosed,
    Eye,
    FileBinary,
    FileCode,
    FileDirectory,
    FileMedia,
    FilePdf,
    FileSubmodule,
    FileSymlinkDirectory,
    FileSymlinkFile,
    FileZip,
    File,
    Flame,
    FoldDown,
    FoldUp,
    Fold,
    Gear,
    Gift,
    GistSecret,
    Gist,
    GitBranch,
    GitCommit,
    GitCompare,
    GitMerge,
    GitPullRequest,
    GithubAction,
    Globe,
    Grabber,
    Graph,
    HeartOutline,
    Heart,
    History,
    Home,
    HorizontalRule,
    Hubot,
    Inbox,
    Infinity,
    Info,
    InternalRepo,
    IssueClosed,
    IssueOpened,
    IssueReopened,
    Italic,
    Jersey,
    KebabHorizontal,
    KebabVertical,
    Key,
    Keyboard,
    Law,
    LightBulb,
    LineArrowDown,
    LineArrowLeft,
    LineArrowRight,
    LineArrowUp,
    LinkExternal,
    Link,
    ListOrdered,
    ListUnordered,
    Location,
    Lock,
    LogoGist,
    LogoGithub,
    MailRead,
    Mail,
    MarkGithub,
    Markdown,
    Megaphone,
    Mention,
    Milestone,
    Mirror,
    MortarBoard,
    Mute,
    NoNewline,
    Note,
    Octoface,
    Organization,
    Package,
    Paintcan,
    Pencil,
    Person,
    Pin,
    Play,
    Plug,
    PlusSmall,
    Plus,
    PrimitiveDotStroke,
    PrimitiveDot,
    PrimitiveSquare,
    Project,
    Pulse,
    Question,
    Quote,
    RadioTower,
    Reply,
    RepoClone,
    RepoForcePush,
    RepoForked,
    RepoPull,
    RepoPush,
    RepoTemplatePrivate,
    RepoTemplate,
    Repo,
    Report,
    RequestChanges,
    Rocket,
    Rss,
    Ruby,
    Saved,
    ScreenFull,
    ScreenNormal,
    Search,
    Server,
    Settings,
    ShieldCheck,
    ShieldLock,
    ShieldX,
    Shield,
    SignIn,
    SignOut,
    Skip,
    Smiley,
    Squirrel,
    Star,
    Stop,
    Sync,
    Tag,
    Tasklist,
    Telescope,
    Terminal,
    TextSize,
    ThreeBars,
    Thumbsdown,
    Thumbsup,
    Tools,
    Trashcan,
    TriangleDown,
    TriangleLeft,
    TriangleRight,
    TriangleUp,
    Unfold,
    Unmute,
    Unsaved,
    Unverified,
    Verified,
    Versions,
    Watch,
    WorkflowAll,
    Workflow,
    X,
    Zap
};
