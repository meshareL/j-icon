/* THIS FILE IS GENERATED. DO NOT EDIT IT. */
import {CreateElement, VNode} from 'vue';
import {Icon} from '@tomoeed/j-icon';

declare const AlarmFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Alarm: Icon<[0, 0, 20, 20], 20, 20>;
declare const AlertCircleFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const AlertCircle: Icon<[0, 0, 20, 20], 20, 20>;
declare const AlertOctagonFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const AlertOctagon: Icon<[0, 0, 20, 20], 20, 20>;
declare const AlertSquareFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const AlertSquare: Icon<[0, 0, 20, 20], 20, 20>;
declare const AlertTriangleFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const AlertTriangle: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArchiveFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Archive: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowBarBottom: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowBarLeft: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowBarRight: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowBarUp: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowClockwise: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowCounterclockwise: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowDownLeft: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowDownRight: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowDownShort: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowDown: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowLeftRight: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowLeftShort: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowLeft: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowRepeat: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowRightShort: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowRight: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowUpDown: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowUpLeft: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowUpRight: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowUpShort: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowUp: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowsAngleContract: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowsAngleExpand: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowsCollapse: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowsExpand: Icon<[0, 0, 20, 20], 20, 20>;
declare const ArrowsFullscreen: Icon<[0, 0, 20, 20], 20, 20>;
declare const At: Icon<[0, 0, 20, 20], 20, 20>;
declare const Award: Icon<[0, 0, 20, 20], 20, 20>;
declare const BackspaceFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const BackspaceReverseFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const BackspaceReverse: Icon<[0, 0, 20, 20], 20, 20>;
declare const Backspace: Icon<[0, 0, 20, 20], 20, 20>;
declare const BarChartFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const BarChart: Icon<[0, 0, 20, 20], 20, 20>;
declare const BatteryCharging: Icon<[0, 0, 20, 20], 20, 20>;
declare const BatteryFull: Icon<[0, 0, 20, 20], 20, 20>;
declare const Battery: Icon<[0, 0, 20, 20], 20, 20>;
declare const BellFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Bell: Icon<[0, 0, 20, 20], 20, 20>;
declare const BlockquoteLeft: Icon<[0, 0, 20, 20], 20, 20>;
declare const BlockquoteRight: Icon<[0, 0, 20, 20], 20, 20>;
declare const BookHalfFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Book: Icon<[0, 0, 20, 20], 20, 20>;
declare const BookmarkFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Bookmark: Icon<[0, 0, 20, 20], 20, 20>;
declare const BootstrapFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const BootstrapReboot: Icon<[0, 0, 20, 20], 20, 20>;
declare const Bootstrap: Icon<[0, 0, 20, 20], 20, 20>;
declare const BoxArrowBottomLeft: Icon<[0, 0, 20, 20], 20, 20>;
declare const BoxArrowBottomRight: Icon<[0, 0, 20, 20], 20, 20>;
declare const BoxArrowDown: Icon<[0, 0, 20, 20], 20, 20>;
declare const BoxArrowLeft: Icon<[0, 0, 20, 20], 20, 20>;
declare const BoxArrowRight: Icon<[0, 0, 20, 20], 20, 20>;
declare const BoxArrowUpLeft: Icon<[0, 0, 20, 20], 20, 20>;
declare const BoxArrowUpRight: Icon<[0, 0, 20, 20], 20, 20>;
declare const BoxArrowUp: Icon<[0, 0, 20, 20], 20, 20>;
declare const Braces: Icon<[0, 0, 20, 20], 20, 20>;
declare const BrightnessFillHigh: Icon<[0, 0, 20, 20], 20, 20>;
declare const BrightnessFillLow: Icon<[0, 0, 20, 20], 20, 20>;
declare const BrightnessHigh: Icon<[0, 0, 20, 20], 20, 20>;
declare const BrightnessLow: Icon<[0, 0, 20, 20], 20, 20>;
declare const Brush: Icon<[0, 0, 20, 20], 20, 20>;
declare const BucketFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Bucket: Icon<[0, 0, 20, 20], 20, 20>;
declare const Building: Icon<[0, 0, 20, 20], 20, 20>;
declare const Bullseye: Icon<[0, 0, 20, 20], 20, 20>;
declare const CalendarFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Calendar: Icon<[0, 0, 20, 20], 20, 20>;
declare const CameraVideoFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const CameraVideo: Icon<[0, 0, 20, 20], 20, 20>;
declare const Camera: Icon<[0, 0, 20, 20], 20, 20>;
declare const CapslockFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Capslock: Icon<[0, 0, 20, 20], 20, 20>;
declare const ChatFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Chat: Icon<[0, 0, 20, 20], 20, 20>;
declare const CheckBox: Icon<[0, 0, 20, 20], 20, 20>;
declare const CheckCircle: Icon<[0, 0, 20, 20], 20, 20>;
declare const Check: Icon<[0, 0, 20, 20], 20, 20>;
declare const ChevronCompactDown: Icon<[0, 0, 20, 20], 20, 20>;
declare const ChevronCompactLeft: Icon<[0, 0, 20, 20], 20, 20>;
declare const ChevronCompactRight: Icon<[0, 0, 20, 20], 20, 20>;
declare const ChevronCompactUp: Icon<[0, 0, 20, 20], 20, 20>;
declare const ChevronDown: Icon<[0, 0, 20, 20], 20, 20>;
declare const ChevronLeft: Icon<[0, 0, 20, 20], 20, 20>;
declare const ChevronRight: Icon<[0, 0, 20, 20], 20, 20>;
declare const ChevronUp: Icon<[0, 0, 20, 20], 20, 20>;
declare const CircleFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const CircleHalf: Icon<[0, 0, 20, 20], 20, 20>;
declare const CircleSlash: Icon<[0, 0, 20, 20], 20, 20>;
declare const Circle: Icon<[0, 0, 20, 20], 20, 20>;
declare const ClockFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Clock: Icon<[0, 0, 20, 20], 20, 20>;
declare const CloudDownload: Icon<[0, 0, 20, 20], 20, 20>;
declare const CloudFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const CloudUpload: Icon<[0, 0, 20, 20], 20, 20>;
declare const Cloud: Icon<[0, 0, 20, 20], 20, 20>;
declare const CodeSlash: Icon<[0, 0, 20, 20], 20, 20>;
declare const Code: Icon<[0, 0, 20, 20], 20, 20>;
declare const ColumnsGutters: Icon<[0, 0, 20, 20], 20, 20>;
declare const Columns: Icon<[0, 0, 20, 20], 20, 20>;
declare const Command: Icon<[0, 0, 20, 20], 20, 20>;
declare const Compass: Icon<[0, 0, 20, 20], 20, 20>;
declare const ConeStriped: Icon<[0, 0, 20, 20], 20, 20>;
declare const Cone: Icon<[0, 0, 20, 20], 20, 20>;
declare const Controller: Icon<[0, 0, 20, 20], 20, 20>;
declare const CreditCard: Icon<[0, 0, 20, 20], 20, 20>;
declare const CursorFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Cursor: Icon<[0, 0, 20, 20], 20, 20>;
declare const Dash: Icon<[0, 0, 20, 20], 20, 20>;
declare const DiamondHalf: Icon<[0, 0, 20, 20], 20, 20>;
declare const Diamond: Icon<[0, 0, 20, 20], 20, 20>;
declare const DisplayFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Display: Icon<[0, 0, 20, 20], 20, 20>;
declare const DocumentCode: Icon<[0, 0, 20, 20], 20, 20>;
declare const DocumentDiff: Icon<[0, 0, 20, 20], 20, 20>;
declare const DocumentRichtext: Icon<[0, 0, 20, 20], 20, 20>;
declare const DocumentSpreadsheet: Icon<[0, 0, 20, 20], 20, 20>;
declare const DocumentText: Icon<[0, 0, 20, 20], 20, 20>;
declare const Document: Icon<[0, 0, 20, 20], 20, 20>;
declare const DocumentsAlt: Icon<[0, 0, 20, 20], 20, 20>;
declare const Documents: Icon<[0, 0, 20, 20], 20, 20>;
declare const Dot: Icon<[0, 0, 20, 20], 20, 20>;
declare const Download: Icon<[0, 0, 20, 20], 20, 20>;
declare const EggFried: Icon<[0, 0, 20, 20], 20, 20>;
declare const EjectFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Eject: Icon<[0, 0, 20, 20], 20, 20>;
declare const EnvelopeFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const EnvelopeOpenFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const EnvelopeOpen: Icon<[0, 0, 20, 20], 20, 20>;
declare const Envelope: Icon<[0, 0, 20, 20], 20, 20>;
declare const EyeFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const EyeSlashFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const EyeSlash: Icon<[0, 0, 20, 20], 20, 20>;
declare const Eye: Icon<[0, 0, 20, 20], 20, 20>;
declare const Filter: Icon<[0, 0, 20, 20], 20, 20>;
declare const FlagFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Flag: Icon<[0, 0, 20, 20], 20, 20>;
declare const FolderFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const FolderSymlinkFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const FolderSymlink: Icon<[0, 0, 20, 20], 20, 20>;
declare const Folder: Icon<[0, 0, 20, 20], 20, 20>;
declare const Fonts: Icon<[0, 0, 20, 20], 20, 20>;
declare const ForwardFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Forward: Icon<[0, 0, 20, 20], 20, 20>;
declare const GearFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const GearWideConnected: Icon<[0, 0, 20, 20], 20, 20>;
declare const GearWide: Icon<[0, 0, 20, 20], 20, 20>;
declare const Gear: Icon<[0, 0, 20, 20], 20, 20>;
declare const Geo: Icon<[0, 0, 20, 20], 20, 20>;
declare const GraphDown: Icon<[0, 0, 20, 20], 20, 20>;
declare const GraphUp: Icon<[0, 0, 20, 20], 20, 20>;
declare const GridFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Grid: Icon<[0, 0, 20, 20], 20, 20>;
declare const Hammer: Icon<[0, 0, 20, 20], 20, 20>;
declare const Hash: Icon<[0, 0, 20, 20], 20, 20>;
declare const HeartFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Heart: Icon<[0, 0, 20, 20], 20, 20>;
declare const HouseFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const House: Icon<[0, 0, 20, 20], 20, 20>;
declare const ImageAlt: Icon<[0, 0, 20, 20], 20, 20>;
declare const ImageFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Image: Icon<[0, 0, 20, 20], 20, 20>;
declare const Images: Icon<[0, 0, 20, 20], 20, 20>;
declare const InboxFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Inbox: Icon<[0, 0, 20, 20], 20, 20>;
declare const InboxesFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Inboxes: Icon<[0, 0, 20, 20], 20, 20>;
declare const InfoFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const InfoSquareFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const InfoSquare: Icon<[0, 0, 20, 20], 20, 20>;
declare const Info: Icon<[0, 0, 20, 20], 20, 20>;
declare const JustifyLeft: Icon<[0, 0, 20, 20], 20, 20>;
declare const JustifyRight: Icon<[0, 0, 20, 20], 20, 20>;
declare const Justify: Icon<[0, 0, 20, 20], 20, 20>;
declare const KanbanFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Kanban: Icon<[0, 0, 20, 20], 20, 20>;
declare const Laptop: Icon<[0, 0, 20, 20], 20, 20>;
declare const LayoutSidebarReverse: Icon<[0, 0, 20, 20], 20, 20>;
declare const LayoutSidebar: Icon<[0, 0, 20, 20], 20, 20>;
declare const LayoutSplit: Icon<[0, 0, 20, 20], 20, 20>;
declare const ListCheck: Icon<[0, 0, 20, 20], 20, 20>;
declare const ListOl: Icon<[0, 0, 20, 20], 20, 20>;
declare const ListTask: Icon<[0, 0, 20, 20], 20, 20>;
declare const ListUl: Icon<[0, 0, 20, 20], 20, 20>;
declare const List: Icon<[0, 0, 20, 20], 20, 20>;
declare const LockFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Lock: Icon<[0, 0, 20, 20], 20, 20>;
declare const Map: Icon<[0, 0, 20, 20], 20, 20>;
declare const Mic: Icon<[0, 0, 20, 20], 20, 20>;
declare const Moon: Icon<[0, 0, 20, 20], 20, 20>;
declare const MusicPlayerFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const MusicPlayer: Icon<[0, 0, 20, 20], 20, 20>;
declare const Option: Icon<[0, 0, 20, 20], 20, 20>;
declare const Outlet: Icon<[0, 0, 20, 20], 20, 20>;
declare const PauseFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Pause: Icon<[0, 0, 20, 20], 20, 20>;
declare const Pen: Icon<[0, 0, 20, 20], 20, 20>;
declare const Pencil: Icon<[0, 0, 20, 20], 20, 20>;
declare const PeopleFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const People: Icon<[0, 0, 20, 20], 20, 20>;
declare const PersonFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Person: Icon<[0, 0, 20, 20], 20, 20>;
declare const PhoneLandscape: Icon<[0, 0, 20, 20], 20, 20>;
declare const Phone: Icon<[0, 0, 20, 20], 20, 20>;
declare const PieChartFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const PieChart: Icon<[0, 0, 20, 20], 20, 20>;
declare const PlayFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Play: Icon<[0, 0, 20, 20], 20, 20>;
declare const Plug: Icon<[0, 0, 20, 20], 20, 20>;
declare const Plus: Icon<[0, 0, 20, 20], 20, 20>;
declare const Power: Icon<[0, 0, 20, 20], 20, 20>;
declare const QuestionFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const QuestionSquareFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const QuestionSquare: Icon<[0, 0, 20, 20], 20, 20>;
declare const Question: Icon<[0, 0, 20, 20], 20, 20>;
declare const ReplyAllFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const ReplyAll: Icon<[0, 0, 20, 20], 20, 20>;
declare const ReplyFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Reply: Icon<[0, 0, 20, 20], 20, 20>;
declare const Screwdriver: Icon<[0, 0, 20, 20], 20, 20>;
declare const Search: Icon<[0, 0, 20, 20], 20, 20>;
declare const ShieldFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const ShieldLockFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const ShieldLock: Icon<[0, 0, 20, 20], 20, 20>;
declare const ShieldShaded: Icon<[0, 0, 20, 20], 20, 20>;
declare const Shield: Icon<[0, 0, 20, 20], 20, 20>;
declare const ShiftFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Shift: Icon<[0, 0, 20, 20], 20, 20>;
declare const SkipBackwardFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const SkipBackward: Icon<[0, 0, 20, 20], 20, 20>;
declare const SkipEndFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const SkipEnd: Icon<[0, 0, 20, 20], 20, 20>;
declare const SkipForwardFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const SkipForward: Icon<[0, 0, 20, 20], 20, 20>;
declare const SkipStartFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const SkipStart: Icon<[0, 0, 20, 20], 20, 20>;
declare const Speaker: Icon<[0, 0, 20, 20], 20, 20>;
declare const SquareFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const SquareHalf: Icon<[0, 0, 20, 20], 20, 20>;
declare const Square: Icon<[0, 0, 20, 20], 20, 20>;
declare const StarFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const StarHalf: Icon<[0, 0, 20, 20], 20, 20>;
declare const Star: Icon<[0, 0, 20, 20], 20, 20>;
declare const StopFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Stop: Icon<[0, 0, 20, 20], 20, 20>;
declare const StopwatchFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Stopwatch: Icon<[0, 0, 20, 20], 20, 20>;
declare const Sun: Icon<[0, 0, 20, 20], 20, 20>;
declare const Table: Icon<[0, 0, 20, 20], 20, 20>;
declare const TabletLandscape: Icon<[0, 0, 20, 20], 20, 20>;
declare const Tablet: Icon<[0, 0, 20, 20], 20, 20>;
declare const TagFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Tag: Icon<[0, 0, 20, 20], 20, 20>;
declare const TerminalFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Terminal: Icon<[0, 0, 20, 20], 20, 20>;
declare const TextCenter: Icon<[0, 0, 20, 20], 20, 20>;
declare const TextIndentLeft: Icon<[0, 0, 20, 20], 20, 20>;
declare const TextIndentRight: Icon<[0, 0, 20, 20], 20, 20>;
declare const TextLeft: Icon<[0, 0, 20, 20], 20, 20>;
declare const TextRight: Icon<[0, 0, 20, 20], 20, 20>;
declare const ThreeDotsVertical: Icon<[0, 0, 20, 20], 20, 20>;
declare const ThreeDots: Icon<[0, 0, 20, 20], 20, 20>;
declare const ToggleOff: Icon<[0, 0, 20, 20], 20, 20>;
declare const ToggleOn: Icon<[0, 0, 20, 20], 20, 20>;
declare const Toggles: Icon<[0, 0, 20, 20], 20, 20>;
declare const Tools: Icon<[0, 0, 20, 20], 20, 20>;
declare const TrashFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Trash: Icon<[0, 0, 20, 20], 20, 20>;
declare const TriangleFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const TriangleHalf: Icon<[0, 0, 20, 20], 20, 20>;
declare const Triangle: Icon<[0, 0, 20, 20], 20, 20>;
declare const Trophy: Icon<[0, 0, 20, 20], 20, 20>;
declare const TvFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Tv: Icon<[0, 0, 20, 20], 20, 20>;
declare const TypeBold: Icon<[0, 0, 20, 20], 20, 20>;
declare const TypeH1: Icon<[0, 0, 20, 20], 20, 20>;
declare const TypeH2: Icon<[0, 0, 20, 20], 20, 20>;
declare const TypeH3: Icon<[0, 0, 20, 20], 20, 20>;
declare const TypeItalic: Icon<[0, 0, 20, 20], 20, 20>;
declare const TypeStrikethrough: Icon<[0, 0, 20, 20], 20, 20>;
declare const TypeUnderline: Icon<[0, 0, 20, 20], 20, 20>;
declare const Type: Icon<[0, 0, 20, 20], 20, 20>;
declare const UnlockFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const Unlock: Icon<[0, 0, 20, 20], 20, 20>;
declare const Upload: Icon<[0, 0, 20, 20], 20, 20>;
declare const VolumeDownFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const VolumeDown: Icon<[0, 0, 20, 20], 20, 20>;
declare const VolumeMuteFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const VolumeMute: Icon<[0, 0, 20, 20], 20, 20>;
declare const VolumeUpFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const VolumeUp: Icon<[0, 0, 20, 20], 20, 20>;
declare const Wallet: Icon<[0, 0, 20, 20], 20, 20>;
declare const Watch: Icon<[0, 0, 20, 20], 20, 20>;
declare const Wifi: Icon<[0, 0, 20, 20], 20, 20>;
declare const Window: Icon<[0, 0, 20, 20], 20, 20>;
declare const Wrench: Icon<[0, 0, 20, 20], 20, 20>;
declare const XCircleFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const XCircle: Icon<[0, 0, 20, 20], 20, 20>;
declare const XOctagonFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const XOctagon: Icon<[0, 0, 20, 20], 20, 20>;
declare const XSquareFill: Icon<[0, 0, 20, 20], 20, 20>;
declare const XSquare: Icon<[0, 0, 20, 20], 20, 20>;
declare const X: Icon<[0, 0, 20, 20], 20, 20>;

type Icons = {
    'alarm-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'alarm': Icon<[0, 0, 20, 20], 20, 20>,
    'alert-circle-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'alert-circle': Icon<[0, 0, 20, 20], 20, 20>,
    'alert-octagon-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'alert-octagon': Icon<[0, 0, 20, 20], 20, 20>,
    'alert-square-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'alert-square': Icon<[0, 0, 20, 20], 20, 20>,
    'alert-triangle-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'alert-triangle': Icon<[0, 0, 20, 20], 20, 20>,
    'archive-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'archive': Icon<[0, 0, 20, 20], 20, 20>,
    'arrow-bar-bottom': Icon<[0, 0, 20, 20], 20, 20>,
    'arrow-bar-left': Icon<[0, 0, 20, 20], 20, 20>,
    'arrow-bar-right': Icon<[0, 0, 20, 20], 20, 20>,
    'arrow-bar-up': Icon<[0, 0, 20, 20], 20, 20>,
    'arrow-clockwise': Icon<[0, 0, 20, 20], 20, 20>,
    'arrow-counterclockwise': Icon<[0, 0, 20, 20], 20, 20>,
    'arrow-down-left': Icon<[0, 0, 20, 20], 20, 20>,
    'arrow-down-right': Icon<[0, 0, 20, 20], 20, 20>,
    'arrow-down-short': Icon<[0, 0, 20, 20], 20, 20>,
    'arrow-down': Icon<[0, 0, 20, 20], 20, 20>,
    'arrow-left-right': Icon<[0, 0, 20, 20], 20, 20>,
    'arrow-left-short': Icon<[0, 0, 20, 20], 20, 20>,
    'arrow-left': Icon<[0, 0, 20, 20], 20, 20>,
    'arrow-repeat': Icon<[0, 0, 20, 20], 20, 20>,
    'arrow-right-short': Icon<[0, 0, 20, 20], 20, 20>,
    'arrow-right': Icon<[0, 0, 20, 20], 20, 20>,
    'arrow-up-down': Icon<[0, 0, 20, 20], 20, 20>,
    'arrow-up-left': Icon<[0, 0, 20, 20], 20, 20>,
    'arrow-up-right': Icon<[0, 0, 20, 20], 20, 20>,
    'arrow-up-short': Icon<[0, 0, 20, 20], 20, 20>,
    'arrow-up': Icon<[0, 0, 20, 20], 20, 20>,
    'arrows-angle-contract': Icon<[0, 0, 20, 20], 20, 20>,
    'arrows-angle-expand': Icon<[0, 0, 20, 20], 20, 20>,
    'arrows-collapse': Icon<[0, 0, 20, 20], 20, 20>,
    'arrows-expand': Icon<[0, 0, 20, 20], 20, 20>,
    'arrows-fullscreen': Icon<[0, 0, 20, 20], 20, 20>,
    'at': Icon<[0, 0, 20, 20], 20, 20>,
    'award': Icon<[0, 0, 20, 20], 20, 20>,
    'backspace-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'backspace-reverse-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'backspace-reverse': Icon<[0, 0, 20, 20], 20, 20>,
    'backspace': Icon<[0, 0, 20, 20], 20, 20>,
    'bar-chart-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'bar-chart': Icon<[0, 0, 20, 20], 20, 20>,
    'battery-charging': Icon<[0, 0, 20, 20], 20, 20>,
    'battery-full': Icon<[0, 0, 20, 20], 20, 20>,
    'battery': Icon<[0, 0, 20, 20], 20, 20>,
    'bell-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'bell': Icon<[0, 0, 20, 20], 20, 20>,
    'blockquote-left': Icon<[0, 0, 20, 20], 20, 20>,
    'blockquote-right': Icon<[0, 0, 20, 20], 20, 20>,
    'book-half-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'book': Icon<[0, 0, 20, 20], 20, 20>,
    'bookmark-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'bookmark': Icon<[0, 0, 20, 20], 20, 20>,
    'bootstrap-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'bootstrap-reboot': Icon<[0, 0, 20, 20], 20, 20>,
    'bootstrap': Icon<[0, 0, 20, 20], 20, 20>,
    'box-arrow-bottom-left': Icon<[0, 0, 20, 20], 20, 20>,
    'box-arrow-bottom-right': Icon<[0, 0, 20, 20], 20, 20>,
    'box-arrow-down': Icon<[0, 0, 20, 20], 20, 20>,
    'box-arrow-left': Icon<[0, 0, 20, 20], 20, 20>,
    'box-arrow-right': Icon<[0, 0, 20, 20], 20, 20>,
    'box-arrow-up-left': Icon<[0, 0, 20, 20], 20, 20>,
    'box-arrow-up-right': Icon<[0, 0, 20, 20], 20, 20>,
    'box-arrow-up': Icon<[0, 0, 20, 20], 20, 20>,
    'braces': Icon<[0, 0, 20, 20], 20, 20>,
    'brightness-fill-high': Icon<[0, 0, 20, 20], 20, 20>,
    'brightness-fill-low': Icon<[0, 0, 20, 20], 20, 20>,
    'brightness-high': Icon<[0, 0, 20, 20], 20, 20>,
    'brightness-low': Icon<[0, 0, 20, 20], 20, 20>,
    'brush': Icon<[0, 0, 20, 20], 20, 20>,
    'bucket-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'bucket': Icon<[0, 0, 20, 20], 20, 20>,
    'building': Icon<[0, 0, 20, 20], 20, 20>,
    'bullseye': Icon<[0, 0, 20, 20], 20, 20>,
    'calendar-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'calendar': Icon<[0, 0, 20, 20], 20, 20>,
    'camera-video-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'camera-video': Icon<[0, 0, 20, 20], 20, 20>,
    'camera': Icon<[0, 0, 20, 20], 20, 20>,
    'capslock-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'capslock': Icon<[0, 0, 20, 20], 20, 20>,
    'chat-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'chat': Icon<[0, 0, 20, 20], 20, 20>,
    'check-box': Icon<[0, 0, 20, 20], 20, 20>,
    'check-circle': Icon<[0, 0, 20, 20], 20, 20>,
    'check': Icon<[0, 0, 20, 20], 20, 20>,
    'chevron-compact-down': Icon<[0, 0, 20, 20], 20, 20>,
    'chevron-compact-left': Icon<[0, 0, 20, 20], 20, 20>,
    'chevron-compact-right': Icon<[0, 0, 20, 20], 20, 20>,
    'chevron-compact-up': Icon<[0, 0, 20, 20], 20, 20>,
    'chevron-down': Icon<[0, 0, 20, 20], 20, 20>,
    'chevron-left': Icon<[0, 0, 20, 20], 20, 20>,
    'chevron-right': Icon<[0, 0, 20, 20], 20, 20>,
    'chevron-up': Icon<[0, 0, 20, 20], 20, 20>,
    'circle-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'circle-half': Icon<[0, 0, 20, 20], 20, 20>,
    'circle-slash': Icon<[0, 0, 20, 20], 20, 20>,
    'circle': Icon<[0, 0, 20, 20], 20, 20>,
    'clock-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'clock': Icon<[0, 0, 20, 20], 20, 20>,
    'cloud-download': Icon<[0, 0, 20, 20], 20, 20>,
    'cloud-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'cloud-upload': Icon<[0, 0, 20, 20], 20, 20>,
    'cloud': Icon<[0, 0, 20, 20], 20, 20>,
    'code-slash': Icon<[0, 0, 20, 20], 20, 20>,
    'code': Icon<[0, 0, 20, 20], 20, 20>,
    'columns-gutters': Icon<[0, 0, 20, 20], 20, 20>,
    'columns': Icon<[0, 0, 20, 20], 20, 20>,
    'command': Icon<[0, 0, 20, 20], 20, 20>,
    'compass': Icon<[0, 0, 20, 20], 20, 20>,
    'cone-striped': Icon<[0, 0, 20, 20], 20, 20>,
    'cone': Icon<[0, 0, 20, 20], 20, 20>,
    'controller': Icon<[0, 0, 20, 20], 20, 20>,
    'credit-card': Icon<[0, 0, 20, 20], 20, 20>,
    'cursor-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'cursor': Icon<[0, 0, 20, 20], 20, 20>,
    'dash': Icon<[0, 0, 20, 20], 20, 20>,
    'diamond-half': Icon<[0, 0, 20, 20], 20, 20>,
    'diamond': Icon<[0, 0, 20, 20], 20, 20>,
    'display-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'display': Icon<[0, 0, 20, 20], 20, 20>,
    'document-code': Icon<[0, 0, 20, 20], 20, 20>,
    'document-diff': Icon<[0, 0, 20, 20], 20, 20>,
    'document-richtext': Icon<[0, 0, 20, 20], 20, 20>,
    'document-spreadsheet': Icon<[0, 0, 20, 20], 20, 20>,
    'document-text': Icon<[0, 0, 20, 20], 20, 20>,
    'document': Icon<[0, 0, 20, 20], 20, 20>,
    'documents-alt': Icon<[0, 0, 20, 20], 20, 20>,
    'documents': Icon<[0, 0, 20, 20], 20, 20>,
    'dot': Icon<[0, 0, 20, 20], 20, 20>,
    'download': Icon<[0, 0, 20, 20], 20, 20>,
    'egg-fried': Icon<[0, 0, 20, 20], 20, 20>,
    'eject-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'eject': Icon<[0, 0, 20, 20], 20, 20>,
    'envelope-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'envelope-open-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'envelope-open': Icon<[0, 0, 20, 20], 20, 20>,
    'envelope': Icon<[0, 0, 20, 20], 20, 20>,
    'eye-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'eye-slash-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'eye-slash': Icon<[0, 0, 20, 20], 20, 20>,
    'eye': Icon<[0, 0, 20, 20], 20, 20>,
    'filter': Icon<[0, 0, 20, 20], 20, 20>,
    'flag-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'flag': Icon<[0, 0, 20, 20], 20, 20>,
    'folder-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'folder-symlink-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'folder-symlink': Icon<[0, 0, 20, 20], 20, 20>,
    'folder': Icon<[0, 0, 20, 20], 20, 20>,
    'fonts': Icon<[0, 0, 20, 20], 20, 20>,
    'forward-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'forward': Icon<[0, 0, 20, 20], 20, 20>,
    'gear-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'gear-wide-connected': Icon<[0, 0, 20, 20], 20, 20>,
    'gear-wide': Icon<[0, 0, 20, 20], 20, 20>,
    'gear': Icon<[0, 0, 20, 20], 20, 20>,
    'geo': Icon<[0, 0, 20, 20], 20, 20>,
    'graph-down': Icon<[0, 0, 20, 20], 20, 20>,
    'graph-up': Icon<[0, 0, 20, 20], 20, 20>,
    'grid-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'grid': Icon<[0, 0, 20, 20], 20, 20>,
    'hammer': Icon<[0, 0, 20, 20], 20, 20>,
    'hash': Icon<[0, 0, 20, 20], 20, 20>,
    'heart-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'heart': Icon<[0, 0, 20, 20], 20, 20>,
    'house-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'house': Icon<[0, 0, 20, 20], 20, 20>,
    'image-alt': Icon<[0, 0, 20, 20], 20, 20>,
    'image-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'image': Icon<[0, 0, 20, 20], 20, 20>,
    'images': Icon<[0, 0, 20, 20], 20, 20>,
    'inbox-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'inbox': Icon<[0, 0, 20, 20], 20, 20>,
    'inboxes-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'inboxes': Icon<[0, 0, 20, 20], 20, 20>,
    'info-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'info-square-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'info-square': Icon<[0, 0, 20, 20], 20, 20>,
    'info': Icon<[0, 0, 20, 20], 20, 20>,
    'justify-left': Icon<[0, 0, 20, 20], 20, 20>,
    'justify-right': Icon<[0, 0, 20, 20], 20, 20>,
    'justify': Icon<[0, 0, 20, 20], 20, 20>,
    'kanban-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'kanban': Icon<[0, 0, 20, 20], 20, 20>,
    'laptop': Icon<[0, 0, 20, 20], 20, 20>,
    'layout-sidebar-reverse': Icon<[0, 0, 20, 20], 20, 20>,
    'layout-sidebar': Icon<[0, 0, 20, 20], 20, 20>,
    'layout-split': Icon<[0, 0, 20, 20], 20, 20>,
    'list-check': Icon<[0, 0, 20, 20], 20, 20>,
    'list-ol': Icon<[0, 0, 20, 20], 20, 20>,
    'list-task': Icon<[0, 0, 20, 20], 20, 20>,
    'list-ul': Icon<[0, 0, 20, 20], 20, 20>,
    'list': Icon<[0, 0, 20, 20], 20, 20>,
    'lock-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'lock': Icon<[0, 0, 20, 20], 20, 20>,
    'map': Icon<[0, 0, 20, 20], 20, 20>,
    'mic': Icon<[0, 0, 20, 20], 20, 20>,
    'moon': Icon<[0, 0, 20, 20], 20, 20>,
    'music-player-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'music-player': Icon<[0, 0, 20, 20], 20, 20>,
    'option': Icon<[0, 0, 20, 20], 20, 20>,
    'outlet': Icon<[0, 0, 20, 20], 20, 20>,
    'pause-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'pause': Icon<[0, 0, 20, 20], 20, 20>,
    'pen': Icon<[0, 0, 20, 20], 20, 20>,
    'pencil': Icon<[0, 0, 20, 20], 20, 20>,
    'people-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'people': Icon<[0, 0, 20, 20], 20, 20>,
    'person-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'person': Icon<[0, 0, 20, 20], 20, 20>,
    'phone-landscape': Icon<[0, 0, 20, 20], 20, 20>,
    'phone': Icon<[0, 0, 20, 20], 20, 20>,
    'pie-chart-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'pie-chart': Icon<[0, 0, 20, 20], 20, 20>,
    'play-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'play': Icon<[0, 0, 20, 20], 20, 20>,
    'plug': Icon<[0, 0, 20, 20], 20, 20>,
    'plus': Icon<[0, 0, 20, 20], 20, 20>,
    'power': Icon<[0, 0, 20, 20], 20, 20>,
    'question-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'question-square-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'question-square': Icon<[0, 0, 20, 20], 20, 20>,
    'question': Icon<[0, 0, 20, 20], 20, 20>,
    'reply-all-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'reply-all': Icon<[0, 0, 20, 20], 20, 20>,
    'reply-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'reply': Icon<[0, 0, 20, 20], 20, 20>,
    'screwdriver': Icon<[0, 0, 20, 20], 20, 20>,
    'search': Icon<[0, 0, 20, 20], 20, 20>,
    'shield-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'shield-lock-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'shield-lock': Icon<[0, 0, 20, 20], 20, 20>,
    'shield-shaded': Icon<[0, 0, 20, 20], 20, 20>,
    'shield': Icon<[0, 0, 20, 20], 20, 20>,
    'shift-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'shift': Icon<[0, 0, 20, 20], 20, 20>,
    'skip-backward-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'skip-backward': Icon<[0, 0, 20, 20], 20, 20>,
    'skip-end-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'skip-end': Icon<[0, 0, 20, 20], 20, 20>,
    'skip-forward-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'skip-forward': Icon<[0, 0, 20, 20], 20, 20>,
    'skip-start-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'skip-start': Icon<[0, 0, 20, 20], 20, 20>,
    'speaker': Icon<[0, 0, 20, 20], 20, 20>,
    'square-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'square-half': Icon<[0, 0, 20, 20], 20, 20>,
    'square': Icon<[0, 0, 20, 20], 20, 20>,
    'star-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'star-half': Icon<[0, 0, 20, 20], 20, 20>,
    'star': Icon<[0, 0, 20, 20], 20, 20>,
    'stop-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'stop': Icon<[0, 0, 20, 20], 20, 20>,
    'stopwatch-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'stopwatch': Icon<[0, 0, 20, 20], 20, 20>,
    'sun': Icon<[0, 0, 20, 20], 20, 20>,
    'table': Icon<[0, 0, 20, 20], 20, 20>,
    'tablet-landscape': Icon<[0, 0, 20, 20], 20, 20>,
    'tablet': Icon<[0, 0, 20, 20], 20, 20>,
    'tag-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'tag': Icon<[0, 0, 20, 20], 20, 20>,
    'terminal-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'terminal': Icon<[0, 0, 20, 20], 20, 20>,
    'text-center': Icon<[0, 0, 20, 20], 20, 20>,
    'text-indent-left': Icon<[0, 0, 20, 20], 20, 20>,
    'text-indent-right': Icon<[0, 0, 20, 20], 20, 20>,
    'text-left': Icon<[0, 0, 20, 20], 20, 20>,
    'text-right': Icon<[0, 0, 20, 20], 20, 20>,
    'three-dots-vertical': Icon<[0, 0, 20, 20], 20, 20>,
    'three-dots': Icon<[0, 0, 20, 20], 20, 20>,
    'toggle-off': Icon<[0, 0, 20, 20], 20, 20>,
    'toggle-on': Icon<[0, 0, 20, 20], 20, 20>,
    'toggles': Icon<[0, 0, 20, 20], 20, 20>,
    'tools': Icon<[0, 0, 20, 20], 20, 20>,
    'trash-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'trash': Icon<[0, 0, 20, 20], 20, 20>,
    'triangle-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'triangle-half': Icon<[0, 0, 20, 20], 20, 20>,
    'triangle': Icon<[0, 0, 20, 20], 20, 20>,
    'trophy': Icon<[0, 0, 20, 20], 20, 20>,
    'tv-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'tv': Icon<[0, 0, 20, 20], 20, 20>,
    'type-bold': Icon<[0, 0, 20, 20], 20, 20>,
    'type-h1': Icon<[0, 0, 20, 20], 20, 20>,
    'type-h2': Icon<[0, 0, 20, 20], 20, 20>,
    'type-h3': Icon<[0, 0, 20, 20], 20, 20>,
    'type-italic': Icon<[0, 0, 20, 20], 20, 20>,
    'type-strikethrough': Icon<[0, 0, 20, 20], 20, 20>,
    'type-underline': Icon<[0, 0, 20, 20], 20, 20>,
    'type': Icon<[0, 0, 20, 20], 20, 20>,
    'unlock-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'unlock': Icon<[0, 0, 20, 20], 20, 20>,
    'upload': Icon<[0, 0, 20, 20], 20, 20>,
    'volume-down-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'volume-down': Icon<[0, 0, 20, 20], 20, 20>,
    'volume-mute-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'volume-mute': Icon<[0, 0, 20, 20], 20, 20>,
    'volume-up-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'volume-up': Icon<[0, 0, 20, 20], 20, 20>,
    'wallet': Icon<[0, 0, 20, 20], 20, 20>,
    'watch': Icon<[0, 0, 20, 20], 20, 20>,
    'wifi': Icon<[0, 0, 20, 20], 20, 20>,
    'window': Icon<[0, 0, 20, 20], 20, 20>,
    'wrench': Icon<[0, 0, 20, 20], 20, 20>,
    'x-circle-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'x-circle': Icon<[0, 0, 20, 20], 20, 20>,
    'x-octagon-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'x-octagon': Icon<[0, 0, 20, 20], 20, 20>,
    'x-square-fill': Icon<[0, 0, 20, 20], 20, 20>,
    'x-square': Icon<[0, 0, 20, 20], 20, 20>,
    'x': Icon<[0, 0, 20, 20], 20, 20>
};

declare const icons: Icons;

export default icons;
export {
    AlarmFill,
    Alarm,
    AlertCircleFill,
    AlertCircle,
    AlertOctagonFill,
    AlertOctagon,
    AlertSquareFill,
    AlertSquare,
    AlertTriangleFill,
    AlertTriangle,
    ArchiveFill,
    Archive,
    ArrowBarBottom,
    ArrowBarLeft,
    ArrowBarRight,
    ArrowBarUp,
    ArrowClockwise,
    ArrowCounterclockwise,
    ArrowDownLeft,
    ArrowDownRight,
    ArrowDownShort,
    ArrowDown,
    ArrowLeftRight,
    ArrowLeftShort,
    ArrowLeft,
    ArrowRepeat,
    ArrowRightShort,
    ArrowRight,
    ArrowUpDown,
    ArrowUpLeft,
    ArrowUpRight,
    ArrowUpShort,
    ArrowUp,
    ArrowsAngleContract,
    ArrowsAngleExpand,
    ArrowsCollapse,
    ArrowsExpand,
    ArrowsFullscreen,
    At,
    Award,
    BackspaceFill,
    BackspaceReverseFill,
    BackspaceReverse,
    Backspace,
    BarChartFill,
    BarChart,
    BatteryCharging,
    BatteryFull,
    Battery,
    BellFill,
    Bell,
    BlockquoteLeft,
    BlockquoteRight,
    BookHalfFill,
    Book,
    BookmarkFill,
    Bookmark,
    BootstrapFill,
    BootstrapReboot,
    Bootstrap,
    BoxArrowBottomLeft,
    BoxArrowBottomRight,
    BoxArrowDown,
    BoxArrowLeft,
    BoxArrowRight,
    BoxArrowUpLeft,
    BoxArrowUpRight,
    BoxArrowUp,
    Braces,
    BrightnessFillHigh,
    BrightnessFillLow,
    BrightnessHigh,
    BrightnessLow,
    Brush,
    BucketFill,
    Bucket,
    Building,
    Bullseye,
    CalendarFill,
    Calendar,
    CameraVideoFill,
    CameraVideo,
    Camera,
    CapslockFill,
    Capslock,
    ChatFill,
    Chat,
    CheckBox,
    CheckCircle,
    Check,
    ChevronCompactDown,
    ChevronCompactLeft,
    ChevronCompactRight,
    ChevronCompactUp,
    ChevronDown,
    ChevronLeft,
    ChevronRight,
    ChevronUp,
    CircleFill,
    CircleHalf,
    CircleSlash,
    Circle,
    ClockFill,
    Clock,
    CloudDownload,
    CloudFill,
    CloudUpload,
    Cloud,
    CodeSlash,
    Code,
    ColumnsGutters,
    Columns,
    Command,
    Compass,
    ConeStriped,
    Cone,
    Controller,
    CreditCard,
    CursorFill,
    Cursor,
    Dash,
    DiamondHalf,
    Diamond,
    DisplayFill,
    Display,
    DocumentCode,
    DocumentDiff,
    DocumentRichtext,
    DocumentSpreadsheet,
    DocumentText,
    Document,
    DocumentsAlt,
    Documents,
    Dot,
    Download,
    EggFried,
    EjectFill,
    Eject,
    EnvelopeFill,
    EnvelopeOpenFill,
    EnvelopeOpen,
    Envelope,
    EyeFill,
    EyeSlashFill,
    EyeSlash,
    Eye,
    Filter,
    FlagFill,
    Flag,
    FolderFill,
    FolderSymlinkFill,
    FolderSymlink,
    Folder,
    Fonts,
    ForwardFill,
    Forward,
    GearFill,
    GearWideConnected,
    GearWide,
    Gear,
    Geo,
    GraphDown,
    GraphUp,
    GridFill,
    Grid,
    Hammer,
    Hash,
    HeartFill,
    Heart,
    HouseFill,
    House,
    ImageAlt,
    ImageFill,
    Image,
    Images,
    InboxFill,
    Inbox,
    InboxesFill,
    Inboxes,
    InfoFill,
    InfoSquareFill,
    InfoSquare,
    Info,
    JustifyLeft,
    JustifyRight,
    Justify,
    KanbanFill,
    Kanban,
    Laptop,
    LayoutSidebarReverse,
    LayoutSidebar,
    LayoutSplit,
    ListCheck,
    ListOl,
    ListTask,
    ListUl,
    List,
    LockFill,
    Lock,
    Map,
    Mic,
    Moon,
    MusicPlayerFill,
    MusicPlayer,
    Option,
    Outlet,
    PauseFill,
    Pause,
    Pen,
    Pencil,
    PeopleFill,
    People,
    PersonFill,
    Person,
    PhoneLandscape,
    Phone,
    PieChartFill,
    PieChart,
    PlayFill,
    Play,
    Plug,
    Plus,
    Power,
    QuestionFill,
    QuestionSquareFill,
    QuestionSquare,
    Question,
    ReplyAllFill,
    ReplyAll,
    ReplyFill,
    Reply,
    Screwdriver,
    Search,
    ShieldFill,
    ShieldLockFill,
    ShieldLock,
    ShieldShaded,
    Shield,
    ShiftFill,
    Shift,
    SkipBackwardFill,
    SkipBackward,
    SkipEndFill,
    SkipEnd,
    SkipForwardFill,
    SkipForward,
    SkipStartFill,
    SkipStart,
    Speaker,
    SquareFill,
    SquareHalf,
    Square,
    StarFill,
    StarHalf,
    Star,
    StopFill,
    Stop,
    StopwatchFill,
    Stopwatch,
    Sun,
    Table,
    TabletLandscape,
    Tablet,
    TagFill,
    Tag,
    TerminalFill,
    Terminal,
    TextCenter,
    TextIndentLeft,
    TextIndentRight,
    TextLeft,
    TextRight,
    ThreeDotsVertical,
    ThreeDots,
    ToggleOff,
    ToggleOn,
    Toggles,
    Tools,
    TrashFill,
    Trash,
    TriangleFill,
    TriangleHalf,
    Triangle,
    Trophy,
    TvFill,
    Tv,
    TypeBold,
    TypeH1,
    TypeH2,
    TypeH3,
    TypeItalic,
    TypeStrikethrough,
    TypeUnderline,
    Type,
    UnlockFill,
    Unlock,
    Upload,
    VolumeDownFill,
    VolumeDown,
    VolumeMuteFill,
    VolumeMute,
    VolumeUpFill,
    VolumeUp,
    Wallet,
    Watch,
    Wifi,
    Window,
    Wrench,
    XCircleFill,
    XCircle,
    XOctagonFill,
    XOctagon,
    XSquareFill,
    XSquare,
    X
};
