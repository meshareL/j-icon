/* THIS FILE IS GENERATED. DO NOT EDIT IT. */
import {CreateElement, VNode} from 'vue';
import {Icon} from '@tomoeed/j-icon';

declare const Ad: Icon<[0, 0, 512, 512], 512, 512>;
declare const AddressBook: Icon<[0, 0, 448, 512], 448, 512>;
declare const AddressCard: Icon<[0, 0, 576, 512], 576, 512>;
declare const Adjust: Icon<[0, 0, 512, 512], 512, 512>;
declare const AirFreshener: Icon<[0, 0, 384, 512], 384, 512>;
declare const AlignCenter: Icon<[0, 0, 448, 512], 448, 512>;
declare const AlignJustify: Icon<[0, 0, 448, 512], 448, 512>;
declare const AlignLeft: Icon<[0, 0, 448, 512], 448, 512>;
declare const AlignRight: Icon<[0, 0, 448, 512], 448, 512>;
declare const Allergies: Icon<[0, 0, 448, 512], 448, 512>;
declare const Ambulance: Icon<[0, 0, 640, 512], 640, 512>;
declare const AmericanSignLanguageInterpreting: Icon<[0, 0, 640, 512], 640, 512>;
declare const Anchor: Icon<[0, 0, 576, 512], 576, 512>;
declare const AngleDoubleDown: Icon<[0, 0, 320, 512], 320, 512>;
declare const AngleDoubleLeft: Icon<[0, 0, 448, 512], 448, 512>;
declare const AngleDoubleRight: Icon<[0, 0, 448, 512], 448, 512>;
declare const AngleDoubleUp: Icon<[0, 0, 320, 512], 320, 512>;
declare const AngleDown: Icon<[0, 0, 320, 512], 320, 512>;
declare const AngleLeft: Icon<[0, 0, 256, 512], 256, 512>;
declare const AngleRight: Icon<[0, 0, 256, 512], 256, 512>;
declare const AngleUp: Icon<[0, 0, 320, 512], 320, 512>;
declare const Angry: Icon<[0, 0, 496, 512], 496, 512>;
declare const Ankh: Icon<[0, 0, 320, 512], 320, 512>;
declare const AppleAlt: Icon<[0, 0, 448, 512], 448, 512>;
declare const Archive: Icon<[0, 0, 512, 512], 512, 512>;
declare const Archway: Icon<[0, 0, 576, 512], 576, 512>;
declare const ArrowAltCircleDown: Icon<[0, 0, 512, 512], 512, 512>;
declare const ArrowAltCircleLeft: Icon<[0, 0, 512, 512], 512, 512>;
declare const ArrowAltCircleRight: Icon<[0, 0, 512, 512], 512, 512>;
declare const ArrowAltCircleUp: Icon<[0, 0, 512, 512], 512, 512>;
declare const ArrowCircleDown: Icon<[0, 0, 512, 512], 512, 512>;
declare const ArrowCircleLeft: Icon<[0, 0, 512, 512], 512, 512>;
declare const ArrowCircleRight: Icon<[0, 0, 512, 512], 512, 512>;
declare const ArrowCircleUp: Icon<[0, 0, 512, 512], 512, 512>;
declare const ArrowDown: Icon<[0, 0, 448, 512], 448, 512>;
declare const ArrowLeft: Icon<[0, 0, 448, 512], 448, 512>;
declare const ArrowRight: Icon<[0, 0, 448, 512], 448, 512>;
declare const ArrowUp: Icon<[0, 0, 448, 512], 448, 512>;
declare const ArrowsAltH: Icon<[0, 0, 512, 512], 512, 512>;
declare const ArrowsAltV: Icon<[0, 0, 256, 512], 256, 512>;
declare const ArrowsAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const AssistiveListeningSystems: Icon<[0, 0, 512, 512], 512, 512>;
declare const Asterisk: Icon<[0, 0, 512, 512], 512, 512>;
declare const At: Icon<[0, 0, 512, 512], 512, 512>;
declare const Atlas: Icon<[0, 0, 448, 512], 448, 512>;
declare const Atom: Icon<[0, 0, 448, 512], 448, 512>;
declare const AudioDescription: Icon<[0, 0, 512, 512], 512, 512>;
declare const Award: Icon<[0, 0, 384, 512], 384, 512>;
declare const BabyCarriage: Icon<[0, 0, 512, 512], 512, 512>;
declare const Baby: Icon<[0, 0, 384, 512], 384, 512>;
declare const Backspace: Icon<[0, 0, 640, 512], 640, 512>;
declare const Backward: Icon<[0, 0, 512, 512], 512, 512>;
declare const Bacon: Icon<[0, 0, 576, 512], 576, 512>;
declare const Bahai: Icon<[0, 0, 512, 512], 512, 512>;
declare const BalanceScaleLeft: Icon<[0, 0, 640, 512], 640, 512>;
declare const BalanceScaleRight: Icon<[0, 0, 640, 512], 640, 512>;
declare const BalanceScale: Icon<[0, 0, 640, 512], 640, 512>;
declare const Ban: Icon<[0, 0, 512, 512], 512, 512>;
declare const BandAid: Icon<[0, 0, 640, 512], 640, 512>;
declare const Barcode: Icon<[0, 0, 512, 512], 512, 512>;
declare const Bars: Icon<[0, 0, 448, 512], 448, 512>;
declare const BaseballBall: Icon<[0, 0, 496, 512], 496, 512>;
declare const BasketballBall: Icon<[0, 0, 496, 512], 496, 512>;
declare const Bath: Icon<[0, 0, 512, 512], 512, 512>;
declare const BatteryEmpty: Icon<[0, 0, 640, 512], 640, 512>;
declare const BatteryFull: Icon<[0, 0, 640, 512], 640, 512>;
declare const BatteryHalf: Icon<[0, 0, 640, 512], 640, 512>;
declare const BatteryQuarter: Icon<[0, 0, 640, 512], 640, 512>;
declare const BatteryThreeQuarters: Icon<[0, 0, 640, 512], 640, 512>;
declare const Bed: Icon<[0, 0, 640, 512], 640, 512>;
declare const Beer: Icon<[0, 0, 448, 512], 448, 512>;
declare const BellSlash: Icon<[0, 0, 640, 512], 640, 512>;
declare const Bell: Icon<[0, 0, 448, 512], 448, 512>;
declare const BezierCurve: Icon<[0, 0, 640, 512], 640, 512>;
declare const Bible: Icon<[0, 0, 448, 512], 448, 512>;
declare const Bicycle: Icon<[0, 0, 640, 512], 640, 512>;
declare const Biking: Icon<[0, 0, 640, 512], 640, 512>;
declare const Binoculars: Icon<[0, 0, 512, 512], 512, 512>;
declare const Biohazard: Icon<[0, 0, 576, 512], 576, 512>;
declare const BirthdayCake: Icon<[0, 0, 448, 512], 448, 512>;
declare const BlenderPhone: Icon<[0, 0, 576, 512], 576, 512>;
declare const Blender: Icon<[0, 0, 512, 512], 512, 512>;
declare const Blind: Icon<[0, 0, 384, 512], 384, 512>;
declare const Blog: Icon<[0, 0, 512, 512], 512, 512>;
declare const Bold: Icon<[0, 0, 384, 512], 384, 512>;
declare const Bolt: Icon<[0, 0, 320, 512], 320, 512>;
declare const Bomb: Icon<[0, 0, 512, 512], 512, 512>;
declare const Bone: Icon<[0, 0, 640, 512], 640, 512>;
declare const Bong: Icon<[0, 0, 448, 512], 448, 512>;
declare const BookDead: Icon<[0, 0, 448, 512], 448, 512>;
declare const BookMedical: Icon<[0, 0, 448, 512], 448, 512>;
declare const BookOpen: Icon<[0, 0, 576, 512], 576, 512>;
declare const BookReader: Icon<[0, 0, 512, 512], 512, 512>;
declare const Book: Icon<[0, 0, 448, 512], 448, 512>;
declare const Bookmark: Icon<[0, 0, 384, 512], 384, 512>;
declare const BorderAll: Icon<[0, 0, 448, 512], 448, 512>;
declare const BorderNone: Icon<[0, 0, 448, 512], 448, 512>;
declare const BorderStyle: Icon<[0, 0, 448, 512], 448, 512>;
declare const BowlingBall: Icon<[0, 0, 496, 512], 496, 512>;
declare const BoxOpen: Icon<[0, 0, 640, 512], 640, 512>;
declare const Box: Icon<[0, 0, 512, 512], 512, 512>;
declare const Boxes: Icon<[0, 0, 576, 512], 576, 512>;
declare const Braille: Icon<[0, 0, 640, 512], 640, 512>;
declare const Brain: Icon<[0, 0, 576, 512], 576, 512>;
declare const BreadSlice: Icon<[0, 0, 576, 512], 576, 512>;
declare const BriefcaseMedical: Icon<[0, 0, 512, 512], 512, 512>;
declare const Briefcase: Icon<[0, 0, 512, 512], 512, 512>;
declare const BroadcastTower: Icon<[0, 0, 640, 512], 640, 512>;
declare const Broom: Icon<[0, 0, 640, 512], 640, 512>;
declare const Brush: Icon<[0, 0, 384, 512], 384, 512>;
declare const Bug: Icon<[0, 0, 512, 512], 512, 512>;
declare const Building: Icon<[0, 0, 448, 512], 448, 512>;
declare const Bullhorn: Icon<[0, 0, 576, 512], 576, 512>;
declare const Bullseye: Icon<[0, 0, 496, 512], 496, 512>;
declare const Burn: Icon<[0, 0, 384, 512], 384, 512>;
declare const BusAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const Bus: Icon<[0, 0, 512, 512], 512, 512>;
declare const BusinessTime: Icon<[0, 0, 640, 512], 640, 512>;
declare const Calculator: Icon<[0, 0, 448, 512], 448, 512>;
declare const CalendarAlt: Icon<[0, 0, 448, 512], 448, 512>;
declare const CalendarCheck: Icon<[0, 0, 448, 512], 448, 512>;
declare const CalendarDay: Icon<[0, 0, 448, 512], 448, 512>;
declare const CalendarMinus: Icon<[0, 0, 448, 512], 448, 512>;
declare const CalendarPlus: Icon<[0, 0, 448, 512], 448, 512>;
declare const CalendarTimes: Icon<[0, 0, 448, 512], 448, 512>;
declare const CalendarWeek: Icon<[0, 0, 448, 512], 448, 512>;
declare const Calendar: Icon<[0, 0, 448, 512], 448, 512>;
declare const CameraRetro: Icon<[0, 0, 512, 512], 512, 512>;
declare const Camera: Icon<[0, 0, 512, 512], 512, 512>;
declare const Campground: Icon<[0, 0, 640, 512], 640, 512>;
declare const CandyCane: Icon<[0, 0, 512, 512], 512, 512>;
declare const Cannabis: Icon<[0, 0, 512, 512], 512, 512>;
declare const Capsules: Icon<[0, 0, 576, 512], 576, 512>;
declare const CarAlt: Icon<[0, 0, 480, 512], 480, 512>;
declare const CarBattery: Icon<[0, 0, 512, 512], 512, 512>;
declare const CarCrash: Icon<[0, 0, 640, 512], 640, 512>;
declare const CarSide: Icon<[0, 0, 640, 512], 640, 512>;
declare const Car: Icon<[0, 0, 512, 512], 512, 512>;
declare const Caravan: Icon<[0, 0, 640, 512], 640, 512>;
declare const CaretDown: Icon<[0, 0, 320, 512], 320, 512>;
declare const CaretLeft: Icon<[0, 0, 192, 512], 192, 512>;
declare const CaretRight: Icon<[0, 0, 192, 512], 192, 512>;
declare const CaretSquareDown: Icon<[0, 0, 448, 512], 448, 512>;
declare const CaretSquareLeft: Icon<[0, 0, 448, 512], 448, 512>;
declare const CaretSquareRight: Icon<[0, 0, 448, 512], 448, 512>;
declare const CaretSquareUp: Icon<[0, 0, 448, 512], 448, 512>;
declare const CaretUp: Icon<[0, 0, 320, 512], 320, 512>;
declare const Carrot: Icon<[0, 0, 512, 512], 512, 512>;
declare const CartArrowDown: Icon<[0, 0, 576, 512], 576, 512>;
declare const CartPlus: Icon<[0, 0, 576, 512], 576, 512>;
declare const CashRegister: Icon<[0, 0, 512, 512], 512, 512>;
declare const Cat: Icon<[0, 0, 512, 512], 512, 512>;
declare const Certificate: Icon<[0, 0, 512, 512], 512, 512>;
declare const Chair: Icon<[0, 0, 448, 512], 448, 512>;
declare const ChalkboardTeacher: Icon<[0, 0, 640, 512], 640, 512>;
declare const Chalkboard: Icon<[0, 0, 640, 512], 640, 512>;
declare const ChargingStation: Icon<[0, 0, 576, 512], 576, 512>;
declare const ChartArea: Icon<[0, 0, 512, 512], 512, 512>;
declare const ChartBar: Icon<[0, 0, 512, 512], 512, 512>;
declare const ChartLine: Icon<[0, 0, 512, 512], 512, 512>;
declare const ChartPie: Icon<[0, 0, 544, 512], 544, 512>;
declare const CheckCircle: Icon<[0, 0, 512, 512], 512, 512>;
declare const CheckDouble: Icon<[0, 0, 512, 512], 512, 512>;
declare const CheckSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Check: Icon<[0, 0, 512, 512], 512, 512>;
declare const Cheese: Icon<[0, 0, 512, 512], 512, 512>;
declare const ChessBishop: Icon<[0, 0, 320, 512], 320, 512>;
declare const ChessBoard: Icon<[0, 0, 512, 512], 512, 512>;
declare const ChessKing: Icon<[0, 0, 448, 512], 448, 512>;
declare const ChessKnight: Icon<[0, 0, 384, 512], 384, 512>;
declare const ChessPawn: Icon<[0, 0, 320, 512], 320, 512>;
declare const ChessQueen: Icon<[0, 0, 512, 512], 512, 512>;
declare const ChessRook: Icon<[0, 0, 384, 512], 384, 512>;
declare const Chess: Icon<[0, 0, 512, 512], 512, 512>;
declare const ChevronCircleDown: Icon<[0, 0, 512, 512], 512, 512>;
declare const ChevronCircleLeft: Icon<[0, 0, 512, 512], 512, 512>;
declare const ChevronCircleRight: Icon<[0, 0, 512, 512], 512, 512>;
declare const ChevronCircleUp: Icon<[0, 0, 512, 512], 512, 512>;
declare const ChevronDown: Icon<[0, 0, 448, 512], 448, 512>;
declare const ChevronLeft: Icon<[0, 0, 320, 512], 320, 512>;
declare const ChevronRight: Icon<[0, 0, 320, 512], 320, 512>;
declare const ChevronUp: Icon<[0, 0, 448, 512], 448, 512>;
declare const Child: Icon<[0, 0, 384, 512], 384, 512>;
declare const Church: Icon<[0, 0, 640, 512], 640, 512>;
declare const CircleNotch: Icon<[0, 0, 512, 512], 512, 512>;
declare const Circle: Icon<[0, 0, 512, 512], 512, 512>;
declare const City: Icon<[0, 0, 640, 512], 640, 512>;
declare const ClinicMedical: Icon<[0, 0, 576, 512], 576, 512>;
declare const ClipboardCheck: Icon<[0, 0, 384, 512], 384, 512>;
declare const ClipboardList: Icon<[0, 0, 384, 512], 384, 512>;
declare const Clipboard: Icon<[0, 0, 384, 512], 384, 512>;
declare const Clock: Icon<[0, 0, 512, 512], 512, 512>;
declare const Clone: Icon<[0, 0, 512, 512], 512, 512>;
declare const ClosedCaptioning: Icon<[0, 0, 512, 512], 512, 512>;
declare const CloudDownloadAlt: Icon<[0, 0, 640, 512], 640, 512>;
declare const CloudMeatball: Icon<[0, 0, 512, 512], 512, 512>;
declare const CloudMoonRain: Icon<[0, 0, 576, 512], 576, 512>;
declare const CloudMoon: Icon<[0, 0, 576, 512], 576, 512>;
declare const CloudRain: Icon<[0, 0, 512, 512], 512, 512>;
declare const CloudShowersHeavy: Icon<[0, 0, 512, 512], 512, 512>;
declare const CloudSunRain: Icon<[0, 0, 576, 512], 576, 512>;
declare const CloudSun: Icon<[0, 0, 640, 512], 640, 512>;
declare const CloudUploadAlt: Icon<[0, 0, 640, 512], 640, 512>;
declare const Cloud: Icon<[0, 0, 640, 512], 640, 512>;
declare const Cocktail: Icon<[0, 0, 576, 512], 576, 512>;
declare const CodeBranch: Icon<[0, 0, 384, 512], 384, 512>;
declare const Code: Icon<[0, 0, 640, 512], 640, 512>;
declare const Coffee: Icon<[0, 0, 640, 512], 640, 512>;
declare const Cog: Icon<[0, 0, 512, 512], 512, 512>;
declare const Cogs: Icon<[0, 0, 640, 512], 640, 512>;
declare const Coins: Icon<[0, 0, 512, 512], 512, 512>;
declare const Columns: Icon<[0, 0, 512, 512], 512, 512>;
declare const CommentAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const CommentDollar: Icon<[0, 0, 512, 512], 512, 512>;
declare const CommentDots: Icon<[0, 0, 512, 512], 512, 512>;
declare const CommentMedical: Icon<[0, 0, 512, 512], 512, 512>;
declare const CommentSlash: Icon<[0, 0, 640, 512], 640, 512>;
declare const Comment: Icon<[0, 0, 512, 512], 512, 512>;
declare const CommentsDollar: Icon<[0, 0, 576, 512], 576, 512>;
declare const Comments: Icon<[0, 0, 576, 512], 576, 512>;
declare const CompactDisc: Icon<[0, 0, 496, 512], 496, 512>;
declare const Compass: Icon<[0, 0, 496, 512], 496, 512>;
declare const CompressAlt: Icon<[0, 0, 448, 512], 448, 512>;
declare const CompressArrowsAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const Compress: Icon<[0, 0, 448, 512], 448, 512>;
declare const ConciergeBell: Icon<[0, 0, 512, 512], 512, 512>;
declare const CookieBite: Icon<[0, 0, 512, 512], 512, 512>;
declare const Cookie: Icon<[0, 0, 512, 512], 512, 512>;
declare const Copy: Icon<[0, 0, 448, 512], 448, 512>;
declare const Copyright: Icon<[0, 0, 512, 512], 512, 512>;
declare const Couch: Icon<[0, 0, 640, 512], 640, 512>;
declare const CreditCard: Icon<[0, 0, 576, 512], 576, 512>;
declare const CropAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const Crop: Icon<[0, 0, 512, 512], 512, 512>;
declare const Cross: Icon<[0, 0, 384, 512], 384, 512>;
declare const Crosshairs: Icon<[0, 0, 512, 512], 512, 512>;
declare const Crow: Icon<[0, 0, 640, 512], 640, 512>;
declare const Crown: Icon<[0, 0, 640, 512], 640, 512>;
declare const Crutch: Icon<[0, 0, 512, 512], 512, 512>;
declare const Cube: Icon<[0, 0, 512, 512], 512, 512>;
declare const Cubes: Icon<[0, 0, 512, 512], 512, 512>;
declare const Cut: Icon<[0, 0, 448, 512], 448, 512>;
declare const Database: Icon<[0, 0, 448, 512], 448, 512>;
declare const Deaf: Icon<[0, 0, 512, 512], 512, 512>;
declare const Democrat: Icon<[0, 0, 640, 512], 640, 512>;
declare const Desktop: Icon<[0, 0, 576, 512], 576, 512>;
declare const Dharmachakra: Icon<[0, 0, 512, 512], 512, 512>;
declare const Diagnoses: Icon<[0, 0, 640, 512], 640, 512>;
declare const DiceD20: Icon<[0, 0, 480, 512], 480, 512>;
declare const DiceD6: Icon<[0, 0, 448, 512], 448, 512>;
declare const DiceFive: Icon<[0, 0, 448, 512], 448, 512>;
declare const DiceFour: Icon<[0, 0, 448, 512], 448, 512>;
declare const DiceOne: Icon<[0, 0, 448, 512], 448, 512>;
declare const DiceSix: Icon<[0, 0, 448, 512], 448, 512>;
declare const DiceThree: Icon<[0, 0, 448, 512], 448, 512>;
declare const DiceTwo: Icon<[0, 0, 448, 512], 448, 512>;
declare const Dice: Icon<[0, 0, 640, 512], 640, 512>;
declare const DigitalTachograph: Icon<[0, 0, 640, 512], 640, 512>;
declare const Directions: Icon<[0, 0, 512, 512], 512, 512>;
declare const Divide: Icon<[0, 0, 448, 512], 448, 512>;
declare const Dizzy: Icon<[0, 0, 496, 512], 496, 512>;
declare const Dna: Icon<[0, 0, 448, 512], 448, 512>;
declare const Dog: Icon<[0, 0, 576, 512], 576, 512>;
declare const DollarSign: Icon<[0, 0, 288, 512], 288, 512>;
declare const DollyFlatbed: Icon<[0, 0, 640, 512], 640, 512>;
declare const Dolly: Icon<[0, 0, 576, 512], 576, 512>;
declare const Donate: Icon<[0, 0, 512, 512], 512, 512>;
declare const DoorClosed: Icon<[0, 0, 640, 512], 640, 512>;
declare const DoorOpen: Icon<[0, 0, 640, 512], 640, 512>;
declare const DotCircle: Icon<[0, 0, 512, 512], 512, 512>;
declare const Dove: Icon<[0, 0, 512, 512], 512, 512>;
declare const Download: Icon<[0, 0, 512, 512], 512, 512>;
declare const DraftingCompass: Icon<[0, 0, 512, 512], 512, 512>;
declare const Dragon: Icon<[0, 0, 640, 512], 640, 512>;
declare const DrawPolygon: Icon<[0, 0, 448, 512], 448, 512>;
declare const DrumSteelpan: Icon<[0, 0, 576, 512], 576, 512>;
declare const Drum: Icon<[0, 0, 512, 512], 512, 512>;
declare const DrumstickBite: Icon<[0, 0, 512, 512], 512, 512>;
declare const Dumbbell: Icon<[0, 0, 640, 512], 640, 512>;
declare const DumpsterFire: Icon<[0, 0, 640, 512], 640, 512>;
declare const Dumpster: Icon<[0, 0, 576, 512], 576, 512>;
declare const Dungeon: Icon<[0, 0, 512, 512], 512, 512>;
declare const Edit: Icon<[0, 0, 576, 512], 576, 512>;
declare const Egg: Icon<[0, 0, 384, 512], 384, 512>;
declare const Eject: Icon<[0, 0, 448, 512], 448, 512>;
declare const EllipsisH: Icon<[0, 0, 512, 512], 512, 512>;
declare const EllipsisV: Icon<[0, 0, 192, 512], 192, 512>;
declare const EnvelopeOpenText: Icon<[0, 0, 512, 512], 512, 512>;
declare const EnvelopeOpen: Icon<[0, 0, 512, 512], 512, 512>;
declare const EnvelopeSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Envelope: Icon<[0, 0, 512, 512], 512, 512>;
declare const Equals: Icon<[0, 0, 448, 512], 448, 512>;
declare const Eraser: Icon<[0, 0, 512, 512], 512, 512>;
declare const Ethernet: Icon<[0, 0, 512, 512], 512, 512>;
declare const EuroSign: Icon<[0, 0, 320, 512], 320, 512>;
declare const ExchangeAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const ExclamationCircle: Icon<[0, 0, 512, 512], 512, 512>;
declare const ExclamationTriangle: Icon<[0, 0, 576, 512], 576, 512>;
declare const Exclamation: Icon<[0, 0, 192, 512], 192, 512>;
declare const ExpandAlt: Icon<[0, 0, 448, 512], 448, 512>;
declare const ExpandArrowsAlt: Icon<[0, 0, 448, 512], 448, 512>;
declare const Expand: Icon<[0, 0, 448, 512], 448, 512>;
declare const ExternalLinkAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const ExternalLinkSquareAlt: Icon<[0, 0, 448, 512], 448, 512>;
declare const EyeDropper: Icon<[0, 0, 512, 512], 512, 512>;
declare const EyeSlash: Icon<[0, 0, 640, 512], 640, 512>;
declare const Eye: Icon<[0, 0, 576, 512], 576, 512>;
declare const Fan: Icon<[0, 0, 512, 512], 512, 512>;
declare const FastBackward: Icon<[0, 0, 512, 512], 512, 512>;
declare const FastForward: Icon<[0, 0, 512, 512], 512, 512>;
declare const Fax: Icon<[0, 0, 512, 512], 512, 512>;
declare const FeatherAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const Feather: Icon<[0, 0, 512, 512], 512, 512>;
declare const Female: Icon<[0, 0, 256, 512], 256, 512>;
declare const FighterJet: Icon<[0, 0, 640, 512], 640, 512>;
declare const FileAlt: Icon<[0, 0, 384, 512], 384, 512>;
declare const FileArchive: Icon<[0, 0, 384, 512], 384, 512>;
declare const FileAudio: Icon<[0, 0, 384, 512], 384, 512>;
declare const FileCode: Icon<[0, 0, 384, 512], 384, 512>;
declare const FileContract: Icon<[0, 0, 384, 512], 384, 512>;
declare const FileCsv: Icon<[0, 0, 384, 512], 384, 512>;
declare const FileDownload: Icon<[0, 0, 384, 512], 384, 512>;
declare const FileExcel: Icon<[0, 0, 384, 512], 384, 512>;
declare const FileExport: Icon<[0, 0, 576, 512], 576, 512>;
declare const FileImage: Icon<[0, 0, 384, 512], 384, 512>;
declare const FileImport: Icon<[0, 0, 512, 512], 512, 512>;
declare const FileInvoiceDollar: Icon<[0, 0, 384, 512], 384, 512>;
declare const FileInvoice: Icon<[0, 0, 384, 512], 384, 512>;
declare const FileMedicalAlt: Icon<[0, 0, 448, 512], 448, 512>;
declare const FileMedical: Icon<[0, 0, 384, 512], 384, 512>;
declare const FilePdf: Icon<[0, 0, 384, 512], 384, 512>;
declare const FilePowerpoint: Icon<[0, 0, 384, 512], 384, 512>;
declare const FilePrescription: Icon<[0, 0, 384, 512], 384, 512>;
declare const FileSignature: Icon<[0, 0, 576, 512], 576, 512>;
declare const FileUpload: Icon<[0, 0, 384, 512], 384, 512>;
declare const FileVideo: Icon<[0, 0, 384, 512], 384, 512>;
declare const FileWord: Icon<[0, 0, 384, 512], 384, 512>;
declare const File: Icon<[0, 0, 384, 512], 384, 512>;
declare const FillDrip: Icon<[0, 0, 576, 512], 576, 512>;
declare const Fill: Icon<[0, 0, 512, 512], 512, 512>;
declare const Film: Icon<[0, 0, 512, 512], 512, 512>;
declare const Filter: Icon<[0, 0, 512, 512], 512, 512>;
declare const Fingerprint: Icon<[0, 0, 512, 512], 512, 512>;
declare const FireAlt: Icon<[0, 0, 448, 512], 448, 512>;
declare const FireExtinguisher: Icon<[0, 0, 448, 512], 448, 512>;
declare const Fire: Icon<[0, 0, 384, 512], 384, 512>;
declare const FirstAid: Icon<[0, 0, 576, 512], 576, 512>;
declare const Fish: Icon<[0, 0, 576, 512], 576, 512>;
declare const FistRaised: Icon<[0, 0, 384, 512], 384, 512>;
declare const FlagCheckered: Icon<[0, 0, 512, 512], 512, 512>;
declare const FlagUsa: Icon<[0, 0, 512, 512], 512, 512>;
declare const Flag: Icon<[0, 0, 512, 512], 512, 512>;
declare const Flask: Icon<[0, 0, 448, 512], 448, 512>;
declare const Flushed: Icon<[0, 0, 496, 512], 496, 512>;
declare const FolderMinus: Icon<[0, 0, 512, 512], 512, 512>;
declare const FolderOpen: Icon<[0, 0, 576, 512], 576, 512>;
declare const FolderPlus: Icon<[0, 0, 512, 512], 512, 512>;
declare const Folder: Icon<[0, 0, 512, 512], 512, 512>;
declare const FontAwesomeLogoFull: Icon<[0, 0, 3992, 512], 3992, 512>;
declare const Font: Icon<[0, 0, 448, 512], 448, 512>;
declare const FootballBall: Icon<[0, 0, 496, 512], 496, 512>;
declare const Forward: Icon<[0, 0, 512, 512], 512, 512>;
declare const Frog: Icon<[0, 0, 576, 512], 576, 512>;
declare const FrownOpen: Icon<[0, 0, 496, 512], 496, 512>;
declare const Frown: Icon<[0, 0, 496, 512], 496, 512>;
declare const FunnelDollar: Icon<[0, 0, 640, 512], 640, 512>;
declare const Futbol: Icon<[0, 0, 512, 512], 512, 512>;
declare const Gamepad: Icon<[0, 0, 640, 512], 640, 512>;
declare const GasPump: Icon<[0, 0, 512, 512], 512, 512>;
declare const Gavel: Icon<[0, 0, 512, 512], 512, 512>;
declare const Gem: Icon<[0, 0, 576, 512], 576, 512>;
declare const Genderless: Icon<[0, 0, 288, 512], 288, 512>;
declare const Ghost: Icon<[0, 0, 384, 512], 384, 512>;
declare const Gift: Icon<[0, 0, 512, 512], 512, 512>;
declare const Gifts: Icon<[0, 0, 640, 512], 640, 512>;
declare const GlassCheers: Icon<[0, 0, 640, 512], 640, 512>;
declare const GlassMartiniAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const GlassMartini: Icon<[0, 0, 512, 512], 512, 512>;
declare const GlassWhiskey: Icon<[0, 0, 512, 512], 512, 512>;
declare const Glasses: Icon<[0, 0, 576, 512], 576, 512>;
declare const GlobeAfrica: Icon<[0, 0, 496, 512], 496, 512>;
declare const GlobeAmericas: Icon<[0, 0, 496, 512], 496, 512>;
declare const GlobeAsia: Icon<[0, 0, 496, 512], 496, 512>;
declare const GlobeEurope: Icon<[0, 0, 496, 512], 496, 512>;
declare const Globe: Icon<[0, 0, 496, 512], 496, 512>;
declare const GolfBall: Icon<[0, 0, 416, 512], 416, 512>;
declare const Gopuram: Icon<[0, 0, 512, 512], 512, 512>;
declare const GraduationCap: Icon<[0, 0, 640, 512], 640, 512>;
declare const GreaterThanEqual: Icon<[0, 0, 448, 512], 448, 512>;
declare const GreaterThan: Icon<[0, 0, 384, 512], 384, 512>;
declare const Grimace: Icon<[0, 0, 496, 512], 496, 512>;
declare const GrinAlt: Icon<[0, 0, 496, 512], 496, 512>;
declare const GrinBeamSweat: Icon<[0, 0, 504, 512], 504, 512>;
declare const GrinBeam: Icon<[0, 0, 496, 512], 496, 512>;
declare const GrinHearts: Icon<[0, 0, 496, 512], 496, 512>;
declare const GrinSquintTears: Icon<[0, 0, 512, 512], 512, 512>;
declare const GrinSquint: Icon<[0, 0, 496, 512], 496, 512>;
declare const GrinStars: Icon<[0, 0, 496, 512], 496, 512>;
declare const GrinTears: Icon<[0, 0, 640, 512], 640, 512>;
declare const GrinTongueSquint: Icon<[0, 0, 496, 512], 496, 512>;
declare const GrinTongueWink: Icon<[0, 0, 496, 512], 496, 512>;
declare const GrinTongue: Icon<[0, 0, 496, 512], 496, 512>;
declare const GrinWink: Icon<[0, 0, 496, 512], 496, 512>;
declare const Grin: Icon<[0, 0, 496, 512], 496, 512>;
declare const GripHorizontal: Icon<[0, 0, 448, 512], 448, 512>;
declare const GripLinesVertical: Icon<[0, 0, 256, 512], 256, 512>;
declare const GripLines: Icon<[0, 0, 512, 512], 512, 512>;
declare const GripVertical: Icon<[0, 0, 320, 512], 320, 512>;
declare const Guitar: Icon<[0, 0, 512, 512], 512, 512>;
declare const HSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Hamburger: Icon<[0, 0, 512, 512], 512, 512>;
declare const Hammer: Icon<[0, 0, 576, 512], 576, 512>;
declare const Hamsa: Icon<[0, 0, 512, 512], 512, 512>;
declare const HandHoldingHeart: Icon<[0, 0, 576, 512], 576, 512>;
declare const HandHoldingUsd: Icon<[0, 0, 576, 512], 576, 512>;
declare const HandHolding: Icon<[0, 0, 576, 512], 576, 512>;
declare const HandLizard: Icon<[0, 0, 576, 512], 576, 512>;
declare const HandMiddleFinger: Icon<[0, 0, 512, 512], 512, 512>;
declare const HandPaper: Icon<[0, 0, 448, 512], 448, 512>;
declare const HandPeace: Icon<[0, 0, 448, 512], 448, 512>;
declare const HandPointDown: Icon<[0, 0, 384, 512], 384, 512>;
declare const HandPointLeft: Icon<[0, 0, 512, 512], 512, 512>;
declare const HandPointRight: Icon<[0, 0, 512, 512], 512, 512>;
declare const HandPointUp: Icon<[0, 0, 384, 512], 384, 512>;
declare const HandPointer: Icon<[0, 0, 448, 512], 448, 512>;
declare const HandRock: Icon<[0, 0, 512, 512], 512, 512>;
declare const HandScissors: Icon<[0, 0, 512, 512], 512, 512>;
declare const HandSpock: Icon<[0, 0, 512, 512], 512, 512>;
declare const HandsHelping: Icon<[0, 0, 640, 512], 640, 512>;
declare const Hands: Icon<[0, 0, 640, 512], 640, 512>;
declare const Handshake: Icon<[0, 0, 640, 512], 640, 512>;
declare const Hanukiah: Icon<[0, 0, 640, 512], 640, 512>;
declare const HardHat: Icon<[0, 0, 512, 512], 512, 512>;
declare const Hashtag: Icon<[0, 0, 448, 512], 448, 512>;
declare const HatCowboySide: Icon<[0, 0, 640, 512], 640, 512>;
declare const HatCowboy: Icon<[0, 0, 640, 512], 640, 512>;
declare const HatWizard: Icon<[0, 0, 512, 512], 512, 512>;
declare const Hdd: Icon<[0, 0, 576, 512], 576, 512>;
declare const Heading: Icon<[0, 0, 512, 512], 512, 512>;
declare const HeadphonesAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const Headphones: Icon<[0, 0, 512, 512], 512, 512>;
declare const Headset: Icon<[0, 0, 512, 512], 512, 512>;
declare const HeartBroken: Icon<[0, 0, 512, 512], 512, 512>;
declare const Heart: Icon<[0, 0, 512, 512], 512, 512>;
declare const Heartbeat: Icon<[0, 0, 512, 512], 512, 512>;
declare const Helicopter: Icon<[0, 0, 640, 512], 640, 512>;
declare const Highlighter: Icon<[0, 0, 544, 512], 544, 512>;
declare const Hiking: Icon<[0, 0, 384, 512], 384, 512>;
declare const Hippo: Icon<[0, 0, 640, 512], 640, 512>;
declare const History: Icon<[0, 0, 512, 512], 512, 512>;
declare const HockeyPuck: Icon<[0, 0, 512, 512], 512, 512>;
declare const HollyBerry: Icon<[0, 0, 448, 512], 448, 512>;
declare const Home: Icon<[0, 0, 576, 512], 576, 512>;
declare const HorseHead: Icon<[0, 0, 512, 512], 512, 512>;
declare const Horse: Icon<[0, 0, 576, 512], 576, 512>;
declare const HospitalAlt: Icon<[0, 0, 576, 512], 576, 512>;
declare const HospitalSymbol: Icon<[0, 0, 512, 512], 512, 512>;
declare const Hospital: Icon<[0, 0, 448, 512], 448, 512>;
declare const HotTub: Icon<[0, 0, 512, 512], 512, 512>;
declare const Hotdog: Icon<[0, 0, 512, 512], 512, 512>;
declare const Hotel: Icon<[0, 0, 576, 512], 576, 512>;
declare const HourglassEnd: Icon<[0, 0, 384, 512], 384, 512>;
declare const HourglassHalf: Icon<[0, 0, 384, 512], 384, 512>;
declare const HourglassStart: Icon<[0, 0, 384, 512], 384, 512>;
declare const Hourglass: Icon<[0, 0, 384, 512], 384, 512>;
declare const HouseDamage: Icon<[0, 0, 576, 512], 576, 512>;
declare const Hryvnia: Icon<[0, 0, 384, 512], 384, 512>;
declare const ICursor: Icon<[0, 0, 256, 512], 256, 512>;
declare const IceCream: Icon<[0, 0, 448, 512], 448, 512>;
declare const Icicles: Icon<[0, 0, 512, 512], 512, 512>;
declare const Icons: Icon<[0, 0, 512, 512], 512, 512>;
declare const IdBadge: Icon<[0, 0, 384, 512], 384, 512>;
declare const IdCardAlt: Icon<[0, 0, 576, 512], 576, 512>;
declare const IdCard: Icon<[0, 0, 576, 512], 576, 512>;
declare const Igloo: Icon<[0, 0, 576, 512], 576, 512>;
declare const Image: Icon<[0, 0, 512, 512], 512, 512>;
declare const Images: Icon<[0, 0, 576, 512], 576, 512>;
declare const Inbox: Icon<[0, 0, 576, 512], 576, 512>;
declare const Indent: Icon<[0, 0, 448, 512], 448, 512>;
declare const Industry: Icon<[0, 0, 512, 512], 512, 512>;
declare const Infinity: Icon<[0, 0, 640, 512], 640, 512>;
declare const InfoCircle: Icon<[0, 0, 512, 512], 512, 512>;
declare const Info: Icon<[0, 0, 192, 512], 192, 512>;
declare const Italic: Icon<[0, 0, 320, 512], 320, 512>;
declare const Jedi: Icon<[0, 0, 576, 512], 576, 512>;
declare const Joint: Icon<[0, 0, 640, 512], 640, 512>;
declare const JournalWhills: Icon<[0, 0, 448, 512], 448, 512>;
declare const Kaaba: Icon<[0, 0, 576, 512], 576, 512>;
declare const Key: Icon<[0, 0, 512, 512], 512, 512>;
declare const Keyboard: Icon<[0, 0, 576, 512], 576, 512>;
declare const Khanda: Icon<[0, 0, 512, 512], 512, 512>;
declare const KissBeam: Icon<[0, 0, 496, 512], 496, 512>;
declare const KissWinkHeart: Icon<[0, 0, 504, 512], 504, 512>;
declare const Kiss: Icon<[0, 0, 496, 512], 496, 512>;
declare const KiwiBird: Icon<[0, 0, 576, 512], 576, 512>;
declare const Landmark: Icon<[0, 0, 512, 512], 512, 512>;
declare const Language: Icon<[0, 0, 640, 512], 640, 512>;
declare const LaptopCode: Icon<[0, 0, 640, 512], 640, 512>;
declare const LaptopMedical: Icon<[0, 0, 640, 512], 640, 512>;
declare const Laptop: Icon<[0, 0, 640, 512], 640, 512>;
declare const LaughBeam: Icon<[0, 0, 496, 512], 496, 512>;
declare const LaughSquint: Icon<[0, 0, 496, 512], 496, 512>;
declare const LaughWink: Icon<[0, 0, 496, 512], 496, 512>;
declare const Laugh: Icon<[0, 0, 496, 512], 496, 512>;
declare const LayerGroup: Icon<[0, 0, 512, 512], 512, 512>;
declare const Leaf: Icon<[0, 0, 576, 512], 576, 512>;
declare const Lemon: Icon<[0, 0, 512, 512], 512, 512>;
declare const LessThanEqual: Icon<[0, 0, 448, 512], 448, 512>;
declare const LessThan: Icon<[0, 0, 384, 512], 384, 512>;
declare const LevelDownAlt: Icon<[0, 0, 320, 512], 320, 512>;
declare const LevelUpAlt: Icon<[0, 0, 320, 512], 320, 512>;
declare const LifeRing: Icon<[0, 0, 512, 512], 512, 512>;
declare const Lightbulb: Icon<[0, 0, 352, 512], 352, 512>;
declare const Link: Icon<[0, 0, 512, 512], 512, 512>;
declare const LiraSign: Icon<[0, 0, 384, 512], 384, 512>;
declare const ListAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const ListOl: Icon<[0, 0, 512, 512], 512, 512>;
declare const ListUl: Icon<[0, 0, 512, 512], 512, 512>;
declare const List: Icon<[0, 0, 512, 512], 512, 512>;
declare const LocationArrow: Icon<[0, 0, 512, 512], 512, 512>;
declare const LockOpen: Icon<[0, 0, 576, 512], 576, 512>;
declare const Lock: Icon<[0, 0, 448, 512], 448, 512>;
declare const LongArrowAltDown: Icon<[0, 0, 256, 512], 256, 512>;
declare const LongArrowAltLeft: Icon<[0, 0, 448, 512], 448, 512>;
declare const LongArrowAltRight: Icon<[0, 0, 448, 512], 448, 512>;
declare const LongArrowAltUp: Icon<[0, 0, 256, 512], 256, 512>;
declare const LowVision: Icon<[0, 0, 576, 512], 576, 512>;
declare const LuggageCart: Icon<[0, 0, 640, 512], 640, 512>;
declare const Magic: Icon<[0, 0, 512, 512], 512, 512>;
declare const Magnet: Icon<[0, 0, 512, 512], 512, 512>;
declare const MailBulk: Icon<[0, 0, 576, 512], 576, 512>;
declare const Male: Icon<[0, 0, 192, 512], 192, 512>;
declare const MapMarkedAlt: Icon<[0, 0, 576, 512], 576, 512>;
declare const MapMarked: Icon<[0, 0, 576, 512], 576, 512>;
declare const MapMarkerAlt: Icon<[0, 0, 384, 512], 384, 512>;
declare const MapMarker: Icon<[0, 0, 384, 512], 384, 512>;
declare const MapPin: Icon<[0, 0, 288, 512], 288, 512>;
declare const MapSigns: Icon<[0, 0, 512, 512], 512, 512>;
declare const Map: Icon<[0, 0, 576, 512], 576, 512>;
declare const Marker: Icon<[0, 0, 512, 512], 512, 512>;
declare const MarsDouble: Icon<[0, 0, 512, 512], 512, 512>;
declare const MarsStrokeH: Icon<[0, 0, 480, 512], 480, 512>;
declare const MarsStrokeV: Icon<[0, 0, 288, 512], 288, 512>;
declare const MarsStroke: Icon<[0, 0, 384, 512], 384, 512>;
declare const Mars: Icon<[0, 0, 384, 512], 384, 512>;
declare const Mask: Icon<[0, 0, 640, 512], 640, 512>;
declare const Medal: Icon<[0, 0, 512, 512], 512, 512>;
declare const Medkit: Icon<[0, 0, 512, 512], 512, 512>;
declare const MehBlank: Icon<[0, 0, 496, 512], 496, 512>;
declare const MehRollingEyes: Icon<[0, 0, 496, 512], 496, 512>;
declare const Meh: Icon<[0, 0, 496, 512], 496, 512>;
declare const Memory: Icon<[0, 0, 640, 512], 640, 512>;
declare const Menorah: Icon<[0, 0, 640, 512], 640, 512>;
declare const Mercury: Icon<[0, 0, 288, 512], 288, 512>;
declare const Meteor: Icon<[0, 0, 512, 512], 512, 512>;
declare const Microchip: Icon<[0, 0, 512, 512], 512, 512>;
declare const MicrophoneAltSlash: Icon<[0, 0, 640, 512], 640, 512>;
declare const MicrophoneAlt: Icon<[0, 0, 352, 512], 352, 512>;
declare const MicrophoneSlash: Icon<[0, 0, 640, 512], 640, 512>;
declare const Microphone: Icon<[0, 0, 352, 512], 352, 512>;
declare const Microscope: Icon<[0, 0, 512, 512], 512, 512>;
declare const MinusCircle: Icon<[0, 0, 512, 512], 512, 512>;
declare const MinusSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Minus: Icon<[0, 0, 448, 512], 448, 512>;
declare const Mitten: Icon<[0, 0, 448, 512], 448, 512>;
declare const MobileAlt: Icon<[0, 0, 320, 512], 320, 512>;
declare const Mobile: Icon<[0, 0, 320, 512], 320, 512>;
declare const MoneyBillAlt: Icon<[0, 0, 640, 512], 640, 512>;
declare const MoneyBillWaveAlt: Icon<[0, 0, 640, 512], 640, 512>;
declare const MoneyBillWave: Icon<[0, 0, 640, 512], 640, 512>;
declare const MoneyBill: Icon<[0, 0, 640, 512], 640, 512>;
declare const MoneyCheckAlt: Icon<[0, 0, 640, 512], 640, 512>;
declare const MoneyCheck: Icon<[0, 0, 640, 512], 640, 512>;
declare const Monument: Icon<[0, 0, 384, 512], 384, 512>;
declare const Moon: Icon<[0, 0, 512, 512], 512, 512>;
declare const MortarPestle: Icon<[0, 0, 512, 512], 512, 512>;
declare const Mosque: Icon<[0, 0, 640, 512], 640, 512>;
declare const Motorcycle: Icon<[0, 0, 640, 512], 640, 512>;
declare const Mountain: Icon<[0, 0, 640, 512], 640, 512>;
declare const MousePointer: Icon<[0, 0, 320, 512], 320, 512>;
declare const Mouse: Icon<[0, 0, 384, 512], 384, 512>;
declare const MugHot: Icon<[0, 0, 512, 512], 512, 512>;
declare const Music: Icon<[0, 0, 512, 512], 512, 512>;
declare const NetworkWired: Icon<[0, 0, 640, 512], 640, 512>;
declare const Neuter: Icon<[0, 0, 288, 512], 288, 512>;
declare const Newspaper: Icon<[0, 0, 576, 512], 576, 512>;
declare const NotEqual: Icon<[0, 0, 448, 512], 448, 512>;
declare const NotesMedical: Icon<[0, 0, 384, 512], 384, 512>;
declare const ObjectGroup: Icon<[0, 0, 512, 512], 512, 512>;
declare const ObjectUngroup: Icon<[0, 0, 576, 512], 576, 512>;
declare const OilCan: Icon<[0, 0, 640, 512], 640, 512>;
declare const Om: Icon<[0, 0, 512, 512], 512, 512>;
declare const Otter: Icon<[0, 0, 640, 512], 640, 512>;
declare const Outdent: Icon<[0, 0, 448, 512], 448, 512>;
declare const Pager: Icon<[0, 0, 512, 512], 512, 512>;
declare const PaintBrush: Icon<[0, 0, 512, 512], 512, 512>;
declare const PaintRoller: Icon<[0, 0, 512, 512], 512, 512>;
declare const Palette: Icon<[0, 0, 512, 512], 512, 512>;
declare const Pallet: Icon<[0, 0, 640, 512], 640, 512>;
declare const PaperPlane: Icon<[0, 0, 512, 512], 512, 512>;
declare const Paperclip: Icon<[0, 0, 448, 512], 448, 512>;
declare const ParachuteBox: Icon<[0, 0, 512, 512], 512, 512>;
declare const Paragraph: Icon<[0, 0, 448, 512], 448, 512>;
declare const Parking: Icon<[0, 0, 448, 512], 448, 512>;
declare const Passport: Icon<[0, 0, 448, 512], 448, 512>;
declare const Pastafarianism: Icon<[0, 0, 640, 512], 640, 512>;
declare const Paste: Icon<[0, 0, 448, 512], 448, 512>;
declare const PauseCircle: Icon<[0, 0, 512, 512], 512, 512>;
declare const Pause: Icon<[0, 0, 448, 512], 448, 512>;
declare const Paw: Icon<[0, 0, 512, 512], 512, 512>;
declare const Peace: Icon<[0, 0, 496, 512], 496, 512>;
declare const PenAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const PenFancy: Icon<[0, 0, 512, 512], 512, 512>;
declare const PenNib: Icon<[0, 0, 512, 512], 512, 512>;
declare const PenSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Pen: Icon<[0, 0, 512, 512], 512, 512>;
declare const PencilAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const PencilRuler: Icon<[0, 0, 512, 512], 512, 512>;
declare const PeopleCarry: Icon<[0, 0, 640, 512], 640, 512>;
declare const PepperHot: Icon<[0, 0, 512, 512], 512, 512>;
declare const Percent: Icon<[0, 0, 448, 512], 448, 512>;
declare const Percentage: Icon<[0, 0, 384, 512], 384, 512>;
declare const PersonBooth: Icon<[0, 0, 576, 512], 576, 512>;
declare const PhoneAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const PhoneSlash: Icon<[0, 0, 640, 512], 640, 512>;
declare const PhoneSquareAlt: Icon<[0, 0, 448, 512], 448, 512>;
declare const PhoneSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const PhoneVolume: Icon<[0, 0, 384, 512], 384, 512>;
declare const Phone: Icon<[0, 0, 512, 512], 512, 512>;
declare const PhotoVideo: Icon<[0, 0, 640, 512], 640, 512>;
declare const PiggyBank: Icon<[0, 0, 576, 512], 576, 512>;
declare const Pills: Icon<[0, 0, 576, 512], 576, 512>;
declare const PizzaSlice: Icon<[0, 0, 512, 512], 512, 512>;
declare const PlaceOfWorship: Icon<[0, 0, 640, 512], 640, 512>;
declare const PlaneArrival: Icon<[0, 0, 640, 512], 640, 512>;
declare const PlaneDeparture: Icon<[0, 0, 640, 512], 640, 512>;
declare const Plane: Icon<[0, 0, 576, 512], 576, 512>;
declare const PlayCircle: Icon<[0, 0, 512, 512], 512, 512>;
declare const Play: Icon<[0, 0, 448, 512], 448, 512>;
declare const Plug: Icon<[0, 0, 384, 512], 384, 512>;
declare const PlusCircle: Icon<[0, 0, 512, 512], 512, 512>;
declare const PlusSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Plus: Icon<[0, 0, 448, 512], 448, 512>;
declare const Podcast: Icon<[0, 0, 448, 512], 448, 512>;
declare const PollH: Icon<[0, 0, 448, 512], 448, 512>;
declare const Poll: Icon<[0, 0, 448, 512], 448, 512>;
declare const PooStorm: Icon<[0, 0, 448, 512], 448, 512>;
declare const Poo: Icon<[0, 0, 512, 512], 512, 512>;
declare const Poop: Icon<[0, 0, 512, 512], 512, 512>;
declare const Portrait: Icon<[0, 0, 384, 512], 384, 512>;
declare const PoundSign: Icon<[0, 0, 320, 512], 320, 512>;
declare const PowerOff: Icon<[0, 0, 512, 512], 512, 512>;
declare const Pray: Icon<[0, 0, 384, 512], 384, 512>;
declare const PrayingHands: Icon<[0, 0, 640, 512], 640, 512>;
declare const PrescriptionBottleAlt: Icon<[0, 0, 384, 512], 384, 512>;
declare const PrescriptionBottle: Icon<[0, 0, 384, 512], 384, 512>;
declare const Prescription: Icon<[0, 0, 384, 512], 384, 512>;
declare const Print: Icon<[0, 0, 512, 512], 512, 512>;
declare const Procedures: Icon<[0, 0, 640, 512], 640, 512>;
declare const ProjectDiagram: Icon<[0, 0, 640, 512], 640, 512>;
declare const PuzzlePiece: Icon<[0, 0, 576, 512], 576, 512>;
declare const Qrcode: Icon<[0, 0, 448, 512], 448, 512>;
declare const QuestionCircle: Icon<[0, 0, 512, 512], 512, 512>;
declare const Question: Icon<[0, 0, 384, 512], 384, 512>;
declare const Quidditch: Icon<[0, 0, 640, 512], 640, 512>;
declare const QuoteLeft: Icon<[0, 0, 512, 512], 512, 512>;
declare const QuoteRight: Icon<[0, 0, 512, 512], 512, 512>;
declare const Quran: Icon<[0, 0, 448, 512], 448, 512>;
declare const RadiationAlt: Icon<[0, 0, 496, 512], 496, 512>;
declare const Radiation: Icon<[0, 0, 496, 512], 496, 512>;
declare const Rainbow: Icon<[0, 0, 576, 512], 576, 512>;
declare const Random: Icon<[0, 0, 512, 512], 512, 512>;
declare const Receipt: Icon<[0, 0, 384, 512], 384, 512>;
declare const RecordVinyl: Icon<[0, 0, 512, 512], 512, 512>;
declare const Recycle: Icon<[0, 0, 512, 512], 512, 512>;
declare const RedoAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const Redo: Icon<[0, 0, 512, 512], 512, 512>;
declare const Registered: Icon<[0, 0, 512, 512], 512, 512>;
declare const RemoveFormat: Icon<[0, 0, 640, 512], 640, 512>;
declare const ReplyAll: Icon<[0, 0, 576, 512], 576, 512>;
declare const Reply: Icon<[0, 0, 512, 512], 512, 512>;
declare const Republican: Icon<[0, 0, 640, 512], 640, 512>;
declare const Restroom: Icon<[0, 0, 640, 512], 640, 512>;
declare const Retweet: Icon<[0, 0, 640, 512], 640, 512>;
declare const Ribbon: Icon<[0, 0, 448, 512], 448, 512>;
declare const Ring: Icon<[0, 0, 512, 512], 512, 512>;
declare const Road: Icon<[0, 0, 576, 512], 576, 512>;
declare const Robot: Icon<[0, 0, 640, 512], 640, 512>;
declare const Rocket: Icon<[0, 0, 512, 512], 512, 512>;
declare const Route: Icon<[0, 0, 512, 512], 512, 512>;
declare const RssSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Rss: Icon<[0, 0, 448, 512], 448, 512>;
declare const RubleSign: Icon<[0, 0, 384, 512], 384, 512>;
declare const RulerCombined: Icon<[0, 0, 512, 512], 512, 512>;
declare const RulerHorizontal: Icon<[0, 0, 576, 512], 576, 512>;
declare const RulerVertical: Icon<[0, 0, 256, 512], 256, 512>;
declare const Ruler: Icon<[0, 0, 640, 512], 640, 512>;
declare const Running: Icon<[0, 0, 416, 512], 416, 512>;
declare const RupeeSign: Icon<[0, 0, 320, 512], 320, 512>;
declare const SadCry: Icon<[0, 0, 496, 512], 496, 512>;
declare const SadTear: Icon<[0, 0, 496, 512], 496, 512>;
declare const SatelliteDish: Icon<[0, 0, 512, 512], 512, 512>;
declare const Satellite: Icon<[0, 0, 512, 512], 512, 512>;
declare const Save: Icon<[0, 0, 448, 512], 448, 512>;
declare const School: Icon<[0, 0, 640, 512], 640, 512>;
declare const Screwdriver: Icon<[0, 0, 512, 512], 512, 512>;
declare const Scroll: Icon<[0, 0, 640, 512], 640, 512>;
declare const SdCard: Icon<[0, 0, 384, 512], 384, 512>;
declare const SearchDollar: Icon<[0, 0, 512, 512], 512, 512>;
declare const SearchLocation: Icon<[0, 0, 512, 512], 512, 512>;
declare const SearchMinus: Icon<[0, 0, 512, 512], 512, 512>;
declare const SearchPlus: Icon<[0, 0, 512, 512], 512, 512>;
declare const Search: Icon<[0, 0, 512, 512], 512, 512>;
declare const Seedling: Icon<[0, 0, 512, 512], 512, 512>;
declare const Server: Icon<[0, 0, 512, 512], 512, 512>;
declare const Shapes: Icon<[0, 0, 512, 512], 512, 512>;
declare const ShareAltSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const ShareAlt: Icon<[0, 0, 448, 512], 448, 512>;
declare const ShareSquare: Icon<[0, 0, 576, 512], 576, 512>;
declare const Share: Icon<[0, 0, 512, 512], 512, 512>;
declare const ShekelSign: Icon<[0, 0, 448, 512], 448, 512>;
declare const ShieldAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const Ship: Icon<[0, 0, 640, 512], 640, 512>;
declare const ShippingFast: Icon<[0, 0, 640, 512], 640, 512>;
declare const ShoePrints: Icon<[0, 0, 640, 512], 640, 512>;
declare const ShoppingBag: Icon<[0, 0, 448, 512], 448, 512>;
declare const ShoppingBasket: Icon<[0, 0, 576, 512], 576, 512>;
declare const ShoppingCart: Icon<[0, 0, 576, 512], 576, 512>;
declare const Shower: Icon<[0, 0, 512, 512], 512, 512>;
declare const ShuttleVan: Icon<[0, 0, 640, 512], 640, 512>;
declare const SignInAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const SignLanguage: Icon<[0, 0, 448, 512], 448, 512>;
declare const SignOutAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const Sign: Icon<[0, 0, 512, 512], 512, 512>;
declare const Signal: Icon<[0, 0, 640, 512], 640, 512>;
declare const Signature: Icon<[0, 0, 640, 512], 640, 512>;
declare const SimCard: Icon<[0, 0, 384, 512], 384, 512>;
declare const Sitemap: Icon<[0, 0, 640, 512], 640, 512>;
declare const Skating: Icon<[0, 0, 448, 512], 448, 512>;
declare const SkiingNordic: Icon<[0, 0, 576, 512], 576, 512>;
declare const Skiing: Icon<[0, 0, 512, 512], 512, 512>;
declare const SkullCrossbones: Icon<[0, 0, 448, 512], 448, 512>;
declare const Skull: Icon<[0, 0, 512, 512], 512, 512>;
declare const Slash: Icon<[0, 0, 640, 512], 640, 512>;
declare const Sleigh: Icon<[0, 0, 640, 512], 640, 512>;
declare const SlidersH: Icon<[0, 0, 512, 512], 512, 512>;
declare const SmileBeam: Icon<[0, 0, 496, 512], 496, 512>;
declare const SmileWink: Icon<[0, 0, 496, 512], 496, 512>;
declare const Smile: Icon<[0, 0, 496, 512], 496, 512>;
declare const Smog: Icon<[0, 0, 640, 512], 640, 512>;
declare const SmokingBan: Icon<[0, 0, 512, 512], 512, 512>;
declare const Smoking: Icon<[0, 0, 640, 512], 640, 512>;
declare const Sms: Icon<[0, 0, 512, 512], 512, 512>;
declare const Snowboarding: Icon<[0, 0, 512, 512], 512, 512>;
declare const Snowflake: Icon<[0, 0, 448, 512], 448, 512>;
declare const Snowman: Icon<[0, 0, 512, 512], 512, 512>;
declare const Snowplow: Icon<[0, 0, 640, 512], 640, 512>;
declare const Socks: Icon<[0, 0, 512, 512], 512, 512>;
declare const SolarPanel: Icon<[0, 0, 640, 512], 640, 512>;
declare const SortAlphaDownAlt: Icon<[0, 0, 448, 512], 448, 512>;
declare const SortAlphaDown: Icon<[0, 0, 448, 512], 448, 512>;
declare const SortAlphaUpAlt: Icon<[0, 0, 448, 512], 448, 512>;
declare const SortAlphaUp: Icon<[0, 0, 448, 512], 448, 512>;
declare const SortAmountDownAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const SortAmountDown: Icon<[0, 0, 512, 512], 512, 512>;
declare const SortAmountUpAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const SortAmountUp: Icon<[0, 0, 512, 512], 512, 512>;
declare const SortDown: Icon<[0, 0, 320, 512], 320, 512>;
declare const SortNumericDownAlt: Icon<[0, 0, 448, 512], 448, 512>;
declare const SortNumericDown: Icon<[0, 0, 448, 512], 448, 512>;
declare const SortNumericUpAlt: Icon<[0, 0, 448, 512], 448, 512>;
declare const SortNumericUp: Icon<[0, 0, 448, 512], 448, 512>;
declare const SortUp: Icon<[0, 0, 320, 512], 320, 512>;
declare const Sort: Icon<[0, 0, 320, 512], 320, 512>;
declare const Spa: Icon<[0, 0, 576, 512], 576, 512>;
declare const SpaceShuttle: Icon<[0, 0, 640, 512], 640, 512>;
declare const SpellCheck: Icon<[0, 0, 576, 512], 576, 512>;
declare const Spider: Icon<[0, 0, 576, 512], 576, 512>;
declare const Spinner: Icon<[0, 0, 512, 512], 512, 512>;
declare const Splotch: Icon<[0, 0, 512, 512], 512, 512>;
declare const SprayCan: Icon<[0, 0, 512, 512], 512, 512>;
declare const SquareFull: Icon<[0, 0, 512, 512], 512, 512>;
declare const SquareRootAlt: Icon<[0, 0, 576, 512], 576, 512>;
declare const Square: Icon<[0, 0, 448, 512], 448, 512>;
declare const Stamp: Icon<[0, 0, 512, 512], 512, 512>;
declare const StarAndCrescent: Icon<[0, 0, 512, 512], 512, 512>;
declare const StarHalfAlt: Icon<[0, 0, 536, 512], 536, 512>;
declare const StarHalf: Icon<[0, 0, 576, 512], 576, 512>;
declare const StarOfDavid: Icon<[0, 0, 464, 512], 464, 512>;
declare const StarOfLife: Icon<[0, 0, 480, 512], 480, 512>;
declare const Star: Icon<[0, 0, 576, 512], 576, 512>;
declare const StepBackward: Icon<[0, 0, 448, 512], 448, 512>;
declare const StepForward: Icon<[0, 0, 448, 512], 448, 512>;
declare const Stethoscope: Icon<[0, 0, 512, 512], 512, 512>;
declare const StickyNote: Icon<[0, 0, 448, 512], 448, 512>;
declare const StopCircle: Icon<[0, 0, 512, 512], 512, 512>;
declare const Stop: Icon<[0, 0, 448, 512], 448, 512>;
declare const Stopwatch: Icon<[0, 0, 448, 512], 448, 512>;
declare const StoreAlt: Icon<[0, 0, 640, 512], 640, 512>;
declare const Store: Icon<[0, 0, 616, 512], 616, 512>;
declare const Stream: Icon<[0, 0, 512, 512], 512, 512>;
declare const StreetView: Icon<[0, 0, 512, 512], 512, 512>;
declare const Strikethrough: Icon<[0, 0, 512, 512], 512, 512>;
declare const Stroopwafel: Icon<[0, 0, 512, 512], 512, 512>;
declare const Subscript: Icon<[0, 0, 512, 512], 512, 512>;
declare const Subway: Icon<[0, 0, 448, 512], 448, 512>;
declare const SuitcaseRolling: Icon<[0, 0, 384, 512], 384, 512>;
declare const Suitcase: Icon<[0, 0, 512, 512], 512, 512>;
declare const Sun: Icon<[0, 0, 512, 512], 512, 512>;
declare const Superscript: Icon<[0, 0, 512, 512], 512, 512>;
declare const Surprise: Icon<[0, 0, 496, 512], 496, 512>;
declare const Swatchbook: Icon<[0, 0, 512, 512], 512, 512>;
declare const Swimmer: Icon<[0, 0, 640, 512], 640, 512>;
declare const SwimmingPool: Icon<[0, 0, 640, 512], 640, 512>;
declare const Synagogue: Icon<[0, 0, 640, 512], 640, 512>;
declare const SyncAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const Sync: Icon<[0, 0, 512, 512], 512, 512>;
declare const Syringe: Icon<[0, 0, 512, 512], 512, 512>;
declare const TableTennis: Icon<[0, 0, 512, 512], 512, 512>;
declare const Table: Icon<[0, 0, 512, 512], 512, 512>;
declare const TabletAlt: Icon<[0, 0, 448, 512], 448, 512>;
declare const Tablet: Icon<[0, 0, 448, 512], 448, 512>;
declare const Tablets: Icon<[0, 0, 640, 512], 640, 512>;
declare const TachometerAlt: Icon<[0, 0, 576, 512], 576, 512>;
declare const Tag: Icon<[0, 0, 512, 512], 512, 512>;
declare const Tags: Icon<[0, 0, 640, 512], 640, 512>;
declare const Tape: Icon<[0, 0, 640, 512], 640, 512>;
declare const Tasks: Icon<[0, 0, 512, 512], 512, 512>;
declare const Taxi: Icon<[0, 0, 512, 512], 512, 512>;
declare const TeethOpen: Icon<[0, 0, 640, 512], 640, 512>;
declare const Teeth: Icon<[0, 0, 640, 512], 640, 512>;
declare const TemperatureHigh: Icon<[0, 0, 512, 512], 512, 512>;
declare const TemperatureLow: Icon<[0, 0, 512, 512], 512, 512>;
declare const Tenge: Icon<[0, 0, 384, 512], 384, 512>;
declare const Terminal: Icon<[0, 0, 640, 512], 640, 512>;
declare const TextHeight: Icon<[0, 0, 576, 512], 576, 512>;
declare const TextWidth: Icon<[0, 0, 448, 512], 448, 512>;
declare const ThLarge: Icon<[0, 0, 512, 512], 512, 512>;
declare const ThList: Icon<[0, 0, 512, 512], 512, 512>;
declare const Th: Icon<[0, 0, 512, 512], 512, 512>;
declare const TheaterMasks: Icon<[0, 0, 640, 512], 640, 512>;
declare const ThermometerEmpty: Icon<[0, 0, 256, 512], 256, 512>;
declare const ThermometerFull: Icon<[0, 0, 256, 512], 256, 512>;
declare const ThermometerHalf: Icon<[0, 0, 256, 512], 256, 512>;
declare const ThermometerQuarter: Icon<[0, 0, 256, 512], 256, 512>;
declare const ThermometerThreeQuarters: Icon<[0, 0, 256, 512], 256, 512>;
declare const Thermometer: Icon<[0, 0, 512, 512], 512, 512>;
declare const ThumbsDown: Icon<[0, 0, 512, 512], 512, 512>;
declare const ThumbsUp: Icon<[0, 0, 512, 512], 512, 512>;
declare const Thumbtack: Icon<[0, 0, 384, 512], 384, 512>;
declare const TicketAlt: Icon<[0, 0, 576, 512], 576, 512>;
declare const TimesCircle: Icon<[0, 0, 512, 512], 512, 512>;
declare const Times: Icon<[0, 0, 352, 512], 352, 512>;
declare const TintSlash: Icon<[0, 0, 640, 512], 640, 512>;
declare const Tint: Icon<[0, 0, 352, 512], 352, 512>;
declare const Tired: Icon<[0, 0, 496, 512], 496, 512>;
declare const ToggleOff: Icon<[0, 0, 576, 512], 576, 512>;
declare const ToggleOn: Icon<[0, 0, 576, 512], 576, 512>;
declare const ToiletPaper: Icon<[0, 0, 576, 512], 576, 512>;
declare const Toilet: Icon<[0, 0, 384, 512], 384, 512>;
declare const Toolbox: Icon<[0, 0, 512, 512], 512, 512>;
declare const Tools: Icon<[0, 0, 512, 512], 512, 512>;
declare const Tooth: Icon<[0, 0, 448, 512], 448, 512>;
declare const Torah: Icon<[0, 0, 640, 512], 640, 512>;
declare const ToriiGate: Icon<[0, 0, 512, 512], 512, 512>;
declare const Tractor: Icon<[0, 0, 640, 512], 640, 512>;
declare const Trademark: Icon<[0, 0, 640, 512], 640, 512>;
declare const TrafficLight: Icon<[0, 0, 384, 512], 384, 512>;
declare const Trailer: Icon<[0, 0, 640, 512], 640, 512>;
declare const Train: Icon<[0, 0, 448, 512], 448, 512>;
declare const Tram: Icon<[0, 0, 512, 512], 512, 512>;
declare const TransgenderAlt: Icon<[0, 0, 480, 512], 480, 512>;
declare const Transgender: Icon<[0, 0, 384, 512], 384, 512>;
declare const TrashAlt: Icon<[0, 0, 448, 512], 448, 512>;
declare const TrashRestoreAlt: Icon<[0, 0, 448, 512], 448, 512>;
declare const TrashRestore: Icon<[0, 0, 448, 512], 448, 512>;
declare const Trash: Icon<[0, 0, 448, 512], 448, 512>;
declare const Tree: Icon<[0, 0, 384, 512], 384, 512>;
declare const Trophy: Icon<[0, 0, 576, 512], 576, 512>;
declare const TruckLoading: Icon<[0, 0, 640, 512], 640, 512>;
declare const TruckMonster: Icon<[0, 0, 640, 512], 640, 512>;
declare const TruckMoving: Icon<[0, 0, 640, 512], 640, 512>;
declare const TruckPickup: Icon<[0, 0, 640, 512], 640, 512>;
declare const Truck: Icon<[0, 0, 640, 512], 640, 512>;
declare const Tshirt: Icon<[0, 0, 640, 512], 640, 512>;
declare const Tty: Icon<[0, 0, 512, 512], 512, 512>;
declare const Tv: Icon<[0, 0, 640, 512], 640, 512>;
declare const UmbrellaBeach: Icon<[0, 0, 640, 512], 640, 512>;
declare const Umbrella: Icon<[0, 0, 576, 512], 576, 512>;
declare const Underline: Icon<[0, 0, 448, 512], 448, 512>;
declare const UndoAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const Undo: Icon<[0, 0, 512, 512], 512, 512>;
declare const UniversalAccess: Icon<[0, 0, 512, 512], 512, 512>;
declare const University: Icon<[0, 0, 512, 512], 512, 512>;
declare const Unlink: Icon<[0, 0, 512, 512], 512, 512>;
declare const UnlockAlt: Icon<[0, 0, 448, 512], 448, 512>;
declare const Unlock: Icon<[0, 0, 448, 512], 448, 512>;
declare const Upload: Icon<[0, 0, 512, 512], 512, 512>;
declare const UserAltSlash: Icon<[0, 0, 640, 512], 640, 512>;
declare const UserAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const UserAstronaut: Icon<[0, 0, 448, 512], 448, 512>;
declare const UserCheck: Icon<[0, 0, 640, 512], 640, 512>;
declare const UserCircle: Icon<[0, 0, 496, 512], 496, 512>;
declare const UserClock: Icon<[0, 0, 640, 512], 640, 512>;
declare const UserCog: Icon<[0, 0, 640, 512], 640, 512>;
declare const UserEdit: Icon<[0, 0, 640, 512], 640, 512>;
declare const UserFriends: Icon<[0, 0, 640, 512], 640, 512>;
declare const UserGraduate: Icon<[0, 0, 448, 512], 448, 512>;
declare const UserInjured: Icon<[0, 0, 448, 512], 448, 512>;
declare const UserLock: Icon<[0, 0, 640, 512], 640, 512>;
declare const UserMd: Icon<[0, 0, 448, 512], 448, 512>;
declare const UserMinus: Icon<[0, 0, 640, 512], 640, 512>;
declare const UserNinja: Icon<[0, 0, 448, 512], 448, 512>;
declare const UserNurse: Icon<[0, 0, 448, 512], 448, 512>;
declare const UserPlus: Icon<[0, 0, 640, 512], 640, 512>;
declare const UserSecret: Icon<[0, 0, 448, 512], 448, 512>;
declare const UserShield: Icon<[0, 0, 640, 512], 640, 512>;
declare const UserSlash: Icon<[0, 0, 640, 512], 640, 512>;
declare const UserTag: Icon<[0, 0, 640, 512], 640, 512>;
declare const UserTie: Icon<[0, 0, 448, 512], 448, 512>;
declare const UserTimes: Icon<[0, 0, 640, 512], 640, 512>;
declare const User: Icon<[0, 0, 448, 512], 448, 512>;
declare const UsersCog: Icon<[0, 0, 640, 512], 640, 512>;
declare const Users: Icon<[0, 0, 640, 512], 640, 512>;
declare const UtensilSpoon: Icon<[0, 0, 512, 512], 512, 512>;
declare const Utensils: Icon<[0, 0, 416, 512], 416, 512>;
declare const VectorSquare: Icon<[0, 0, 512, 512], 512, 512>;
declare const VenusDouble: Icon<[0, 0, 512, 512], 512, 512>;
declare const VenusMars: Icon<[0, 0, 576, 512], 576, 512>;
declare const Venus: Icon<[0, 0, 288, 512], 288, 512>;
declare const Vial: Icon<[0, 0, 480, 512], 480, 512>;
declare const Vials: Icon<[0, 0, 640, 512], 640, 512>;
declare const VideoSlash: Icon<[0, 0, 640, 512], 640, 512>;
declare const Video: Icon<[0, 0, 576, 512], 576, 512>;
declare const Vihara: Icon<[0, 0, 640, 512], 640, 512>;
declare const Voicemail: Icon<[0, 0, 640, 512], 640, 512>;
declare const VolleyballBall: Icon<[0, 0, 512, 512], 512, 512>;
declare const VolumeDown: Icon<[0, 0, 384, 512], 384, 512>;
declare const VolumeMute: Icon<[0, 0, 512, 512], 512, 512>;
declare const VolumeOff: Icon<[0, 0, 256, 512], 256, 512>;
declare const VolumeUp: Icon<[0, 0, 576, 512], 576, 512>;
declare const VoteYea: Icon<[0, 0, 640, 512], 640, 512>;
declare const VrCardboard: Icon<[0, 0, 640, 512], 640, 512>;
declare const Walking: Icon<[0, 0, 320, 512], 320, 512>;
declare const Wallet: Icon<[0, 0, 512, 512], 512, 512>;
declare const Warehouse: Icon<[0, 0, 640, 512], 640, 512>;
declare const Water: Icon<[0, 0, 576, 512], 576, 512>;
declare const WaveSquare: Icon<[0, 0, 640, 512], 640, 512>;
declare const WeightHanging: Icon<[0, 0, 512, 512], 512, 512>;
declare const Weight: Icon<[0, 0, 512, 512], 512, 512>;
declare const Wheelchair: Icon<[0, 0, 512, 512], 512, 512>;
declare const Wifi: Icon<[0, 0, 640, 512], 640, 512>;
declare const Wind: Icon<[0, 0, 512, 512], 512, 512>;
declare const WindowClose: Icon<[0, 0, 512, 512], 512, 512>;
declare const WindowMaximize: Icon<[0, 0, 512, 512], 512, 512>;
declare const WindowMinimize: Icon<[0, 0, 512, 512], 512, 512>;
declare const WindowRestore: Icon<[0, 0, 512, 512], 512, 512>;
declare const WineBottle: Icon<[0, 0, 512, 512], 512, 512>;
declare const WineGlassAlt: Icon<[0, 0, 288, 512], 288, 512>;
declare const WineGlass: Icon<[0, 0, 288, 512], 288, 512>;
declare const WonSign: Icon<[0, 0, 576, 512], 576, 512>;
declare const Wrench: Icon<[0, 0, 512, 512], 512, 512>;
declare const XRay: Icon<[0, 0, 640, 512], 640, 512>;
declare const YenSign: Icon<[0, 0, 384, 512], 384, 512>;
declare const YinYang: Icon<[0, 0, 496, 512], 496, 512>;

type Icons = {
    'ad': Icon<[0, 0, 512, 512], 512, 512>,
    'address-book': Icon<[0, 0, 448, 512], 448, 512>,
    'address-card': Icon<[0, 0, 576, 512], 576, 512>,
    'adjust': Icon<[0, 0, 512, 512], 512, 512>,
    'air-freshener': Icon<[0, 0, 384, 512], 384, 512>,
    'align-center': Icon<[0, 0, 448, 512], 448, 512>,
    'align-justify': Icon<[0, 0, 448, 512], 448, 512>,
    'align-left': Icon<[0, 0, 448, 512], 448, 512>,
    'align-right': Icon<[0, 0, 448, 512], 448, 512>,
    'allergies': Icon<[0, 0, 448, 512], 448, 512>,
    'ambulance': Icon<[0, 0, 640, 512], 640, 512>,
    'american-sign-language-interpreting': Icon<[0, 0, 640, 512], 640, 512>,
    'anchor': Icon<[0, 0, 576, 512], 576, 512>,
    'angle-double-down': Icon<[0, 0, 320, 512], 320, 512>,
    'angle-double-left': Icon<[0, 0, 448, 512], 448, 512>,
    'angle-double-right': Icon<[0, 0, 448, 512], 448, 512>,
    'angle-double-up': Icon<[0, 0, 320, 512], 320, 512>,
    'angle-down': Icon<[0, 0, 320, 512], 320, 512>,
    'angle-left': Icon<[0, 0, 256, 512], 256, 512>,
    'angle-right': Icon<[0, 0, 256, 512], 256, 512>,
    'angle-up': Icon<[0, 0, 320, 512], 320, 512>,
    'angry': Icon<[0, 0, 496, 512], 496, 512>,
    'ankh': Icon<[0, 0, 320, 512], 320, 512>,
    'apple-alt': Icon<[0, 0, 448, 512], 448, 512>,
    'archive': Icon<[0, 0, 512, 512], 512, 512>,
    'archway': Icon<[0, 0, 576, 512], 576, 512>,
    'arrow-alt-circle-down': Icon<[0, 0, 512, 512], 512, 512>,
    'arrow-alt-circle-left': Icon<[0, 0, 512, 512], 512, 512>,
    'arrow-alt-circle-right': Icon<[0, 0, 512, 512], 512, 512>,
    'arrow-alt-circle-up': Icon<[0, 0, 512, 512], 512, 512>,
    'arrow-circle-down': Icon<[0, 0, 512, 512], 512, 512>,
    'arrow-circle-left': Icon<[0, 0, 512, 512], 512, 512>,
    'arrow-circle-right': Icon<[0, 0, 512, 512], 512, 512>,
    'arrow-circle-up': Icon<[0, 0, 512, 512], 512, 512>,
    'arrow-down': Icon<[0, 0, 448, 512], 448, 512>,
    'arrow-left': Icon<[0, 0, 448, 512], 448, 512>,
    'arrow-right': Icon<[0, 0, 448, 512], 448, 512>,
    'arrow-up': Icon<[0, 0, 448, 512], 448, 512>,
    'arrows-alt-h': Icon<[0, 0, 512, 512], 512, 512>,
    'arrows-alt-v': Icon<[0, 0, 256, 512], 256, 512>,
    'arrows-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'assistive-listening-systems': Icon<[0, 0, 512, 512], 512, 512>,
    'asterisk': Icon<[0, 0, 512, 512], 512, 512>,
    'at': Icon<[0, 0, 512, 512], 512, 512>,
    'atlas': Icon<[0, 0, 448, 512], 448, 512>,
    'atom': Icon<[0, 0, 448, 512], 448, 512>,
    'audio-description': Icon<[0, 0, 512, 512], 512, 512>,
    'award': Icon<[0, 0, 384, 512], 384, 512>,
    'baby-carriage': Icon<[0, 0, 512, 512], 512, 512>,
    'baby': Icon<[0, 0, 384, 512], 384, 512>,
    'backspace': Icon<[0, 0, 640, 512], 640, 512>,
    'backward': Icon<[0, 0, 512, 512], 512, 512>,
    'bacon': Icon<[0, 0, 576, 512], 576, 512>,
    'bahai': Icon<[0, 0, 512, 512], 512, 512>,
    'balance-scale-left': Icon<[0, 0, 640, 512], 640, 512>,
    'balance-scale-right': Icon<[0, 0, 640, 512], 640, 512>,
    'balance-scale': Icon<[0, 0, 640, 512], 640, 512>,
    'ban': Icon<[0, 0, 512, 512], 512, 512>,
    'band-aid': Icon<[0, 0, 640, 512], 640, 512>,
    'barcode': Icon<[0, 0, 512, 512], 512, 512>,
    'bars': Icon<[0, 0, 448, 512], 448, 512>,
    'baseball-ball': Icon<[0, 0, 496, 512], 496, 512>,
    'basketball-ball': Icon<[0, 0, 496, 512], 496, 512>,
    'bath': Icon<[0, 0, 512, 512], 512, 512>,
    'battery-empty': Icon<[0, 0, 640, 512], 640, 512>,
    'battery-full': Icon<[0, 0, 640, 512], 640, 512>,
    'battery-half': Icon<[0, 0, 640, 512], 640, 512>,
    'battery-quarter': Icon<[0, 0, 640, 512], 640, 512>,
    'battery-three-quarters': Icon<[0, 0, 640, 512], 640, 512>,
    'bed': Icon<[0, 0, 640, 512], 640, 512>,
    'beer': Icon<[0, 0, 448, 512], 448, 512>,
    'bell-slash': Icon<[0, 0, 640, 512], 640, 512>,
    'bell': Icon<[0, 0, 448, 512], 448, 512>,
    'bezier-curve': Icon<[0, 0, 640, 512], 640, 512>,
    'bible': Icon<[0, 0, 448, 512], 448, 512>,
    'bicycle': Icon<[0, 0, 640, 512], 640, 512>,
    'biking': Icon<[0, 0, 640, 512], 640, 512>,
    'binoculars': Icon<[0, 0, 512, 512], 512, 512>,
    'biohazard': Icon<[0, 0, 576, 512], 576, 512>,
    'birthday-cake': Icon<[0, 0, 448, 512], 448, 512>,
    'blender-phone': Icon<[0, 0, 576, 512], 576, 512>,
    'blender': Icon<[0, 0, 512, 512], 512, 512>,
    'blind': Icon<[0, 0, 384, 512], 384, 512>,
    'blog': Icon<[0, 0, 512, 512], 512, 512>,
    'bold': Icon<[0, 0, 384, 512], 384, 512>,
    'bolt': Icon<[0, 0, 320, 512], 320, 512>,
    'bomb': Icon<[0, 0, 512, 512], 512, 512>,
    'bone': Icon<[0, 0, 640, 512], 640, 512>,
    'bong': Icon<[0, 0, 448, 512], 448, 512>,
    'book-dead': Icon<[0, 0, 448, 512], 448, 512>,
    'book-medical': Icon<[0, 0, 448, 512], 448, 512>,
    'book-open': Icon<[0, 0, 576, 512], 576, 512>,
    'book-reader': Icon<[0, 0, 512, 512], 512, 512>,
    'book': Icon<[0, 0, 448, 512], 448, 512>,
    'bookmark': Icon<[0, 0, 384, 512], 384, 512>,
    'border-all': Icon<[0, 0, 448, 512], 448, 512>,
    'border-none': Icon<[0, 0, 448, 512], 448, 512>,
    'border-style': Icon<[0, 0, 448, 512], 448, 512>,
    'bowling-ball': Icon<[0, 0, 496, 512], 496, 512>,
    'box-open': Icon<[0, 0, 640, 512], 640, 512>,
    'box': Icon<[0, 0, 512, 512], 512, 512>,
    'boxes': Icon<[0, 0, 576, 512], 576, 512>,
    'braille': Icon<[0, 0, 640, 512], 640, 512>,
    'brain': Icon<[0, 0, 576, 512], 576, 512>,
    'bread-slice': Icon<[0, 0, 576, 512], 576, 512>,
    'briefcase-medical': Icon<[0, 0, 512, 512], 512, 512>,
    'briefcase': Icon<[0, 0, 512, 512], 512, 512>,
    'broadcast-tower': Icon<[0, 0, 640, 512], 640, 512>,
    'broom': Icon<[0, 0, 640, 512], 640, 512>,
    'brush': Icon<[0, 0, 384, 512], 384, 512>,
    'bug': Icon<[0, 0, 512, 512], 512, 512>,
    'building': Icon<[0, 0, 448, 512], 448, 512>,
    'bullhorn': Icon<[0, 0, 576, 512], 576, 512>,
    'bullseye': Icon<[0, 0, 496, 512], 496, 512>,
    'burn': Icon<[0, 0, 384, 512], 384, 512>,
    'bus-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'bus': Icon<[0, 0, 512, 512], 512, 512>,
    'business-time': Icon<[0, 0, 640, 512], 640, 512>,
    'calculator': Icon<[0, 0, 448, 512], 448, 512>,
    'calendar-alt': Icon<[0, 0, 448, 512], 448, 512>,
    'calendar-check': Icon<[0, 0, 448, 512], 448, 512>,
    'calendar-day': Icon<[0, 0, 448, 512], 448, 512>,
    'calendar-minus': Icon<[0, 0, 448, 512], 448, 512>,
    'calendar-plus': Icon<[0, 0, 448, 512], 448, 512>,
    'calendar-times': Icon<[0, 0, 448, 512], 448, 512>,
    'calendar-week': Icon<[0, 0, 448, 512], 448, 512>,
    'calendar': Icon<[0, 0, 448, 512], 448, 512>,
    'camera-retro': Icon<[0, 0, 512, 512], 512, 512>,
    'camera': Icon<[0, 0, 512, 512], 512, 512>,
    'campground': Icon<[0, 0, 640, 512], 640, 512>,
    'candy-cane': Icon<[0, 0, 512, 512], 512, 512>,
    'cannabis': Icon<[0, 0, 512, 512], 512, 512>,
    'capsules': Icon<[0, 0, 576, 512], 576, 512>,
    'car-alt': Icon<[0, 0, 480, 512], 480, 512>,
    'car-battery': Icon<[0, 0, 512, 512], 512, 512>,
    'car-crash': Icon<[0, 0, 640, 512], 640, 512>,
    'car-side': Icon<[0, 0, 640, 512], 640, 512>,
    'car': Icon<[0, 0, 512, 512], 512, 512>,
    'caravan': Icon<[0, 0, 640, 512], 640, 512>,
    'caret-down': Icon<[0, 0, 320, 512], 320, 512>,
    'caret-left': Icon<[0, 0, 192, 512], 192, 512>,
    'caret-right': Icon<[0, 0, 192, 512], 192, 512>,
    'caret-square-down': Icon<[0, 0, 448, 512], 448, 512>,
    'caret-square-left': Icon<[0, 0, 448, 512], 448, 512>,
    'caret-square-right': Icon<[0, 0, 448, 512], 448, 512>,
    'caret-square-up': Icon<[0, 0, 448, 512], 448, 512>,
    'caret-up': Icon<[0, 0, 320, 512], 320, 512>,
    'carrot': Icon<[0, 0, 512, 512], 512, 512>,
    'cart-arrow-down': Icon<[0, 0, 576, 512], 576, 512>,
    'cart-plus': Icon<[0, 0, 576, 512], 576, 512>,
    'cash-register': Icon<[0, 0, 512, 512], 512, 512>,
    'cat': Icon<[0, 0, 512, 512], 512, 512>,
    'certificate': Icon<[0, 0, 512, 512], 512, 512>,
    'chair': Icon<[0, 0, 448, 512], 448, 512>,
    'chalkboard-teacher': Icon<[0, 0, 640, 512], 640, 512>,
    'chalkboard': Icon<[0, 0, 640, 512], 640, 512>,
    'charging-station': Icon<[0, 0, 576, 512], 576, 512>,
    'chart-area': Icon<[0, 0, 512, 512], 512, 512>,
    'chart-bar': Icon<[0, 0, 512, 512], 512, 512>,
    'chart-line': Icon<[0, 0, 512, 512], 512, 512>,
    'chart-pie': Icon<[0, 0, 544, 512], 544, 512>,
    'check-circle': Icon<[0, 0, 512, 512], 512, 512>,
    'check-double': Icon<[0, 0, 512, 512], 512, 512>,
    'check-square': Icon<[0, 0, 448, 512], 448, 512>,
    'check': Icon<[0, 0, 512, 512], 512, 512>,
    'cheese': Icon<[0, 0, 512, 512], 512, 512>,
    'chess-bishop': Icon<[0, 0, 320, 512], 320, 512>,
    'chess-board': Icon<[0, 0, 512, 512], 512, 512>,
    'chess-king': Icon<[0, 0, 448, 512], 448, 512>,
    'chess-knight': Icon<[0, 0, 384, 512], 384, 512>,
    'chess-pawn': Icon<[0, 0, 320, 512], 320, 512>,
    'chess-queen': Icon<[0, 0, 512, 512], 512, 512>,
    'chess-rook': Icon<[0, 0, 384, 512], 384, 512>,
    'chess': Icon<[0, 0, 512, 512], 512, 512>,
    'chevron-circle-down': Icon<[0, 0, 512, 512], 512, 512>,
    'chevron-circle-left': Icon<[0, 0, 512, 512], 512, 512>,
    'chevron-circle-right': Icon<[0, 0, 512, 512], 512, 512>,
    'chevron-circle-up': Icon<[0, 0, 512, 512], 512, 512>,
    'chevron-down': Icon<[0, 0, 448, 512], 448, 512>,
    'chevron-left': Icon<[0, 0, 320, 512], 320, 512>,
    'chevron-right': Icon<[0, 0, 320, 512], 320, 512>,
    'chevron-up': Icon<[0, 0, 448, 512], 448, 512>,
    'child': Icon<[0, 0, 384, 512], 384, 512>,
    'church': Icon<[0, 0, 640, 512], 640, 512>,
    'circle-notch': Icon<[0, 0, 512, 512], 512, 512>,
    'circle': Icon<[0, 0, 512, 512], 512, 512>,
    'city': Icon<[0, 0, 640, 512], 640, 512>,
    'clinic-medical': Icon<[0, 0, 576, 512], 576, 512>,
    'clipboard-check': Icon<[0, 0, 384, 512], 384, 512>,
    'clipboard-list': Icon<[0, 0, 384, 512], 384, 512>,
    'clipboard': Icon<[0, 0, 384, 512], 384, 512>,
    'clock': Icon<[0, 0, 512, 512], 512, 512>,
    'clone': Icon<[0, 0, 512, 512], 512, 512>,
    'closed-captioning': Icon<[0, 0, 512, 512], 512, 512>,
    'cloud-download-alt': Icon<[0, 0, 640, 512], 640, 512>,
    'cloud-meatball': Icon<[0, 0, 512, 512], 512, 512>,
    'cloud-moon-rain': Icon<[0, 0, 576, 512], 576, 512>,
    'cloud-moon': Icon<[0, 0, 576, 512], 576, 512>,
    'cloud-rain': Icon<[0, 0, 512, 512], 512, 512>,
    'cloud-showers-heavy': Icon<[0, 0, 512, 512], 512, 512>,
    'cloud-sun-rain': Icon<[0, 0, 576, 512], 576, 512>,
    'cloud-sun': Icon<[0, 0, 640, 512], 640, 512>,
    'cloud-upload-alt': Icon<[0, 0, 640, 512], 640, 512>,
    'cloud': Icon<[0, 0, 640, 512], 640, 512>,
    'cocktail': Icon<[0, 0, 576, 512], 576, 512>,
    'code-branch': Icon<[0, 0, 384, 512], 384, 512>,
    'code': Icon<[0, 0, 640, 512], 640, 512>,
    'coffee': Icon<[0, 0, 640, 512], 640, 512>,
    'cog': Icon<[0, 0, 512, 512], 512, 512>,
    'cogs': Icon<[0, 0, 640, 512], 640, 512>,
    'coins': Icon<[0, 0, 512, 512], 512, 512>,
    'columns': Icon<[0, 0, 512, 512], 512, 512>,
    'comment-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'comment-dollar': Icon<[0, 0, 512, 512], 512, 512>,
    'comment-dots': Icon<[0, 0, 512, 512], 512, 512>,
    'comment-medical': Icon<[0, 0, 512, 512], 512, 512>,
    'comment-slash': Icon<[0, 0, 640, 512], 640, 512>,
    'comment': Icon<[0, 0, 512, 512], 512, 512>,
    'comments-dollar': Icon<[0, 0, 576, 512], 576, 512>,
    'comments': Icon<[0, 0, 576, 512], 576, 512>,
    'compact-disc': Icon<[0, 0, 496, 512], 496, 512>,
    'compass': Icon<[0, 0, 496, 512], 496, 512>,
    'compress-alt': Icon<[0, 0, 448, 512], 448, 512>,
    'compress-arrows-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'compress': Icon<[0, 0, 448, 512], 448, 512>,
    'concierge-bell': Icon<[0, 0, 512, 512], 512, 512>,
    'cookie-bite': Icon<[0, 0, 512, 512], 512, 512>,
    'cookie': Icon<[0, 0, 512, 512], 512, 512>,
    'copy': Icon<[0, 0, 448, 512], 448, 512>,
    'copyright': Icon<[0, 0, 512, 512], 512, 512>,
    'couch': Icon<[0, 0, 640, 512], 640, 512>,
    'credit-card': Icon<[0, 0, 576, 512], 576, 512>,
    'crop-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'crop': Icon<[0, 0, 512, 512], 512, 512>,
    'cross': Icon<[0, 0, 384, 512], 384, 512>,
    'crosshairs': Icon<[0, 0, 512, 512], 512, 512>,
    'crow': Icon<[0, 0, 640, 512], 640, 512>,
    'crown': Icon<[0, 0, 640, 512], 640, 512>,
    'crutch': Icon<[0, 0, 512, 512], 512, 512>,
    'cube': Icon<[0, 0, 512, 512], 512, 512>,
    'cubes': Icon<[0, 0, 512, 512], 512, 512>,
    'cut': Icon<[0, 0, 448, 512], 448, 512>,
    'database': Icon<[0, 0, 448, 512], 448, 512>,
    'deaf': Icon<[0, 0, 512, 512], 512, 512>,
    'democrat': Icon<[0, 0, 640, 512], 640, 512>,
    'desktop': Icon<[0, 0, 576, 512], 576, 512>,
    'dharmachakra': Icon<[0, 0, 512, 512], 512, 512>,
    'diagnoses': Icon<[0, 0, 640, 512], 640, 512>,
    'dice-d20': Icon<[0, 0, 480, 512], 480, 512>,
    'dice-d6': Icon<[0, 0, 448, 512], 448, 512>,
    'dice-five': Icon<[0, 0, 448, 512], 448, 512>,
    'dice-four': Icon<[0, 0, 448, 512], 448, 512>,
    'dice-one': Icon<[0, 0, 448, 512], 448, 512>,
    'dice-six': Icon<[0, 0, 448, 512], 448, 512>,
    'dice-three': Icon<[0, 0, 448, 512], 448, 512>,
    'dice-two': Icon<[0, 0, 448, 512], 448, 512>,
    'dice': Icon<[0, 0, 640, 512], 640, 512>,
    'digital-tachograph': Icon<[0, 0, 640, 512], 640, 512>,
    'directions': Icon<[0, 0, 512, 512], 512, 512>,
    'divide': Icon<[0, 0, 448, 512], 448, 512>,
    'dizzy': Icon<[0, 0, 496, 512], 496, 512>,
    'dna': Icon<[0, 0, 448, 512], 448, 512>,
    'dog': Icon<[0, 0, 576, 512], 576, 512>,
    'dollar-sign': Icon<[0, 0, 288, 512], 288, 512>,
    'dolly-flatbed': Icon<[0, 0, 640, 512], 640, 512>,
    'dolly': Icon<[0, 0, 576, 512], 576, 512>,
    'donate': Icon<[0, 0, 512, 512], 512, 512>,
    'door-closed': Icon<[0, 0, 640, 512], 640, 512>,
    'door-open': Icon<[0, 0, 640, 512], 640, 512>,
    'dot-circle': Icon<[0, 0, 512, 512], 512, 512>,
    'dove': Icon<[0, 0, 512, 512], 512, 512>,
    'download': Icon<[0, 0, 512, 512], 512, 512>,
    'drafting-compass': Icon<[0, 0, 512, 512], 512, 512>,
    'dragon': Icon<[0, 0, 640, 512], 640, 512>,
    'draw-polygon': Icon<[0, 0, 448, 512], 448, 512>,
    'drum-steelpan': Icon<[0, 0, 576, 512], 576, 512>,
    'drum': Icon<[0, 0, 512, 512], 512, 512>,
    'drumstick-bite': Icon<[0, 0, 512, 512], 512, 512>,
    'dumbbell': Icon<[0, 0, 640, 512], 640, 512>,
    'dumpster-fire': Icon<[0, 0, 640, 512], 640, 512>,
    'dumpster': Icon<[0, 0, 576, 512], 576, 512>,
    'dungeon': Icon<[0, 0, 512, 512], 512, 512>,
    'edit': Icon<[0, 0, 576, 512], 576, 512>,
    'egg': Icon<[0, 0, 384, 512], 384, 512>,
    'eject': Icon<[0, 0, 448, 512], 448, 512>,
    'ellipsis-h': Icon<[0, 0, 512, 512], 512, 512>,
    'ellipsis-v': Icon<[0, 0, 192, 512], 192, 512>,
    'envelope-open-text': Icon<[0, 0, 512, 512], 512, 512>,
    'envelope-open': Icon<[0, 0, 512, 512], 512, 512>,
    'envelope-square': Icon<[0, 0, 448, 512], 448, 512>,
    'envelope': Icon<[0, 0, 512, 512], 512, 512>,
    'equals': Icon<[0, 0, 448, 512], 448, 512>,
    'eraser': Icon<[0, 0, 512, 512], 512, 512>,
    'ethernet': Icon<[0, 0, 512, 512], 512, 512>,
    'euro-sign': Icon<[0, 0, 320, 512], 320, 512>,
    'exchange-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'exclamation-circle': Icon<[0, 0, 512, 512], 512, 512>,
    'exclamation-triangle': Icon<[0, 0, 576, 512], 576, 512>,
    'exclamation': Icon<[0, 0, 192, 512], 192, 512>,
    'expand-alt': Icon<[0, 0, 448, 512], 448, 512>,
    'expand-arrows-alt': Icon<[0, 0, 448, 512], 448, 512>,
    'expand': Icon<[0, 0, 448, 512], 448, 512>,
    'external-link-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'external-link-square-alt': Icon<[0, 0, 448, 512], 448, 512>,
    'eye-dropper': Icon<[0, 0, 512, 512], 512, 512>,
    'eye-slash': Icon<[0, 0, 640, 512], 640, 512>,
    'eye': Icon<[0, 0, 576, 512], 576, 512>,
    'fan': Icon<[0, 0, 512, 512], 512, 512>,
    'fast-backward': Icon<[0, 0, 512, 512], 512, 512>,
    'fast-forward': Icon<[0, 0, 512, 512], 512, 512>,
    'fax': Icon<[0, 0, 512, 512], 512, 512>,
    'feather-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'feather': Icon<[0, 0, 512, 512], 512, 512>,
    'female': Icon<[0, 0, 256, 512], 256, 512>,
    'fighter-jet': Icon<[0, 0, 640, 512], 640, 512>,
    'file-alt': Icon<[0, 0, 384, 512], 384, 512>,
    'file-archive': Icon<[0, 0, 384, 512], 384, 512>,
    'file-audio': Icon<[0, 0, 384, 512], 384, 512>,
    'file-code': Icon<[0, 0, 384, 512], 384, 512>,
    'file-contract': Icon<[0, 0, 384, 512], 384, 512>,
    'file-csv': Icon<[0, 0, 384, 512], 384, 512>,
    'file-download': Icon<[0, 0, 384, 512], 384, 512>,
    'file-excel': Icon<[0, 0, 384, 512], 384, 512>,
    'file-export': Icon<[0, 0, 576, 512], 576, 512>,
    'file-image': Icon<[0, 0, 384, 512], 384, 512>,
    'file-import': Icon<[0, 0, 512, 512], 512, 512>,
    'file-invoice-dollar': Icon<[0, 0, 384, 512], 384, 512>,
    'file-invoice': Icon<[0, 0, 384, 512], 384, 512>,
    'file-medical-alt': Icon<[0, 0, 448, 512], 448, 512>,
    'file-medical': Icon<[0, 0, 384, 512], 384, 512>,
    'file-pdf': Icon<[0, 0, 384, 512], 384, 512>,
    'file-powerpoint': Icon<[0, 0, 384, 512], 384, 512>,
    'file-prescription': Icon<[0, 0, 384, 512], 384, 512>,
    'file-signature': Icon<[0, 0, 576, 512], 576, 512>,
    'file-upload': Icon<[0, 0, 384, 512], 384, 512>,
    'file-video': Icon<[0, 0, 384, 512], 384, 512>,
    'file-word': Icon<[0, 0, 384, 512], 384, 512>,
    'file': Icon<[0, 0, 384, 512], 384, 512>,
    'fill-drip': Icon<[0, 0, 576, 512], 576, 512>,
    'fill': Icon<[0, 0, 512, 512], 512, 512>,
    'film': Icon<[0, 0, 512, 512], 512, 512>,
    'filter': Icon<[0, 0, 512, 512], 512, 512>,
    'fingerprint': Icon<[0, 0, 512, 512], 512, 512>,
    'fire-alt': Icon<[0, 0, 448, 512], 448, 512>,
    'fire-extinguisher': Icon<[0, 0, 448, 512], 448, 512>,
    'fire': Icon<[0, 0, 384, 512], 384, 512>,
    'first-aid': Icon<[0, 0, 576, 512], 576, 512>,
    'fish': Icon<[0, 0, 576, 512], 576, 512>,
    'fist-raised': Icon<[0, 0, 384, 512], 384, 512>,
    'flag-checkered': Icon<[0, 0, 512, 512], 512, 512>,
    'flag-usa': Icon<[0, 0, 512, 512], 512, 512>,
    'flag': Icon<[0, 0, 512, 512], 512, 512>,
    'flask': Icon<[0, 0, 448, 512], 448, 512>,
    'flushed': Icon<[0, 0, 496, 512], 496, 512>,
    'folder-minus': Icon<[0, 0, 512, 512], 512, 512>,
    'folder-open': Icon<[0, 0, 576, 512], 576, 512>,
    'folder-plus': Icon<[0, 0, 512, 512], 512, 512>,
    'folder': Icon<[0, 0, 512, 512], 512, 512>,
    'font-awesome-logo-full': Icon<[0, 0, 3992, 512], 3992, 512>,
    'font': Icon<[0, 0, 448, 512], 448, 512>,
    'football-ball': Icon<[0, 0, 496, 512], 496, 512>,
    'forward': Icon<[0, 0, 512, 512], 512, 512>,
    'frog': Icon<[0, 0, 576, 512], 576, 512>,
    'frown-open': Icon<[0, 0, 496, 512], 496, 512>,
    'frown': Icon<[0, 0, 496, 512], 496, 512>,
    'funnel-dollar': Icon<[0, 0, 640, 512], 640, 512>,
    'futbol': Icon<[0, 0, 512, 512], 512, 512>,
    'gamepad': Icon<[0, 0, 640, 512], 640, 512>,
    'gas-pump': Icon<[0, 0, 512, 512], 512, 512>,
    'gavel': Icon<[0, 0, 512, 512], 512, 512>,
    'gem': Icon<[0, 0, 576, 512], 576, 512>,
    'genderless': Icon<[0, 0, 288, 512], 288, 512>,
    'ghost': Icon<[0, 0, 384, 512], 384, 512>,
    'gift': Icon<[0, 0, 512, 512], 512, 512>,
    'gifts': Icon<[0, 0, 640, 512], 640, 512>,
    'glass-cheers': Icon<[0, 0, 640, 512], 640, 512>,
    'glass-martini-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'glass-martini': Icon<[0, 0, 512, 512], 512, 512>,
    'glass-whiskey': Icon<[0, 0, 512, 512], 512, 512>,
    'glasses': Icon<[0, 0, 576, 512], 576, 512>,
    'globe-africa': Icon<[0, 0, 496, 512], 496, 512>,
    'globe-americas': Icon<[0, 0, 496, 512], 496, 512>,
    'globe-asia': Icon<[0, 0, 496, 512], 496, 512>,
    'globe-europe': Icon<[0, 0, 496, 512], 496, 512>,
    'globe': Icon<[0, 0, 496, 512], 496, 512>,
    'golf-ball': Icon<[0, 0, 416, 512], 416, 512>,
    'gopuram': Icon<[0, 0, 512, 512], 512, 512>,
    'graduation-cap': Icon<[0, 0, 640, 512], 640, 512>,
    'greater-than-equal': Icon<[0, 0, 448, 512], 448, 512>,
    'greater-than': Icon<[0, 0, 384, 512], 384, 512>,
    'grimace': Icon<[0, 0, 496, 512], 496, 512>,
    'grin-alt': Icon<[0, 0, 496, 512], 496, 512>,
    'grin-beam-sweat': Icon<[0, 0, 504, 512], 504, 512>,
    'grin-beam': Icon<[0, 0, 496, 512], 496, 512>,
    'grin-hearts': Icon<[0, 0, 496, 512], 496, 512>,
    'grin-squint-tears': Icon<[0, 0, 512, 512], 512, 512>,
    'grin-squint': Icon<[0, 0, 496, 512], 496, 512>,
    'grin-stars': Icon<[0, 0, 496, 512], 496, 512>,
    'grin-tears': Icon<[0, 0, 640, 512], 640, 512>,
    'grin-tongue-squint': Icon<[0, 0, 496, 512], 496, 512>,
    'grin-tongue-wink': Icon<[0, 0, 496, 512], 496, 512>,
    'grin-tongue': Icon<[0, 0, 496, 512], 496, 512>,
    'grin-wink': Icon<[0, 0, 496, 512], 496, 512>,
    'grin': Icon<[0, 0, 496, 512], 496, 512>,
    'grip-horizontal': Icon<[0, 0, 448, 512], 448, 512>,
    'grip-lines-vertical': Icon<[0, 0, 256, 512], 256, 512>,
    'grip-lines': Icon<[0, 0, 512, 512], 512, 512>,
    'grip-vertical': Icon<[0, 0, 320, 512], 320, 512>,
    'guitar': Icon<[0, 0, 512, 512], 512, 512>,
    'h-square': Icon<[0, 0, 448, 512], 448, 512>,
    'hamburger': Icon<[0, 0, 512, 512], 512, 512>,
    'hammer': Icon<[0, 0, 576, 512], 576, 512>,
    'hamsa': Icon<[0, 0, 512, 512], 512, 512>,
    'hand-holding-heart': Icon<[0, 0, 576, 512], 576, 512>,
    'hand-holding-usd': Icon<[0, 0, 576, 512], 576, 512>,
    'hand-holding': Icon<[0, 0, 576, 512], 576, 512>,
    'hand-lizard': Icon<[0, 0, 576, 512], 576, 512>,
    'hand-middle-finger': Icon<[0, 0, 512, 512], 512, 512>,
    'hand-paper': Icon<[0, 0, 448, 512], 448, 512>,
    'hand-peace': Icon<[0, 0, 448, 512], 448, 512>,
    'hand-point-down': Icon<[0, 0, 384, 512], 384, 512>,
    'hand-point-left': Icon<[0, 0, 512, 512], 512, 512>,
    'hand-point-right': Icon<[0, 0, 512, 512], 512, 512>,
    'hand-point-up': Icon<[0, 0, 384, 512], 384, 512>,
    'hand-pointer': Icon<[0, 0, 448, 512], 448, 512>,
    'hand-rock': Icon<[0, 0, 512, 512], 512, 512>,
    'hand-scissors': Icon<[0, 0, 512, 512], 512, 512>,
    'hand-spock': Icon<[0, 0, 512, 512], 512, 512>,
    'hands-helping': Icon<[0, 0, 640, 512], 640, 512>,
    'hands': Icon<[0, 0, 640, 512], 640, 512>,
    'handshake': Icon<[0, 0, 640, 512], 640, 512>,
    'hanukiah': Icon<[0, 0, 640, 512], 640, 512>,
    'hard-hat': Icon<[0, 0, 512, 512], 512, 512>,
    'hashtag': Icon<[0, 0, 448, 512], 448, 512>,
    'hat-cowboy-side': Icon<[0, 0, 640, 512], 640, 512>,
    'hat-cowboy': Icon<[0, 0, 640, 512], 640, 512>,
    'hat-wizard': Icon<[0, 0, 512, 512], 512, 512>,
    'hdd': Icon<[0, 0, 576, 512], 576, 512>,
    'heading': Icon<[0, 0, 512, 512], 512, 512>,
    'headphones-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'headphones': Icon<[0, 0, 512, 512], 512, 512>,
    'headset': Icon<[0, 0, 512, 512], 512, 512>,
    'heart-broken': Icon<[0, 0, 512, 512], 512, 512>,
    'heart': Icon<[0, 0, 512, 512], 512, 512>,
    'heartbeat': Icon<[0, 0, 512, 512], 512, 512>,
    'helicopter': Icon<[0, 0, 640, 512], 640, 512>,
    'highlighter': Icon<[0, 0, 544, 512], 544, 512>,
    'hiking': Icon<[0, 0, 384, 512], 384, 512>,
    'hippo': Icon<[0, 0, 640, 512], 640, 512>,
    'history': Icon<[0, 0, 512, 512], 512, 512>,
    'hockey-puck': Icon<[0, 0, 512, 512], 512, 512>,
    'holly-berry': Icon<[0, 0, 448, 512], 448, 512>,
    'home': Icon<[0, 0, 576, 512], 576, 512>,
    'horse-head': Icon<[0, 0, 512, 512], 512, 512>,
    'horse': Icon<[0, 0, 576, 512], 576, 512>,
    'hospital-alt': Icon<[0, 0, 576, 512], 576, 512>,
    'hospital-symbol': Icon<[0, 0, 512, 512], 512, 512>,
    'hospital': Icon<[0, 0, 448, 512], 448, 512>,
    'hot-tub': Icon<[0, 0, 512, 512], 512, 512>,
    'hotdog': Icon<[0, 0, 512, 512], 512, 512>,
    'hotel': Icon<[0, 0, 576, 512], 576, 512>,
    'hourglass-end': Icon<[0, 0, 384, 512], 384, 512>,
    'hourglass-half': Icon<[0, 0, 384, 512], 384, 512>,
    'hourglass-start': Icon<[0, 0, 384, 512], 384, 512>,
    'hourglass': Icon<[0, 0, 384, 512], 384, 512>,
    'house-damage': Icon<[0, 0, 576, 512], 576, 512>,
    'hryvnia': Icon<[0, 0, 384, 512], 384, 512>,
    'i-cursor': Icon<[0, 0, 256, 512], 256, 512>,
    'ice-cream': Icon<[0, 0, 448, 512], 448, 512>,
    'icicles': Icon<[0, 0, 512, 512], 512, 512>,
    'icons': Icon<[0, 0, 512, 512], 512, 512>,
    'id-badge': Icon<[0, 0, 384, 512], 384, 512>,
    'id-card-alt': Icon<[0, 0, 576, 512], 576, 512>,
    'id-card': Icon<[0, 0, 576, 512], 576, 512>,
    'igloo': Icon<[0, 0, 576, 512], 576, 512>,
    'image': Icon<[0, 0, 512, 512], 512, 512>,
    'images': Icon<[0, 0, 576, 512], 576, 512>,
    'inbox': Icon<[0, 0, 576, 512], 576, 512>,
    'indent': Icon<[0, 0, 448, 512], 448, 512>,
    'industry': Icon<[0, 0, 512, 512], 512, 512>,
    'infinity': Icon<[0, 0, 640, 512], 640, 512>,
    'info-circle': Icon<[0, 0, 512, 512], 512, 512>,
    'info': Icon<[0, 0, 192, 512], 192, 512>,
    'italic': Icon<[0, 0, 320, 512], 320, 512>,
    'jedi': Icon<[0, 0, 576, 512], 576, 512>,
    'joint': Icon<[0, 0, 640, 512], 640, 512>,
    'journal-whills': Icon<[0, 0, 448, 512], 448, 512>,
    'kaaba': Icon<[0, 0, 576, 512], 576, 512>,
    'key': Icon<[0, 0, 512, 512], 512, 512>,
    'keyboard': Icon<[0, 0, 576, 512], 576, 512>,
    'khanda': Icon<[0, 0, 512, 512], 512, 512>,
    'kiss-beam': Icon<[0, 0, 496, 512], 496, 512>,
    'kiss-wink-heart': Icon<[0, 0, 504, 512], 504, 512>,
    'kiss': Icon<[0, 0, 496, 512], 496, 512>,
    'kiwi-bird': Icon<[0, 0, 576, 512], 576, 512>,
    'landmark': Icon<[0, 0, 512, 512], 512, 512>,
    'language': Icon<[0, 0, 640, 512], 640, 512>,
    'laptop-code': Icon<[0, 0, 640, 512], 640, 512>,
    'laptop-medical': Icon<[0, 0, 640, 512], 640, 512>,
    'laptop': Icon<[0, 0, 640, 512], 640, 512>,
    'laugh-beam': Icon<[0, 0, 496, 512], 496, 512>,
    'laugh-squint': Icon<[0, 0, 496, 512], 496, 512>,
    'laugh-wink': Icon<[0, 0, 496, 512], 496, 512>,
    'laugh': Icon<[0, 0, 496, 512], 496, 512>,
    'layer-group': Icon<[0, 0, 512, 512], 512, 512>,
    'leaf': Icon<[0, 0, 576, 512], 576, 512>,
    'lemon': Icon<[0, 0, 512, 512], 512, 512>,
    'less-than-equal': Icon<[0, 0, 448, 512], 448, 512>,
    'less-than': Icon<[0, 0, 384, 512], 384, 512>,
    'level-down-alt': Icon<[0, 0, 320, 512], 320, 512>,
    'level-up-alt': Icon<[0, 0, 320, 512], 320, 512>,
    'life-ring': Icon<[0, 0, 512, 512], 512, 512>,
    'lightbulb': Icon<[0, 0, 352, 512], 352, 512>,
    'link': Icon<[0, 0, 512, 512], 512, 512>,
    'lira-sign': Icon<[0, 0, 384, 512], 384, 512>,
    'list-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'list-ol': Icon<[0, 0, 512, 512], 512, 512>,
    'list-ul': Icon<[0, 0, 512, 512], 512, 512>,
    'list': Icon<[0, 0, 512, 512], 512, 512>,
    'location-arrow': Icon<[0, 0, 512, 512], 512, 512>,
    'lock-open': Icon<[0, 0, 576, 512], 576, 512>,
    'lock': Icon<[0, 0, 448, 512], 448, 512>,
    'long-arrow-alt-down': Icon<[0, 0, 256, 512], 256, 512>,
    'long-arrow-alt-left': Icon<[0, 0, 448, 512], 448, 512>,
    'long-arrow-alt-right': Icon<[0, 0, 448, 512], 448, 512>,
    'long-arrow-alt-up': Icon<[0, 0, 256, 512], 256, 512>,
    'low-vision': Icon<[0, 0, 576, 512], 576, 512>,
    'luggage-cart': Icon<[0, 0, 640, 512], 640, 512>,
    'magic': Icon<[0, 0, 512, 512], 512, 512>,
    'magnet': Icon<[0, 0, 512, 512], 512, 512>,
    'mail-bulk': Icon<[0, 0, 576, 512], 576, 512>,
    'male': Icon<[0, 0, 192, 512], 192, 512>,
    'map-marked-alt': Icon<[0, 0, 576, 512], 576, 512>,
    'map-marked': Icon<[0, 0, 576, 512], 576, 512>,
    'map-marker-alt': Icon<[0, 0, 384, 512], 384, 512>,
    'map-marker': Icon<[0, 0, 384, 512], 384, 512>,
    'map-pin': Icon<[0, 0, 288, 512], 288, 512>,
    'map-signs': Icon<[0, 0, 512, 512], 512, 512>,
    'map': Icon<[0, 0, 576, 512], 576, 512>,
    'marker': Icon<[0, 0, 512, 512], 512, 512>,
    'mars-double': Icon<[0, 0, 512, 512], 512, 512>,
    'mars-stroke-h': Icon<[0, 0, 480, 512], 480, 512>,
    'mars-stroke-v': Icon<[0, 0, 288, 512], 288, 512>,
    'mars-stroke': Icon<[0, 0, 384, 512], 384, 512>,
    'mars': Icon<[0, 0, 384, 512], 384, 512>,
    'mask': Icon<[0, 0, 640, 512], 640, 512>,
    'medal': Icon<[0, 0, 512, 512], 512, 512>,
    'medkit': Icon<[0, 0, 512, 512], 512, 512>,
    'meh-blank': Icon<[0, 0, 496, 512], 496, 512>,
    'meh-rolling-eyes': Icon<[0, 0, 496, 512], 496, 512>,
    'meh': Icon<[0, 0, 496, 512], 496, 512>,
    'memory': Icon<[0, 0, 640, 512], 640, 512>,
    'menorah': Icon<[0, 0, 640, 512], 640, 512>,
    'mercury': Icon<[0, 0, 288, 512], 288, 512>,
    'meteor': Icon<[0, 0, 512, 512], 512, 512>,
    'microchip': Icon<[0, 0, 512, 512], 512, 512>,
    'microphone-alt-slash': Icon<[0, 0, 640, 512], 640, 512>,
    'microphone-alt': Icon<[0, 0, 352, 512], 352, 512>,
    'microphone-slash': Icon<[0, 0, 640, 512], 640, 512>,
    'microphone': Icon<[0, 0, 352, 512], 352, 512>,
    'microscope': Icon<[0, 0, 512, 512], 512, 512>,
    'minus-circle': Icon<[0, 0, 512, 512], 512, 512>,
    'minus-square': Icon<[0, 0, 448, 512], 448, 512>,
    'minus': Icon<[0, 0, 448, 512], 448, 512>,
    'mitten': Icon<[0, 0, 448, 512], 448, 512>,
    'mobile-alt': Icon<[0, 0, 320, 512], 320, 512>,
    'mobile': Icon<[0, 0, 320, 512], 320, 512>,
    'money-bill-alt': Icon<[0, 0, 640, 512], 640, 512>,
    'money-bill-wave-alt': Icon<[0, 0, 640, 512], 640, 512>,
    'money-bill-wave': Icon<[0, 0, 640, 512], 640, 512>,
    'money-bill': Icon<[0, 0, 640, 512], 640, 512>,
    'money-check-alt': Icon<[0, 0, 640, 512], 640, 512>,
    'money-check': Icon<[0, 0, 640, 512], 640, 512>,
    'monument': Icon<[0, 0, 384, 512], 384, 512>,
    'moon': Icon<[0, 0, 512, 512], 512, 512>,
    'mortar-pestle': Icon<[0, 0, 512, 512], 512, 512>,
    'mosque': Icon<[0, 0, 640, 512], 640, 512>,
    'motorcycle': Icon<[0, 0, 640, 512], 640, 512>,
    'mountain': Icon<[0, 0, 640, 512], 640, 512>,
    'mouse-pointer': Icon<[0, 0, 320, 512], 320, 512>,
    'mouse': Icon<[0, 0, 384, 512], 384, 512>,
    'mug-hot': Icon<[0, 0, 512, 512], 512, 512>,
    'music': Icon<[0, 0, 512, 512], 512, 512>,
    'network-wired': Icon<[0, 0, 640, 512], 640, 512>,
    'neuter': Icon<[0, 0, 288, 512], 288, 512>,
    'newspaper': Icon<[0, 0, 576, 512], 576, 512>,
    'not-equal': Icon<[0, 0, 448, 512], 448, 512>,
    'notes-medical': Icon<[0, 0, 384, 512], 384, 512>,
    'object-group': Icon<[0, 0, 512, 512], 512, 512>,
    'object-ungroup': Icon<[0, 0, 576, 512], 576, 512>,
    'oil-can': Icon<[0, 0, 640, 512], 640, 512>,
    'om': Icon<[0, 0, 512, 512], 512, 512>,
    'otter': Icon<[0, 0, 640, 512], 640, 512>,
    'outdent': Icon<[0, 0, 448, 512], 448, 512>,
    'pager': Icon<[0, 0, 512, 512], 512, 512>,
    'paint-brush': Icon<[0, 0, 512, 512], 512, 512>,
    'paint-roller': Icon<[0, 0, 512, 512], 512, 512>,
    'palette': Icon<[0, 0, 512, 512], 512, 512>,
    'pallet': Icon<[0, 0, 640, 512], 640, 512>,
    'paper-plane': Icon<[0, 0, 512, 512], 512, 512>,
    'paperclip': Icon<[0, 0, 448, 512], 448, 512>,
    'parachute-box': Icon<[0, 0, 512, 512], 512, 512>,
    'paragraph': Icon<[0, 0, 448, 512], 448, 512>,
    'parking': Icon<[0, 0, 448, 512], 448, 512>,
    'passport': Icon<[0, 0, 448, 512], 448, 512>,
    'pastafarianism': Icon<[0, 0, 640, 512], 640, 512>,
    'paste': Icon<[0, 0, 448, 512], 448, 512>,
    'pause-circle': Icon<[0, 0, 512, 512], 512, 512>,
    'pause': Icon<[0, 0, 448, 512], 448, 512>,
    'paw': Icon<[0, 0, 512, 512], 512, 512>,
    'peace': Icon<[0, 0, 496, 512], 496, 512>,
    'pen-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'pen-fancy': Icon<[0, 0, 512, 512], 512, 512>,
    'pen-nib': Icon<[0, 0, 512, 512], 512, 512>,
    'pen-square': Icon<[0, 0, 448, 512], 448, 512>,
    'pen': Icon<[0, 0, 512, 512], 512, 512>,
    'pencil-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'pencil-ruler': Icon<[0, 0, 512, 512], 512, 512>,
    'people-carry': Icon<[0, 0, 640, 512], 640, 512>,
    'pepper-hot': Icon<[0, 0, 512, 512], 512, 512>,
    'percent': Icon<[0, 0, 448, 512], 448, 512>,
    'percentage': Icon<[0, 0, 384, 512], 384, 512>,
    'person-booth': Icon<[0, 0, 576, 512], 576, 512>,
    'phone-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'phone-slash': Icon<[0, 0, 640, 512], 640, 512>,
    'phone-square-alt': Icon<[0, 0, 448, 512], 448, 512>,
    'phone-square': Icon<[0, 0, 448, 512], 448, 512>,
    'phone-volume': Icon<[0, 0, 384, 512], 384, 512>,
    'phone': Icon<[0, 0, 512, 512], 512, 512>,
    'photo-video': Icon<[0, 0, 640, 512], 640, 512>,
    'piggy-bank': Icon<[0, 0, 576, 512], 576, 512>,
    'pills': Icon<[0, 0, 576, 512], 576, 512>,
    'pizza-slice': Icon<[0, 0, 512, 512], 512, 512>,
    'place-of-worship': Icon<[0, 0, 640, 512], 640, 512>,
    'plane-arrival': Icon<[0, 0, 640, 512], 640, 512>,
    'plane-departure': Icon<[0, 0, 640, 512], 640, 512>,
    'plane': Icon<[0, 0, 576, 512], 576, 512>,
    'play-circle': Icon<[0, 0, 512, 512], 512, 512>,
    'play': Icon<[0, 0, 448, 512], 448, 512>,
    'plug': Icon<[0, 0, 384, 512], 384, 512>,
    'plus-circle': Icon<[0, 0, 512, 512], 512, 512>,
    'plus-square': Icon<[0, 0, 448, 512], 448, 512>,
    'plus': Icon<[0, 0, 448, 512], 448, 512>,
    'podcast': Icon<[0, 0, 448, 512], 448, 512>,
    'poll-h': Icon<[0, 0, 448, 512], 448, 512>,
    'poll': Icon<[0, 0, 448, 512], 448, 512>,
    'poo-storm': Icon<[0, 0, 448, 512], 448, 512>,
    'poo': Icon<[0, 0, 512, 512], 512, 512>,
    'poop': Icon<[0, 0, 512, 512], 512, 512>,
    'portrait': Icon<[0, 0, 384, 512], 384, 512>,
    'pound-sign': Icon<[0, 0, 320, 512], 320, 512>,
    'power-off': Icon<[0, 0, 512, 512], 512, 512>,
    'pray': Icon<[0, 0, 384, 512], 384, 512>,
    'praying-hands': Icon<[0, 0, 640, 512], 640, 512>,
    'prescription-bottle-alt': Icon<[0, 0, 384, 512], 384, 512>,
    'prescription-bottle': Icon<[0, 0, 384, 512], 384, 512>,
    'prescription': Icon<[0, 0, 384, 512], 384, 512>,
    'print': Icon<[0, 0, 512, 512], 512, 512>,
    'procedures': Icon<[0, 0, 640, 512], 640, 512>,
    'project-diagram': Icon<[0, 0, 640, 512], 640, 512>,
    'puzzle-piece': Icon<[0, 0, 576, 512], 576, 512>,
    'qrcode': Icon<[0, 0, 448, 512], 448, 512>,
    'question-circle': Icon<[0, 0, 512, 512], 512, 512>,
    'question': Icon<[0, 0, 384, 512], 384, 512>,
    'quidditch': Icon<[0, 0, 640, 512], 640, 512>,
    'quote-left': Icon<[0, 0, 512, 512], 512, 512>,
    'quote-right': Icon<[0, 0, 512, 512], 512, 512>,
    'quran': Icon<[0, 0, 448, 512], 448, 512>,
    'radiation-alt': Icon<[0, 0, 496, 512], 496, 512>,
    'radiation': Icon<[0, 0, 496, 512], 496, 512>,
    'rainbow': Icon<[0, 0, 576, 512], 576, 512>,
    'random': Icon<[0, 0, 512, 512], 512, 512>,
    'receipt': Icon<[0, 0, 384, 512], 384, 512>,
    'record-vinyl': Icon<[0, 0, 512, 512], 512, 512>,
    'recycle': Icon<[0, 0, 512, 512], 512, 512>,
    'redo-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'redo': Icon<[0, 0, 512, 512], 512, 512>,
    'registered': Icon<[0, 0, 512, 512], 512, 512>,
    'remove-format': Icon<[0, 0, 640, 512], 640, 512>,
    'reply-all': Icon<[0, 0, 576, 512], 576, 512>,
    'reply': Icon<[0, 0, 512, 512], 512, 512>,
    'republican': Icon<[0, 0, 640, 512], 640, 512>,
    'restroom': Icon<[0, 0, 640, 512], 640, 512>,
    'retweet': Icon<[0, 0, 640, 512], 640, 512>,
    'ribbon': Icon<[0, 0, 448, 512], 448, 512>,
    'ring': Icon<[0, 0, 512, 512], 512, 512>,
    'road': Icon<[0, 0, 576, 512], 576, 512>,
    'robot': Icon<[0, 0, 640, 512], 640, 512>,
    'rocket': Icon<[0, 0, 512, 512], 512, 512>,
    'route': Icon<[0, 0, 512, 512], 512, 512>,
    'rss-square': Icon<[0, 0, 448, 512], 448, 512>,
    'rss': Icon<[0, 0, 448, 512], 448, 512>,
    'ruble-sign': Icon<[0, 0, 384, 512], 384, 512>,
    'ruler-combined': Icon<[0, 0, 512, 512], 512, 512>,
    'ruler-horizontal': Icon<[0, 0, 576, 512], 576, 512>,
    'ruler-vertical': Icon<[0, 0, 256, 512], 256, 512>,
    'ruler': Icon<[0, 0, 640, 512], 640, 512>,
    'running': Icon<[0, 0, 416, 512], 416, 512>,
    'rupee-sign': Icon<[0, 0, 320, 512], 320, 512>,
    'sad-cry': Icon<[0, 0, 496, 512], 496, 512>,
    'sad-tear': Icon<[0, 0, 496, 512], 496, 512>,
    'satellite-dish': Icon<[0, 0, 512, 512], 512, 512>,
    'satellite': Icon<[0, 0, 512, 512], 512, 512>,
    'save': Icon<[0, 0, 448, 512], 448, 512>,
    'school': Icon<[0, 0, 640, 512], 640, 512>,
    'screwdriver': Icon<[0, 0, 512, 512], 512, 512>,
    'scroll': Icon<[0, 0, 640, 512], 640, 512>,
    'sd-card': Icon<[0, 0, 384, 512], 384, 512>,
    'search-dollar': Icon<[0, 0, 512, 512], 512, 512>,
    'search-location': Icon<[0, 0, 512, 512], 512, 512>,
    'search-minus': Icon<[0, 0, 512, 512], 512, 512>,
    'search-plus': Icon<[0, 0, 512, 512], 512, 512>,
    'search': Icon<[0, 0, 512, 512], 512, 512>,
    'seedling': Icon<[0, 0, 512, 512], 512, 512>,
    'server': Icon<[0, 0, 512, 512], 512, 512>,
    'shapes': Icon<[0, 0, 512, 512], 512, 512>,
    'share-alt-square': Icon<[0, 0, 448, 512], 448, 512>,
    'share-alt': Icon<[0, 0, 448, 512], 448, 512>,
    'share-square': Icon<[0, 0, 576, 512], 576, 512>,
    'share': Icon<[0, 0, 512, 512], 512, 512>,
    'shekel-sign': Icon<[0, 0, 448, 512], 448, 512>,
    'shield-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'ship': Icon<[0, 0, 640, 512], 640, 512>,
    'shipping-fast': Icon<[0, 0, 640, 512], 640, 512>,
    'shoe-prints': Icon<[0, 0, 640, 512], 640, 512>,
    'shopping-bag': Icon<[0, 0, 448, 512], 448, 512>,
    'shopping-basket': Icon<[0, 0, 576, 512], 576, 512>,
    'shopping-cart': Icon<[0, 0, 576, 512], 576, 512>,
    'shower': Icon<[0, 0, 512, 512], 512, 512>,
    'shuttle-van': Icon<[0, 0, 640, 512], 640, 512>,
    'sign-in-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'sign-language': Icon<[0, 0, 448, 512], 448, 512>,
    'sign-out-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'sign': Icon<[0, 0, 512, 512], 512, 512>,
    'signal': Icon<[0, 0, 640, 512], 640, 512>,
    'signature': Icon<[0, 0, 640, 512], 640, 512>,
    'sim-card': Icon<[0, 0, 384, 512], 384, 512>,
    'sitemap': Icon<[0, 0, 640, 512], 640, 512>,
    'skating': Icon<[0, 0, 448, 512], 448, 512>,
    'skiing-nordic': Icon<[0, 0, 576, 512], 576, 512>,
    'skiing': Icon<[0, 0, 512, 512], 512, 512>,
    'skull-crossbones': Icon<[0, 0, 448, 512], 448, 512>,
    'skull': Icon<[0, 0, 512, 512], 512, 512>,
    'slash': Icon<[0, 0, 640, 512], 640, 512>,
    'sleigh': Icon<[0, 0, 640, 512], 640, 512>,
    'sliders-h': Icon<[0, 0, 512, 512], 512, 512>,
    'smile-beam': Icon<[0, 0, 496, 512], 496, 512>,
    'smile-wink': Icon<[0, 0, 496, 512], 496, 512>,
    'smile': Icon<[0, 0, 496, 512], 496, 512>,
    'smog': Icon<[0, 0, 640, 512], 640, 512>,
    'smoking-ban': Icon<[0, 0, 512, 512], 512, 512>,
    'smoking': Icon<[0, 0, 640, 512], 640, 512>,
    'sms': Icon<[0, 0, 512, 512], 512, 512>,
    'snowboarding': Icon<[0, 0, 512, 512], 512, 512>,
    'snowflake': Icon<[0, 0, 448, 512], 448, 512>,
    'snowman': Icon<[0, 0, 512, 512], 512, 512>,
    'snowplow': Icon<[0, 0, 640, 512], 640, 512>,
    'socks': Icon<[0, 0, 512, 512], 512, 512>,
    'solar-panel': Icon<[0, 0, 640, 512], 640, 512>,
    'sort-alpha-down-alt': Icon<[0, 0, 448, 512], 448, 512>,
    'sort-alpha-down': Icon<[0, 0, 448, 512], 448, 512>,
    'sort-alpha-up-alt': Icon<[0, 0, 448, 512], 448, 512>,
    'sort-alpha-up': Icon<[0, 0, 448, 512], 448, 512>,
    'sort-amount-down-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'sort-amount-down': Icon<[0, 0, 512, 512], 512, 512>,
    'sort-amount-up-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'sort-amount-up': Icon<[0, 0, 512, 512], 512, 512>,
    'sort-down': Icon<[0, 0, 320, 512], 320, 512>,
    'sort-numeric-down-alt': Icon<[0, 0, 448, 512], 448, 512>,
    'sort-numeric-down': Icon<[0, 0, 448, 512], 448, 512>,
    'sort-numeric-up-alt': Icon<[0, 0, 448, 512], 448, 512>,
    'sort-numeric-up': Icon<[0, 0, 448, 512], 448, 512>,
    'sort-up': Icon<[0, 0, 320, 512], 320, 512>,
    'sort': Icon<[0, 0, 320, 512], 320, 512>,
    'spa': Icon<[0, 0, 576, 512], 576, 512>,
    'space-shuttle': Icon<[0, 0, 640, 512], 640, 512>,
    'spell-check': Icon<[0, 0, 576, 512], 576, 512>,
    'spider': Icon<[0, 0, 576, 512], 576, 512>,
    'spinner': Icon<[0, 0, 512, 512], 512, 512>,
    'splotch': Icon<[0, 0, 512, 512], 512, 512>,
    'spray-can': Icon<[0, 0, 512, 512], 512, 512>,
    'square-full': Icon<[0, 0, 512, 512], 512, 512>,
    'square-root-alt': Icon<[0, 0, 576, 512], 576, 512>,
    'square': Icon<[0, 0, 448, 512], 448, 512>,
    'stamp': Icon<[0, 0, 512, 512], 512, 512>,
    'star-and-crescent': Icon<[0, 0, 512, 512], 512, 512>,
    'star-half-alt': Icon<[0, 0, 536, 512], 536, 512>,
    'star-half': Icon<[0, 0, 576, 512], 576, 512>,
    'star-of-david': Icon<[0, 0, 464, 512], 464, 512>,
    'star-of-life': Icon<[0, 0, 480, 512], 480, 512>,
    'star': Icon<[0, 0, 576, 512], 576, 512>,
    'step-backward': Icon<[0, 0, 448, 512], 448, 512>,
    'step-forward': Icon<[0, 0, 448, 512], 448, 512>,
    'stethoscope': Icon<[0, 0, 512, 512], 512, 512>,
    'sticky-note': Icon<[0, 0, 448, 512], 448, 512>,
    'stop-circle': Icon<[0, 0, 512, 512], 512, 512>,
    'stop': Icon<[0, 0, 448, 512], 448, 512>,
    'stopwatch': Icon<[0, 0, 448, 512], 448, 512>,
    'store-alt': Icon<[0, 0, 640, 512], 640, 512>,
    'store': Icon<[0, 0, 616, 512], 616, 512>,
    'stream': Icon<[0, 0, 512, 512], 512, 512>,
    'street-view': Icon<[0, 0, 512, 512], 512, 512>,
    'strikethrough': Icon<[0, 0, 512, 512], 512, 512>,
    'stroopwafel': Icon<[0, 0, 512, 512], 512, 512>,
    'subscript': Icon<[0, 0, 512, 512], 512, 512>,
    'subway': Icon<[0, 0, 448, 512], 448, 512>,
    'suitcase-rolling': Icon<[0, 0, 384, 512], 384, 512>,
    'suitcase': Icon<[0, 0, 512, 512], 512, 512>,
    'sun': Icon<[0, 0, 512, 512], 512, 512>,
    'superscript': Icon<[0, 0, 512, 512], 512, 512>,
    'surprise': Icon<[0, 0, 496, 512], 496, 512>,
    'swatchbook': Icon<[0, 0, 512, 512], 512, 512>,
    'swimmer': Icon<[0, 0, 640, 512], 640, 512>,
    'swimming-pool': Icon<[0, 0, 640, 512], 640, 512>,
    'synagogue': Icon<[0, 0, 640, 512], 640, 512>,
    'sync-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'sync': Icon<[0, 0, 512, 512], 512, 512>,
    'syringe': Icon<[0, 0, 512, 512], 512, 512>,
    'table-tennis': Icon<[0, 0, 512, 512], 512, 512>,
    'table': Icon<[0, 0, 512, 512], 512, 512>,
    'tablet-alt': Icon<[0, 0, 448, 512], 448, 512>,
    'tablet': Icon<[0, 0, 448, 512], 448, 512>,
    'tablets': Icon<[0, 0, 640, 512], 640, 512>,
    'tachometer-alt': Icon<[0, 0, 576, 512], 576, 512>,
    'tag': Icon<[0, 0, 512, 512], 512, 512>,
    'tags': Icon<[0, 0, 640, 512], 640, 512>,
    'tape': Icon<[0, 0, 640, 512], 640, 512>,
    'tasks': Icon<[0, 0, 512, 512], 512, 512>,
    'taxi': Icon<[0, 0, 512, 512], 512, 512>,
    'teeth-open': Icon<[0, 0, 640, 512], 640, 512>,
    'teeth': Icon<[0, 0, 640, 512], 640, 512>,
    'temperature-high': Icon<[0, 0, 512, 512], 512, 512>,
    'temperature-low': Icon<[0, 0, 512, 512], 512, 512>,
    'tenge': Icon<[0, 0, 384, 512], 384, 512>,
    'terminal': Icon<[0, 0, 640, 512], 640, 512>,
    'text-height': Icon<[0, 0, 576, 512], 576, 512>,
    'text-width': Icon<[0, 0, 448, 512], 448, 512>,
    'th-large': Icon<[0, 0, 512, 512], 512, 512>,
    'th-list': Icon<[0, 0, 512, 512], 512, 512>,
    'th': Icon<[0, 0, 512, 512], 512, 512>,
    'theater-masks': Icon<[0, 0, 640, 512], 640, 512>,
    'thermometer-empty': Icon<[0, 0, 256, 512], 256, 512>,
    'thermometer-full': Icon<[0, 0, 256, 512], 256, 512>,
    'thermometer-half': Icon<[0, 0, 256, 512], 256, 512>,
    'thermometer-quarter': Icon<[0, 0, 256, 512], 256, 512>,
    'thermometer-three-quarters': Icon<[0, 0, 256, 512], 256, 512>,
    'thermometer': Icon<[0, 0, 512, 512], 512, 512>,
    'thumbs-down': Icon<[0, 0, 512, 512], 512, 512>,
    'thumbs-up': Icon<[0, 0, 512, 512], 512, 512>,
    'thumbtack': Icon<[0, 0, 384, 512], 384, 512>,
    'ticket-alt': Icon<[0, 0, 576, 512], 576, 512>,
    'times-circle': Icon<[0, 0, 512, 512], 512, 512>,
    'times': Icon<[0, 0, 352, 512], 352, 512>,
    'tint-slash': Icon<[0, 0, 640, 512], 640, 512>,
    'tint': Icon<[0, 0, 352, 512], 352, 512>,
    'tired': Icon<[0, 0, 496, 512], 496, 512>,
    'toggle-off': Icon<[0, 0, 576, 512], 576, 512>,
    'toggle-on': Icon<[0, 0, 576, 512], 576, 512>,
    'toilet-paper': Icon<[0, 0, 576, 512], 576, 512>,
    'toilet': Icon<[0, 0, 384, 512], 384, 512>,
    'toolbox': Icon<[0, 0, 512, 512], 512, 512>,
    'tools': Icon<[0, 0, 512, 512], 512, 512>,
    'tooth': Icon<[0, 0, 448, 512], 448, 512>,
    'torah': Icon<[0, 0, 640, 512], 640, 512>,
    'torii-gate': Icon<[0, 0, 512, 512], 512, 512>,
    'tractor': Icon<[0, 0, 640, 512], 640, 512>,
    'trademark': Icon<[0, 0, 640, 512], 640, 512>,
    'traffic-light': Icon<[0, 0, 384, 512], 384, 512>,
    'trailer': Icon<[0, 0, 640, 512], 640, 512>,
    'train': Icon<[0, 0, 448, 512], 448, 512>,
    'tram': Icon<[0, 0, 512, 512], 512, 512>,
    'transgender-alt': Icon<[0, 0, 480, 512], 480, 512>,
    'transgender': Icon<[0, 0, 384, 512], 384, 512>,
    'trash-alt': Icon<[0, 0, 448, 512], 448, 512>,
    'trash-restore-alt': Icon<[0, 0, 448, 512], 448, 512>,
    'trash-restore': Icon<[0, 0, 448, 512], 448, 512>,
    'trash': Icon<[0, 0, 448, 512], 448, 512>,
    'tree': Icon<[0, 0, 384, 512], 384, 512>,
    'trophy': Icon<[0, 0, 576, 512], 576, 512>,
    'truck-loading': Icon<[0, 0, 640, 512], 640, 512>,
    'truck-monster': Icon<[0, 0, 640, 512], 640, 512>,
    'truck-moving': Icon<[0, 0, 640, 512], 640, 512>,
    'truck-pickup': Icon<[0, 0, 640, 512], 640, 512>,
    'truck': Icon<[0, 0, 640, 512], 640, 512>,
    'tshirt': Icon<[0, 0, 640, 512], 640, 512>,
    'tty': Icon<[0, 0, 512, 512], 512, 512>,
    'tv': Icon<[0, 0, 640, 512], 640, 512>,
    'umbrella-beach': Icon<[0, 0, 640, 512], 640, 512>,
    'umbrella': Icon<[0, 0, 576, 512], 576, 512>,
    'underline': Icon<[0, 0, 448, 512], 448, 512>,
    'undo-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'undo': Icon<[0, 0, 512, 512], 512, 512>,
    'universal-access': Icon<[0, 0, 512, 512], 512, 512>,
    'university': Icon<[0, 0, 512, 512], 512, 512>,
    'unlink': Icon<[0, 0, 512, 512], 512, 512>,
    'unlock-alt': Icon<[0, 0, 448, 512], 448, 512>,
    'unlock': Icon<[0, 0, 448, 512], 448, 512>,
    'upload': Icon<[0, 0, 512, 512], 512, 512>,
    'user-alt-slash': Icon<[0, 0, 640, 512], 640, 512>,
    'user-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'user-astronaut': Icon<[0, 0, 448, 512], 448, 512>,
    'user-check': Icon<[0, 0, 640, 512], 640, 512>,
    'user-circle': Icon<[0, 0, 496, 512], 496, 512>,
    'user-clock': Icon<[0, 0, 640, 512], 640, 512>,
    'user-cog': Icon<[0, 0, 640, 512], 640, 512>,
    'user-edit': Icon<[0, 0, 640, 512], 640, 512>,
    'user-friends': Icon<[0, 0, 640, 512], 640, 512>,
    'user-graduate': Icon<[0, 0, 448, 512], 448, 512>,
    'user-injured': Icon<[0, 0, 448, 512], 448, 512>,
    'user-lock': Icon<[0, 0, 640, 512], 640, 512>,
    'user-md': Icon<[0, 0, 448, 512], 448, 512>,
    'user-minus': Icon<[0, 0, 640, 512], 640, 512>,
    'user-ninja': Icon<[0, 0, 448, 512], 448, 512>,
    'user-nurse': Icon<[0, 0, 448, 512], 448, 512>,
    'user-plus': Icon<[0, 0, 640, 512], 640, 512>,
    'user-secret': Icon<[0, 0, 448, 512], 448, 512>,
    'user-shield': Icon<[0, 0, 640, 512], 640, 512>,
    'user-slash': Icon<[0, 0, 640, 512], 640, 512>,
    'user-tag': Icon<[0, 0, 640, 512], 640, 512>,
    'user-tie': Icon<[0, 0, 448, 512], 448, 512>,
    'user-times': Icon<[0, 0, 640, 512], 640, 512>,
    'user': Icon<[0, 0, 448, 512], 448, 512>,
    'users-cog': Icon<[0, 0, 640, 512], 640, 512>,
    'users': Icon<[0, 0, 640, 512], 640, 512>,
    'utensil-spoon': Icon<[0, 0, 512, 512], 512, 512>,
    'utensils': Icon<[0, 0, 416, 512], 416, 512>,
    'vector-square': Icon<[0, 0, 512, 512], 512, 512>,
    'venus-double': Icon<[0, 0, 512, 512], 512, 512>,
    'venus-mars': Icon<[0, 0, 576, 512], 576, 512>,
    'venus': Icon<[0, 0, 288, 512], 288, 512>,
    'vial': Icon<[0, 0, 480, 512], 480, 512>,
    'vials': Icon<[0, 0, 640, 512], 640, 512>,
    'video-slash': Icon<[0, 0, 640, 512], 640, 512>,
    'video': Icon<[0, 0, 576, 512], 576, 512>,
    'vihara': Icon<[0, 0, 640, 512], 640, 512>,
    'voicemail': Icon<[0, 0, 640, 512], 640, 512>,
    'volleyball-ball': Icon<[0, 0, 512, 512], 512, 512>,
    'volume-down': Icon<[0, 0, 384, 512], 384, 512>,
    'volume-mute': Icon<[0, 0, 512, 512], 512, 512>,
    'volume-off': Icon<[0, 0, 256, 512], 256, 512>,
    'volume-up': Icon<[0, 0, 576, 512], 576, 512>,
    'vote-yea': Icon<[0, 0, 640, 512], 640, 512>,
    'vr-cardboard': Icon<[0, 0, 640, 512], 640, 512>,
    'walking': Icon<[0, 0, 320, 512], 320, 512>,
    'wallet': Icon<[0, 0, 512, 512], 512, 512>,
    'warehouse': Icon<[0, 0, 640, 512], 640, 512>,
    'water': Icon<[0, 0, 576, 512], 576, 512>,
    'wave-square': Icon<[0, 0, 640, 512], 640, 512>,
    'weight-hanging': Icon<[0, 0, 512, 512], 512, 512>,
    'weight': Icon<[0, 0, 512, 512], 512, 512>,
    'wheelchair': Icon<[0, 0, 512, 512], 512, 512>,
    'wifi': Icon<[0, 0, 640, 512], 640, 512>,
    'wind': Icon<[0, 0, 512, 512], 512, 512>,
    'window-close': Icon<[0, 0, 512, 512], 512, 512>,
    'window-maximize': Icon<[0, 0, 512, 512], 512, 512>,
    'window-minimize': Icon<[0, 0, 512, 512], 512, 512>,
    'window-restore': Icon<[0, 0, 512, 512], 512, 512>,
    'wine-bottle': Icon<[0, 0, 512, 512], 512, 512>,
    'wine-glass-alt': Icon<[0, 0, 288, 512], 288, 512>,
    'wine-glass': Icon<[0, 0, 288, 512], 288, 512>,
    'won-sign': Icon<[0, 0, 576, 512], 576, 512>,
    'wrench': Icon<[0, 0, 512, 512], 512, 512>,
    'x-ray': Icon<[0, 0, 640, 512], 640, 512>,
    'yen-sign': Icon<[0, 0, 384, 512], 384, 512>,
    'yin-yang': Icon<[0, 0, 496, 512], 496, 512>
};

declare const icons: Icons;

export default icons;
export {
    Ad,
    AddressBook,
    AddressCard,
    Adjust,
    AirFreshener,
    AlignCenter,
    AlignJustify,
    AlignLeft,
    AlignRight,
    Allergies,
    Ambulance,
    AmericanSignLanguageInterpreting,
    Anchor,
    AngleDoubleDown,
    AngleDoubleLeft,
    AngleDoubleRight,
    AngleDoubleUp,
    AngleDown,
    AngleLeft,
    AngleRight,
    AngleUp,
    Angry,
    Ankh,
    AppleAlt,
    Archive,
    Archway,
    ArrowAltCircleDown,
    ArrowAltCircleLeft,
    ArrowAltCircleRight,
    ArrowAltCircleUp,
    ArrowCircleDown,
    ArrowCircleLeft,
    ArrowCircleRight,
    ArrowCircleUp,
    ArrowDown,
    ArrowLeft,
    ArrowRight,
    ArrowUp,
    ArrowsAltH,
    ArrowsAltV,
    ArrowsAlt,
    AssistiveListeningSystems,
    Asterisk,
    At,
    Atlas,
    Atom,
    AudioDescription,
    Award,
    BabyCarriage,
    Baby,
    Backspace,
    Backward,
    Bacon,
    Bahai,
    BalanceScaleLeft,
    BalanceScaleRight,
    BalanceScale,
    Ban,
    BandAid,
    Barcode,
    Bars,
    BaseballBall,
    BasketballBall,
    Bath,
    BatteryEmpty,
    BatteryFull,
    BatteryHalf,
    BatteryQuarter,
    BatteryThreeQuarters,
    Bed,
    Beer,
    BellSlash,
    Bell,
    BezierCurve,
    Bible,
    Bicycle,
    Biking,
    Binoculars,
    Biohazard,
    BirthdayCake,
    BlenderPhone,
    Blender,
    Blind,
    Blog,
    Bold,
    Bolt,
    Bomb,
    Bone,
    Bong,
    BookDead,
    BookMedical,
    BookOpen,
    BookReader,
    Book,
    Bookmark,
    BorderAll,
    BorderNone,
    BorderStyle,
    BowlingBall,
    BoxOpen,
    Box,
    Boxes,
    Braille,
    Brain,
    BreadSlice,
    BriefcaseMedical,
    Briefcase,
    BroadcastTower,
    Broom,
    Brush,
    Bug,
    Building,
    Bullhorn,
    Bullseye,
    Burn,
    BusAlt,
    Bus,
    BusinessTime,
    Calculator,
    CalendarAlt,
    CalendarCheck,
    CalendarDay,
    CalendarMinus,
    CalendarPlus,
    CalendarTimes,
    CalendarWeek,
    Calendar,
    CameraRetro,
    Camera,
    Campground,
    CandyCane,
    Cannabis,
    Capsules,
    CarAlt,
    CarBattery,
    CarCrash,
    CarSide,
    Car,
    Caravan,
    CaretDown,
    CaretLeft,
    CaretRight,
    CaretSquareDown,
    CaretSquareLeft,
    CaretSquareRight,
    CaretSquareUp,
    CaretUp,
    Carrot,
    CartArrowDown,
    CartPlus,
    CashRegister,
    Cat,
    Certificate,
    Chair,
    ChalkboardTeacher,
    Chalkboard,
    ChargingStation,
    ChartArea,
    ChartBar,
    ChartLine,
    ChartPie,
    CheckCircle,
    CheckDouble,
    CheckSquare,
    Check,
    Cheese,
    ChessBishop,
    ChessBoard,
    ChessKing,
    ChessKnight,
    ChessPawn,
    ChessQueen,
    ChessRook,
    Chess,
    ChevronCircleDown,
    ChevronCircleLeft,
    ChevronCircleRight,
    ChevronCircleUp,
    ChevronDown,
    ChevronLeft,
    ChevronRight,
    ChevronUp,
    Child,
    Church,
    CircleNotch,
    Circle,
    City,
    ClinicMedical,
    ClipboardCheck,
    ClipboardList,
    Clipboard,
    Clock,
    Clone,
    ClosedCaptioning,
    CloudDownloadAlt,
    CloudMeatball,
    CloudMoonRain,
    CloudMoon,
    CloudRain,
    CloudShowersHeavy,
    CloudSunRain,
    CloudSun,
    CloudUploadAlt,
    Cloud,
    Cocktail,
    CodeBranch,
    Code,
    Coffee,
    Cog,
    Cogs,
    Coins,
    Columns,
    CommentAlt,
    CommentDollar,
    CommentDots,
    CommentMedical,
    CommentSlash,
    Comment,
    CommentsDollar,
    Comments,
    CompactDisc,
    Compass,
    CompressAlt,
    CompressArrowsAlt,
    Compress,
    ConciergeBell,
    CookieBite,
    Cookie,
    Copy,
    Copyright,
    Couch,
    CreditCard,
    CropAlt,
    Crop,
    Cross,
    Crosshairs,
    Crow,
    Crown,
    Crutch,
    Cube,
    Cubes,
    Cut,
    Database,
    Deaf,
    Democrat,
    Desktop,
    Dharmachakra,
    Diagnoses,
    DiceD20,
    DiceD6,
    DiceFive,
    DiceFour,
    DiceOne,
    DiceSix,
    DiceThree,
    DiceTwo,
    Dice,
    DigitalTachograph,
    Directions,
    Divide,
    Dizzy,
    Dna,
    Dog,
    DollarSign,
    DollyFlatbed,
    Dolly,
    Donate,
    DoorClosed,
    DoorOpen,
    DotCircle,
    Dove,
    Download,
    DraftingCompass,
    Dragon,
    DrawPolygon,
    DrumSteelpan,
    Drum,
    DrumstickBite,
    Dumbbell,
    DumpsterFire,
    Dumpster,
    Dungeon,
    Edit,
    Egg,
    Eject,
    EllipsisH,
    EllipsisV,
    EnvelopeOpenText,
    EnvelopeOpen,
    EnvelopeSquare,
    Envelope,
    Equals,
    Eraser,
    Ethernet,
    EuroSign,
    ExchangeAlt,
    ExclamationCircle,
    ExclamationTriangle,
    Exclamation,
    ExpandAlt,
    ExpandArrowsAlt,
    Expand,
    ExternalLinkAlt,
    ExternalLinkSquareAlt,
    EyeDropper,
    EyeSlash,
    Eye,
    Fan,
    FastBackward,
    FastForward,
    Fax,
    FeatherAlt,
    Feather,
    Female,
    FighterJet,
    FileAlt,
    FileArchive,
    FileAudio,
    FileCode,
    FileContract,
    FileCsv,
    FileDownload,
    FileExcel,
    FileExport,
    FileImage,
    FileImport,
    FileInvoiceDollar,
    FileInvoice,
    FileMedicalAlt,
    FileMedical,
    FilePdf,
    FilePowerpoint,
    FilePrescription,
    FileSignature,
    FileUpload,
    FileVideo,
    FileWord,
    File,
    FillDrip,
    Fill,
    Film,
    Filter,
    Fingerprint,
    FireAlt,
    FireExtinguisher,
    Fire,
    FirstAid,
    Fish,
    FistRaised,
    FlagCheckered,
    FlagUsa,
    Flag,
    Flask,
    Flushed,
    FolderMinus,
    FolderOpen,
    FolderPlus,
    Folder,
    FontAwesomeLogoFull,
    Font,
    FootballBall,
    Forward,
    Frog,
    FrownOpen,
    Frown,
    FunnelDollar,
    Futbol,
    Gamepad,
    GasPump,
    Gavel,
    Gem,
    Genderless,
    Ghost,
    Gift,
    Gifts,
    GlassCheers,
    GlassMartiniAlt,
    GlassMartini,
    GlassWhiskey,
    Glasses,
    GlobeAfrica,
    GlobeAmericas,
    GlobeAsia,
    GlobeEurope,
    Globe,
    GolfBall,
    Gopuram,
    GraduationCap,
    GreaterThanEqual,
    GreaterThan,
    Grimace,
    GrinAlt,
    GrinBeamSweat,
    GrinBeam,
    GrinHearts,
    GrinSquintTears,
    GrinSquint,
    GrinStars,
    GrinTears,
    GrinTongueSquint,
    GrinTongueWink,
    GrinTongue,
    GrinWink,
    Grin,
    GripHorizontal,
    GripLinesVertical,
    GripLines,
    GripVertical,
    Guitar,
    HSquare,
    Hamburger,
    Hammer,
    Hamsa,
    HandHoldingHeart,
    HandHoldingUsd,
    HandHolding,
    HandLizard,
    HandMiddleFinger,
    HandPaper,
    HandPeace,
    HandPointDown,
    HandPointLeft,
    HandPointRight,
    HandPointUp,
    HandPointer,
    HandRock,
    HandScissors,
    HandSpock,
    HandsHelping,
    Hands,
    Handshake,
    Hanukiah,
    HardHat,
    Hashtag,
    HatCowboySide,
    HatCowboy,
    HatWizard,
    Hdd,
    Heading,
    HeadphonesAlt,
    Headphones,
    Headset,
    HeartBroken,
    Heart,
    Heartbeat,
    Helicopter,
    Highlighter,
    Hiking,
    Hippo,
    History,
    HockeyPuck,
    HollyBerry,
    Home,
    HorseHead,
    Horse,
    HospitalAlt,
    HospitalSymbol,
    Hospital,
    HotTub,
    Hotdog,
    Hotel,
    HourglassEnd,
    HourglassHalf,
    HourglassStart,
    Hourglass,
    HouseDamage,
    Hryvnia,
    ICursor,
    IceCream,
    Icicles,
    Icons,
    IdBadge,
    IdCardAlt,
    IdCard,
    Igloo,
    Image,
    Images,
    Inbox,
    Indent,
    Industry,
    Infinity,
    InfoCircle,
    Info,
    Italic,
    Jedi,
    Joint,
    JournalWhills,
    Kaaba,
    Key,
    Keyboard,
    Khanda,
    KissBeam,
    KissWinkHeart,
    Kiss,
    KiwiBird,
    Landmark,
    Language,
    LaptopCode,
    LaptopMedical,
    Laptop,
    LaughBeam,
    LaughSquint,
    LaughWink,
    Laugh,
    LayerGroup,
    Leaf,
    Lemon,
    LessThanEqual,
    LessThan,
    LevelDownAlt,
    LevelUpAlt,
    LifeRing,
    Lightbulb,
    Link,
    LiraSign,
    ListAlt,
    ListOl,
    ListUl,
    List,
    LocationArrow,
    LockOpen,
    Lock,
    LongArrowAltDown,
    LongArrowAltLeft,
    LongArrowAltRight,
    LongArrowAltUp,
    LowVision,
    LuggageCart,
    Magic,
    Magnet,
    MailBulk,
    Male,
    MapMarkedAlt,
    MapMarked,
    MapMarkerAlt,
    MapMarker,
    MapPin,
    MapSigns,
    Map,
    Marker,
    MarsDouble,
    MarsStrokeH,
    MarsStrokeV,
    MarsStroke,
    Mars,
    Mask,
    Medal,
    Medkit,
    MehBlank,
    MehRollingEyes,
    Meh,
    Memory,
    Menorah,
    Mercury,
    Meteor,
    Microchip,
    MicrophoneAltSlash,
    MicrophoneAlt,
    MicrophoneSlash,
    Microphone,
    Microscope,
    MinusCircle,
    MinusSquare,
    Minus,
    Mitten,
    MobileAlt,
    Mobile,
    MoneyBillAlt,
    MoneyBillWaveAlt,
    MoneyBillWave,
    MoneyBill,
    MoneyCheckAlt,
    MoneyCheck,
    Monument,
    Moon,
    MortarPestle,
    Mosque,
    Motorcycle,
    Mountain,
    MousePointer,
    Mouse,
    MugHot,
    Music,
    NetworkWired,
    Neuter,
    Newspaper,
    NotEqual,
    NotesMedical,
    ObjectGroup,
    ObjectUngroup,
    OilCan,
    Om,
    Otter,
    Outdent,
    Pager,
    PaintBrush,
    PaintRoller,
    Palette,
    Pallet,
    PaperPlane,
    Paperclip,
    ParachuteBox,
    Paragraph,
    Parking,
    Passport,
    Pastafarianism,
    Paste,
    PauseCircle,
    Pause,
    Paw,
    Peace,
    PenAlt,
    PenFancy,
    PenNib,
    PenSquare,
    Pen,
    PencilAlt,
    PencilRuler,
    PeopleCarry,
    PepperHot,
    Percent,
    Percentage,
    PersonBooth,
    PhoneAlt,
    PhoneSlash,
    PhoneSquareAlt,
    PhoneSquare,
    PhoneVolume,
    Phone,
    PhotoVideo,
    PiggyBank,
    Pills,
    PizzaSlice,
    PlaceOfWorship,
    PlaneArrival,
    PlaneDeparture,
    Plane,
    PlayCircle,
    Play,
    Plug,
    PlusCircle,
    PlusSquare,
    Plus,
    Podcast,
    PollH,
    Poll,
    PooStorm,
    Poo,
    Poop,
    Portrait,
    PoundSign,
    PowerOff,
    Pray,
    PrayingHands,
    PrescriptionBottleAlt,
    PrescriptionBottle,
    Prescription,
    Print,
    Procedures,
    ProjectDiagram,
    PuzzlePiece,
    Qrcode,
    QuestionCircle,
    Question,
    Quidditch,
    QuoteLeft,
    QuoteRight,
    Quran,
    RadiationAlt,
    Radiation,
    Rainbow,
    Random,
    Receipt,
    RecordVinyl,
    Recycle,
    RedoAlt,
    Redo,
    Registered,
    RemoveFormat,
    ReplyAll,
    Reply,
    Republican,
    Restroom,
    Retweet,
    Ribbon,
    Ring,
    Road,
    Robot,
    Rocket,
    Route,
    RssSquare,
    Rss,
    RubleSign,
    RulerCombined,
    RulerHorizontal,
    RulerVertical,
    Ruler,
    Running,
    RupeeSign,
    SadCry,
    SadTear,
    SatelliteDish,
    Satellite,
    Save,
    School,
    Screwdriver,
    Scroll,
    SdCard,
    SearchDollar,
    SearchLocation,
    SearchMinus,
    SearchPlus,
    Search,
    Seedling,
    Server,
    Shapes,
    ShareAltSquare,
    ShareAlt,
    ShareSquare,
    Share,
    ShekelSign,
    ShieldAlt,
    Ship,
    ShippingFast,
    ShoePrints,
    ShoppingBag,
    ShoppingBasket,
    ShoppingCart,
    Shower,
    ShuttleVan,
    SignInAlt,
    SignLanguage,
    SignOutAlt,
    Sign,
    Signal,
    Signature,
    SimCard,
    Sitemap,
    Skating,
    SkiingNordic,
    Skiing,
    SkullCrossbones,
    Skull,
    Slash,
    Sleigh,
    SlidersH,
    SmileBeam,
    SmileWink,
    Smile,
    Smog,
    SmokingBan,
    Smoking,
    Sms,
    Snowboarding,
    Snowflake,
    Snowman,
    Snowplow,
    Socks,
    SolarPanel,
    SortAlphaDownAlt,
    SortAlphaDown,
    SortAlphaUpAlt,
    SortAlphaUp,
    SortAmountDownAlt,
    SortAmountDown,
    SortAmountUpAlt,
    SortAmountUp,
    SortDown,
    SortNumericDownAlt,
    SortNumericDown,
    SortNumericUpAlt,
    SortNumericUp,
    SortUp,
    Sort,
    Spa,
    SpaceShuttle,
    SpellCheck,
    Spider,
    Spinner,
    Splotch,
    SprayCan,
    SquareFull,
    SquareRootAlt,
    Square,
    Stamp,
    StarAndCrescent,
    StarHalfAlt,
    StarHalf,
    StarOfDavid,
    StarOfLife,
    Star,
    StepBackward,
    StepForward,
    Stethoscope,
    StickyNote,
    StopCircle,
    Stop,
    Stopwatch,
    StoreAlt,
    Store,
    Stream,
    StreetView,
    Strikethrough,
    Stroopwafel,
    Subscript,
    Subway,
    SuitcaseRolling,
    Suitcase,
    Sun,
    Superscript,
    Surprise,
    Swatchbook,
    Swimmer,
    SwimmingPool,
    Synagogue,
    SyncAlt,
    Sync,
    Syringe,
    TableTennis,
    Table,
    TabletAlt,
    Tablet,
    Tablets,
    TachometerAlt,
    Tag,
    Tags,
    Tape,
    Tasks,
    Taxi,
    TeethOpen,
    Teeth,
    TemperatureHigh,
    TemperatureLow,
    Tenge,
    Terminal,
    TextHeight,
    TextWidth,
    ThLarge,
    ThList,
    Th,
    TheaterMasks,
    ThermometerEmpty,
    ThermometerFull,
    ThermometerHalf,
    ThermometerQuarter,
    ThermometerThreeQuarters,
    Thermometer,
    ThumbsDown,
    ThumbsUp,
    Thumbtack,
    TicketAlt,
    TimesCircle,
    Times,
    TintSlash,
    Tint,
    Tired,
    ToggleOff,
    ToggleOn,
    ToiletPaper,
    Toilet,
    Toolbox,
    Tools,
    Tooth,
    Torah,
    ToriiGate,
    Tractor,
    Trademark,
    TrafficLight,
    Trailer,
    Train,
    Tram,
    TransgenderAlt,
    Transgender,
    TrashAlt,
    TrashRestoreAlt,
    TrashRestore,
    Trash,
    Tree,
    Trophy,
    TruckLoading,
    TruckMonster,
    TruckMoving,
    TruckPickup,
    Truck,
    Tshirt,
    Tty,
    Tv,
    UmbrellaBeach,
    Umbrella,
    Underline,
    UndoAlt,
    Undo,
    UniversalAccess,
    University,
    Unlink,
    UnlockAlt,
    Unlock,
    Upload,
    UserAltSlash,
    UserAlt,
    UserAstronaut,
    UserCheck,
    UserCircle,
    UserClock,
    UserCog,
    UserEdit,
    UserFriends,
    UserGraduate,
    UserInjured,
    UserLock,
    UserMd,
    UserMinus,
    UserNinja,
    UserNurse,
    UserPlus,
    UserSecret,
    UserShield,
    UserSlash,
    UserTag,
    UserTie,
    UserTimes,
    User,
    UsersCog,
    Users,
    UtensilSpoon,
    Utensils,
    VectorSquare,
    VenusDouble,
    VenusMars,
    Venus,
    Vial,
    Vials,
    VideoSlash,
    Video,
    Vihara,
    Voicemail,
    VolleyballBall,
    VolumeDown,
    VolumeMute,
    VolumeOff,
    VolumeUp,
    VoteYea,
    VrCardboard,
    Walking,
    Wallet,
    Warehouse,
    Water,
    WaveSquare,
    WeightHanging,
    Weight,
    Wheelchair,
    Wifi,
    Wind,
    WindowClose,
    WindowMaximize,
    WindowMinimize,
    WindowRestore,
    WineBottle,
    WineGlassAlt,
    WineGlass,
    WonSign,
    Wrench,
    XRay,
    YenSign,
    YinYang
};
