/* THIS FILE IS GENERATED. DO NOT EDIT IT. */
import {CreateElement, VNode} from 'vue';
import {Icon} from '@tomoeed/j-icon';

declare const AddressBook: Icon<[0, 0, 448, 512], 448, 512>;
declare const AddressCard: Icon<[0, 0, 576, 512], 576, 512>;
declare const Angry: Icon<[0, 0, 496, 512], 496, 512>;
declare const ArrowAltCircleDown: Icon<[0, 0, 512, 512], 512, 512>;
declare const ArrowAltCircleLeft: Icon<[0, 0, 512, 512], 512, 512>;
declare const ArrowAltCircleRight: Icon<[0, 0, 512, 512], 512, 512>;
declare const ArrowAltCircleUp: Icon<[0, 0, 512, 512], 512, 512>;
declare const BellSlash: Icon<[0, 0, 640, 512], 640, 512>;
declare const Bell: Icon<[0, 0, 448, 512], 448, 512>;
declare const Bookmark: Icon<[0, 0, 384, 512], 384, 512>;
declare const Building: Icon<[0, 0, 448, 512], 448, 512>;
declare const CalendarAlt: Icon<[0, 0, 448, 512], 448, 512>;
declare const CalendarCheck: Icon<[0, 0, 448, 512], 448, 512>;
declare const CalendarMinus: Icon<[0, 0, 448, 512], 448, 512>;
declare const CalendarPlus: Icon<[0, 0, 448, 512], 448, 512>;
declare const CalendarTimes: Icon<[0, 0, 448, 512], 448, 512>;
declare const Calendar: Icon<[0, 0, 448, 512], 448, 512>;
declare const CaretSquareDown: Icon<[0, 0, 448, 512], 448, 512>;
declare const CaretSquareLeft: Icon<[0, 0, 448, 512], 448, 512>;
declare const CaretSquareRight: Icon<[0, 0, 448, 512], 448, 512>;
declare const CaretSquareUp: Icon<[0, 0, 448, 512], 448, 512>;
declare const ChartBar: Icon<[0, 0, 512, 512], 512, 512>;
declare const CheckCircle: Icon<[0, 0, 512, 512], 512, 512>;
declare const CheckSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Circle: Icon<[0, 0, 512, 512], 512, 512>;
declare const Clipboard: Icon<[0, 0, 384, 512], 384, 512>;
declare const Clock: Icon<[0, 0, 512, 512], 512, 512>;
declare const Clone: Icon<[0, 0, 512, 512], 512, 512>;
declare const ClosedCaptioning: Icon<[0, 0, 512, 512], 512, 512>;
declare const CommentAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const CommentDots: Icon<[0, 0, 512, 512], 512, 512>;
declare const Comment: Icon<[0, 0, 512, 512], 512, 512>;
declare const Comments: Icon<[0, 0, 576, 512], 576, 512>;
declare const Compass: Icon<[0, 0, 496, 512], 496, 512>;
declare const Copy: Icon<[0, 0, 448, 512], 448, 512>;
declare const Copyright: Icon<[0, 0, 512, 512], 512, 512>;
declare const CreditCard: Icon<[0, 0, 576, 512], 576, 512>;
declare const Dizzy: Icon<[0, 0, 496, 512], 496, 512>;
declare const DotCircle: Icon<[0, 0, 512, 512], 512, 512>;
declare const Edit: Icon<[0, 0, 576, 512], 576, 512>;
declare const EnvelopeOpen: Icon<[0, 0, 512, 512], 512, 512>;
declare const Envelope: Icon<[0, 0, 512, 512], 512, 512>;
declare const EyeSlash: Icon<[0, 0, 640, 512], 640, 512>;
declare const Eye: Icon<[0, 0, 576, 512], 576, 512>;
declare const FileAlt: Icon<[0, 0, 384, 512], 384, 512>;
declare const FileArchive: Icon<[0, 0, 384, 512], 384, 512>;
declare const FileAudio: Icon<[0, 0, 384, 512], 384, 512>;
declare const FileCode: Icon<[0, 0, 384, 512], 384, 512>;
declare const FileExcel: Icon<[0, 0, 384, 512], 384, 512>;
declare const FileImage: Icon<[0, 0, 384, 512], 384, 512>;
declare const FilePdf: Icon<[0, 0, 384, 512], 384, 512>;
declare const FilePowerpoint: Icon<[0, 0, 384, 512], 384, 512>;
declare const FileVideo: Icon<[0, 0, 384, 512], 384, 512>;
declare const FileWord: Icon<[0, 0, 384, 512], 384, 512>;
declare const File: Icon<[0, 0, 384, 512], 384, 512>;
declare const Flag: Icon<[0, 0, 512, 512], 512, 512>;
declare const Flushed: Icon<[0, 0, 496, 512], 496, 512>;
declare const FolderOpen: Icon<[0, 0, 576, 512], 576, 512>;
declare const Folder: Icon<[0, 0, 512, 512], 512, 512>;
declare const FontAwesomeLogoFull: Icon<[0, 0, 3992, 512], 3992, 512>;
declare const FrownOpen: Icon<[0, 0, 496, 512], 496, 512>;
declare const Frown: Icon<[0, 0, 496, 512], 496, 512>;
declare const Futbol: Icon<[0, 0, 496, 512], 496, 512>;
declare const Gem: Icon<[0, 0, 576, 512], 576, 512>;
declare const Grimace: Icon<[0, 0, 496, 512], 496, 512>;
declare const GrinAlt: Icon<[0, 0, 496, 512], 496, 512>;
declare const GrinBeamSweat: Icon<[0, 0, 496, 512], 496, 512>;
declare const GrinBeam: Icon<[0, 0, 496, 512], 496, 512>;
declare const GrinHearts: Icon<[0, 0, 496, 512], 496, 512>;
declare const GrinSquintTears: Icon<[0, 0, 512, 512], 512, 512>;
declare const GrinSquint: Icon<[0, 0, 496, 512], 496, 512>;
declare const GrinStars: Icon<[0, 0, 496, 512], 496, 512>;
declare const GrinTears: Icon<[0, 0, 640, 512], 640, 512>;
declare const GrinTongueSquint: Icon<[0, 0, 496, 512], 496, 512>;
declare const GrinTongueWink: Icon<[0, 0, 496, 512], 496, 512>;
declare const GrinTongue: Icon<[0, 0, 496, 512], 496, 512>;
declare const GrinWink: Icon<[0, 0, 496, 512], 496, 512>;
declare const Grin: Icon<[0, 0, 496, 512], 496, 512>;
declare const HandLizard: Icon<[0, 0, 576, 512], 576, 512>;
declare const HandPaper: Icon<[0, 0, 448, 512], 448, 512>;
declare const HandPeace: Icon<[0, 0, 448, 512], 448, 512>;
declare const HandPointDown: Icon<[0, 0, 448, 512], 448, 512>;
declare const HandPointLeft: Icon<[0, 0, 512, 512], 512, 512>;
declare const HandPointRight: Icon<[0, 0, 512, 512], 512, 512>;
declare const HandPointUp: Icon<[0, 0, 448, 512], 448, 512>;
declare const HandPointer: Icon<[0, 0, 448, 512], 448, 512>;
declare const HandRock: Icon<[0, 0, 512, 512], 512, 512>;
declare const HandScissors: Icon<[0, 0, 512, 512], 512, 512>;
declare const HandSpock: Icon<[0, 0, 512, 512], 512, 512>;
declare const Handshake: Icon<[0, 0, 640, 512], 640, 512>;
declare const Hdd: Icon<[0, 0, 576, 512], 576, 512>;
declare const Heart: Icon<[0, 0, 512, 512], 512, 512>;
declare const Hospital: Icon<[0, 0, 448, 512], 448, 512>;
declare const Hourglass: Icon<[0, 0, 384, 512], 384, 512>;
declare const IdBadge: Icon<[0, 0, 384, 512], 384, 512>;
declare const IdCard: Icon<[0, 0, 576, 512], 576, 512>;
declare const Image: Icon<[0, 0, 512, 512], 512, 512>;
declare const Images: Icon<[0, 0, 576, 512], 576, 512>;
declare const Keyboard: Icon<[0, 0, 576, 512], 576, 512>;
declare const KissBeam: Icon<[0, 0, 496, 512], 496, 512>;
declare const KissWinkHeart: Icon<[0, 0, 504, 512], 504, 512>;
declare const Kiss: Icon<[0, 0, 496, 512], 496, 512>;
declare const LaughBeam: Icon<[0, 0, 496, 512], 496, 512>;
declare const LaughSquint: Icon<[0, 0, 496, 512], 496, 512>;
declare const LaughWink: Icon<[0, 0, 496, 512], 496, 512>;
declare const Laugh: Icon<[0, 0, 496, 512], 496, 512>;
declare const Lemon: Icon<[0, 0, 512, 512], 512, 512>;
declare const LifeRing: Icon<[0, 0, 512, 512], 512, 512>;
declare const Lightbulb: Icon<[0, 0, 352, 512], 352, 512>;
declare const ListAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const Map: Icon<[0, 0, 576, 512], 576, 512>;
declare const MehBlank: Icon<[0, 0, 496, 512], 496, 512>;
declare const MehRollingEyes: Icon<[0, 0, 496, 512], 496, 512>;
declare const Meh: Icon<[0, 0, 496, 512], 496, 512>;
declare const MinusSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const MoneyBillAlt: Icon<[0, 0, 640, 512], 640, 512>;
declare const Moon: Icon<[0, 0, 512, 512], 512, 512>;
declare const Newspaper: Icon<[0, 0, 576, 512], 576, 512>;
declare const ObjectGroup: Icon<[0, 0, 512, 512], 512, 512>;
declare const ObjectUngroup: Icon<[0, 0, 576, 512], 576, 512>;
declare const PaperPlane: Icon<[0, 0, 512, 512], 512, 512>;
declare const PauseCircle: Icon<[0, 0, 512, 512], 512, 512>;
declare const PlayCircle: Icon<[0, 0, 512, 512], 512, 512>;
declare const PlusSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const QuestionCircle: Icon<[0, 0, 512, 512], 512, 512>;
declare const Registered: Icon<[0, 0, 512, 512], 512, 512>;
declare const SadCry: Icon<[0, 0, 496, 512], 496, 512>;
declare const SadTear: Icon<[0, 0, 496, 512], 496, 512>;
declare const Save: Icon<[0, 0, 448, 512], 448, 512>;
declare const ShareSquare: Icon<[0, 0, 576, 512], 576, 512>;
declare const SmileBeam: Icon<[0, 0, 496, 512], 496, 512>;
declare const SmileWink: Icon<[0, 0, 496, 512], 496, 512>;
declare const Smile: Icon<[0, 0, 496, 512], 496, 512>;
declare const Snowflake: Icon<[0, 0, 448, 512], 448, 512>;
declare const Square: Icon<[0, 0, 448, 512], 448, 512>;
declare const StarHalf: Icon<[0, 0, 576, 512], 576, 512>;
declare const Star: Icon<[0, 0, 576, 512], 576, 512>;
declare const StickyNote: Icon<[0, 0, 448, 512], 448, 512>;
declare const StopCircle: Icon<[0, 0, 512, 512], 512, 512>;
declare const Sun: Icon<[0, 0, 512, 512], 512, 512>;
declare const Surprise: Icon<[0, 0, 496, 512], 496, 512>;
declare const ThumbsDown: Icon<[0, 0, 512, 512], 512, 512>;
declare const ThumbsUp: Icon<[0, 0, 512, 512], 512, 512>;
declare const TimesCircle: Icon<[0, 0, 512, 512], 512, 512>;
declare const Tired: Icon<[0, 0, 496, 512], 496, 512>;
declare const TrashAlt: Icon<[0, 0, 448, 512], 448, 512>;
declare const UserCircle: Icon<[0, 0, 496, 512], 496, 512>;
declare const User: Icon<[0, 0, 448, 512], 448, 512>;
declare const WindowClose: Icon<[0, 0, 512, 512], 512, 512>;
declare const WindowMaximize: Icon<[0, 0, 512, 512], 512, 512>;
declare const WindowMinimize: Icon<[0, 0, 512, 512], 512, 512>;
declare const WindowRestore: Icon<[0, 0, 512, 512], 512, 512>;

type Icons = {
    'address-book': Icon<[0, 0, 448, 512], 448, 512>,
    'address-card': Icon<[0, 0, 576, 512], 576, 512>,
    'angry': Icon<[0, 0, 496, 512], 496, 512>,
    'arrow-alt-circle-down': Icon<[0, 0, 512, 512], 512, 512>,
    'arrow-alt-circle-left': Icon<[0, 0, 512, 512], 512, 512>,
    'arrow-alt-circle-right': Icon<[0, 0, 512, 512], 512, 512>,
    'arrow-alt-circle-up': Icon<[0, 0, 512, 512], 512, 512>,
    'bell-slash': Icon<[0, 0, 640, 512], 640, 512>,
    'bell': Icon<[0, 0, 448, 512], 448, 512>,
    'bookmark': Icon<[0, 0, 384, 512], 384, 512>,
    'building': Icon<[0, 0, 448, 512], 448, 512>,
    'calendar-alt': Icon<[0, 0, 448, 512], 448, 512>,
    'calendar-check': Icon<[0, 0, 448, 512], 448, 512>,
    'calendar-minus': Icon<[0, 0, 448, 512], 448, 512>,
    'calendar-plus': Icon<[0, 0, 448, 512], 448, 512>,
    'calendar-times': Icon<[0, 0, 448, 512], 448, 512>,
    'calendar': Icon<[0, 0, 448, 512], 448, 512>,
    'caret-square-down': Icon<[0, 0, 448, 512], 448, 512>,
    'caret-square-left': Icon<[0, 0, 448, 512], 448, 512>,
    'caret-square-right': Icon<[0, 0, 448, 512], 448, 512>,
    'caret-square-up': Icon<[0, 0, 448, 512], 448, 512>,
    'chart-bar': Icon<[0, 0, 512, 512], 512, 512>,
    'check-circle': Icon<[0, 0, 512, 512], 512, 512>,
    'check-square': Icon<[0, 0, 448, 512], 448, 512>,
    'circle': Icon<[0, 0, 512, 512], 512, 512>,
    'clipboard': Icon<[0, 0, 384, 512], 384, 512>,
    'clock': Icon<[0, 0, 512, 512], 512, 512>,
    'clone': Icon<[0, 0, 512, 512], 512, 512>,
    'closed-captioning': Icon<[0, 0, 512, 512], 512, 512>,
    'comment-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'comment-dots': Icon<[0, 0, 512, 512], 512, 512>,
    'comment': Icon<[0, 0, 512, 512], 512, 512>,
    'comments': Icon<[0, 0, 576, 512], 576, 512>,
    'compass': Icon<[0, 0, 496, 512], 496, 512>,
    'copy': Icon<[0, 0, 448, 512], 448, 512>,
    'copyright': Icon<[0, 0, 512, 512], 512, 512>,
    'credit-card': Icon<[0, 0, 576, 512], 576, 512>,
    'dizzy': Icon<[0, 0, 496, 512], 496, 512>,
    'dot-circle': Icon<[0, 0, 512, 512], 512, 512>,
    'edit': Icon<[0, 0, 576, 512], 576, 512>,
    'envelope-open': Icon<[0, 0, 512, 512], 512, 512>,
    'envelope': Icon<[0, 0, 512, 512], 512, 512>,
    'eye-slash': Icon<[0, 0, 640, 512], 640, 512>,
    'eye': Icon<[0, 0, 576, 512], 576, 512>,
    'file-alt': Icon<[0, 0, 384, 512], 384, 512>,
    'file-archive': Icon<[0, 0, 384, 512], 384, 512>,
    'file-audio': Icon<[0, 0, 384, 512], 384, 512>,
    'file-code': Icon<[0, 0, 384, 512], 384, 512>,
    'file-excel': Icon<[0, 0, 384, 512], 384, 512>,
    'file-image': Icon<[0, 0, 384, 512], 384, 512>,
    'file-pdf': Icon<[0, 0, 384, 512], 384, 512>,
    'file-powerpoint': Icon<[0, 0, 384, 512], 384, 512>,
    'file-video': Icon<[0, 0, 384, 512], 384, 512>,
    'file-word': Icon<[0, 0, 384, 512], 384, 512>,
    'file': Icon<[0, 0, 384, 512], 384, 512>,
    'flag': Icon<[0, 0, 512, 512], 512, 512>,
    'flushed': Icon<[0, 0, 496, 512], 496, 512>,
    'folder-open': Icon<[0, 0, 576, 512], 576, 512>,
    'folder': Icon<[0, 0, 512, 512], 512, 512>,
    'font-awesome-logo-full': Icon<[0, 0, 3992, 512], 3992, 512>,
    'frown-open': Icon<[0, 0, 496, 512], 496, 512>,
    'frown': Icon<[0, 0, 496, 512], 496, 512>,
    'futbol': Icon<[0, 0, 496, 512], 496, 512>,
    'gem': Icon<[0, 0, 576, 512], 576, 512>,
    'grimace': Icon<[0, 0, 496, 512], 496, 512>,
    'grin-alt': Icon<[0, 0, 496, 512], 496, 512>,
    'grin-beam-sweat': Icon<[0, 0, 496, 512], 496, 512>,
    'grin-beam': Icon<[0, 0, 496, 512], 496, 512>,
    'grin-hearts': Icon<[0, 0, 496, 512], 496, 512>,
    'grin-squint-tears': Icon<[0, 0, 512, 512], 512, 512>,
    'grin-squint': Icon<[0, 0, 496, 512], 496, 512>,
    'grin-stars': Icon<[0, 0, 496, 512], 496, 512>,
    'grin-tears': Icon<[0, 0, 640, 512], 640, 512>,
    'grin-tongue-squint': Icon<[0, 0, 496, 512], 496, 512>,
    'grin-tongue-wink': Icon<[0, 0, 496, 512], 496, 512>,
    'grin-tongue': Icon<[0, 0, 496, 512], 496, 512>,
    'grin-wink': Icon<[0, 0, 496, 512], 496, 512>,
    'grin': Icon<[0, 0, 496, 512], 496, 512>,
    'hand-lizard': Icon<[0, 0, 576, 512], 576, 512>,
    'hand-paper': Icon<[0, 0, 448, 512], 448, 512>,
    'hand-peace': Icon<[0, 0, 448, 512], 448, 512>,
    'hand-point-down': Icon<[0, 0, 448, 512], 448, 512>,
    'hand-point-left': Icon<[0, 0, 512, 512], 512, 512>,
    'hand-point-right': Icon<[0, 0, 512, 512], 512, 512>,
    'hand-point-up': Icon<[0, 0, 448, 512], 448, 512>,
    'hand-pointer': Icon<[0, 0, 448, 512], 448, 512>,
    'hand-rock': Icon<[0, 0, 512, 512], 512, 512>,
    'hand-scissors': Icon<[0, 0, 512, 512], 512, 512>,
    'hand-spock': Icon<[0, 0, 512, 512], 512, 512>,
    'handshake': Icon<[0, 0, 640, 512], 640, 512>,
    'hdd': Icon<[0, 0, 576, 512], 576, 512>,
    'heart': Icon<[0, 0, 512, 512], 512, 512>,
    'hospital': Icon<[0, 0, 448, 512], 448, 512>,
    'hourglass': Icon<[0, 0, 384, 512], 384, 512>,
    'id-badge': Icon<[0, 0, 384, 512], 384, 512>,
    'id-card': Icon<[0, 0, 576, 512], 576, 512>,
    'image': Icon<[0, 0, 512, 512], 512, 512>,
    'images': Icon<[0, 0, 576, 512], 576, 512>,
    'keyboard': Icon<[0, 0, 576, 512], 576, 512>,
    'kiss-beam': Icon<[0, 0, 496, 512], 496, 512>,
    'kiss-wink-heart': Icon<[0, 0, 504, 512], 504, 512>,
    'kiss': Icon<[0, 0, 496, 512], 496, 512>,
    'laugh-beam': Icon<[0, 0, 496, 512], 496, 512>,
    'laugh-squint': Icon<[0, 0, 496, 512], 496, 512>,
    'laugh-wink': Icon<[0, 0, 496, 512], 496, 512>,
    'laugh': Icon<[0, 0, 496, 512], 496, 512>,
    'lemon': Icon<[0, 0, 512, 512], 512, 512>,
    'life-ring': Icon<[0, 0, 512, 512], 512, 512>,
    'lightbulb': Icon<[0, 0, 352, 512], 352, 512>,
    'list-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'map': Icon<[0, 0, 576, 512], 576, 512>,
    'meh-blank': Icon<[0, 0, 496, 512], 496, 512>,
    'meh-rolling-eyes': Icon<[0, 0, 496, 512], 496, 512>,
    'meh': Icon<[0, 0, 496, 512], 496, 512>,
    'minus-square': Icon<[0, 0, 448, 512], 448, 512>,
    'money-bill-alt': Icon<[0, 0, 640, 512], 640, 512>,
    'moon': Icon<[0, 0, 512, 512], 512, 512>,
    'newspaper': Icon<[0, 0, 576, 512], 576, 512>,
    'object-group': Icon<[0, 0, 512, 512], 512, 512>,
    'object-ungroup': Icon<[0, 0, 576, 512], 576, 512>,
    'paper-plane': Icon<[0, 0, 512, 512], 512, 512>,
    'pause-circle': Icon<[0, 0, 512, 512], 512, 512>,
    'play-circle': Icon<[0, 0, 512, 512], 512, 512>,
    'plus-square': Icon<[0, 0, 448, 512], 448, 512>,
    'question-circle': Icon<[0, 0, 512, 512], 512, 512>,
    'registered': Icon<[0, 0, 512, 512], 512, 512>,
    'sad-cry': Icon<[0, 0, 496, 512], 496, 512>,
    'sad-tear': Icon<[0, 0, 496, 512], 496, 512>,
    'save': Icon<[0, 0, 448, 512], 448, 512>,
    'share-square': Icon<[0, 0, 576, 512], 576, 512>,
    'smile-beam': Icon<[0, 0, 496, 512], 496, 512>,
    'smile-wink': Icon<[0, 0, 496, 512], 496, 512>,
    'smile': Icon<[0, 0, 496, 512], 496, 512>,
    'snowflake': Icon<[0, 0, 448, 512], 448, 512>,
    'square': Icon<[0, 0, 448, 512], 448, 512>,
    'star-half': Icon<[0, 0, 576, 512], 576, 512>,
    'star': Icon<[0, 0, 576, 512], 576, 512>,
    'sticky-note': Icon<[0, 0, 448, 512], 448, 512>,
    'stop-circle': Icon<[0, 0, 512, 512], 512, 512>,
    'sun': Icon<[0, 0, 512, 512], 512, 512>,
    'surprise': Icon<[0, 0, 496, 512], 496, 512>,
    'thumbs-down': Icon<[0, 0, 512, 512], 512, 512>,
    'thumbs-up': Icon<[0, 0, 512, 512], 512, 512>,
    'times-circle': Icon<[0, 0, 512, 512], 512, 512>,
    'tired': Icon<[0, 0, 496, 512], 496, 512>,
    'trash-alt': Icon<[0, 0, 448, 512], 448, 512>,
    'user-circle': Icon<[0, 0, 496, 512], 496, 512>,
    'user': Icon<[0, 0, 448, 512], 448, 512>,
    'window-close': Icon<[0, 0, 512, 512], 512, 512>,
    'window-maximize': Icon<[0, 0, 512, 512], 512, 512>,
    'window-minimize': Icon<[0, 0, 512, 512], 512, 512>,
    'window-restore': Icon<[0, 0, 512, 512], 512, 512>
};

declare const icons: Icons;

export default icons;
export {
    AddressBook,
    AddressCard,
    Angry,
    ArrowAltCircleDown,
    ArrowAltCircleLeft,
    ArrowAltCircleRight,
    ArrowAltCircleUp,
    BellSlash,
    Bell,
    Bookmark,
    Building,
    CalendarAlt,
    CalendarCheck,
    CalendarMinus,
    CalendarPlus,
    CalendarTimes,
    Calendar,
    CaretSquareDown,
    CaretSquareLeft,
    CaretSquareRight,
    CaretSquareUp,
    ChartBar,
    CheckCircle,
    CheckSquare,
    Circle,
    Clipboard,
    Clock,
    Clone,
    ClosedCaptioning,
    CommentAlt,
    CommentDots,
    Comment,
    Comments,
    Compass,
    Copy,
    Copyright,
    CreditCard,
    Dizzy,
    DotCircle,
    Edit,
    EnvelopeOpen,
    Envelope,
    EyeSlash,
    Eye,
    FileAlt,
    FileArchive,
    FileAudio,
    FileCode,
    FileExcel,
    FileImage,
    FilePdf,
    FilePowerpoint,
    FileVideo,
    FileWord,
    File,
    Flag,
    Flushed,
    FolderOpen,
    Folder,
    FontAwesomeLogoFull,
    FrownOpen,
    Frown,
    Futbol,
    Gem,
    Grimace,
    GrinAlt,
    GrinBeamSweat,
    GrinBeam,
    GrinHearts,
    GrinSquintTears,
    GrinSquint,
    GrinStars,
    GrinTears,
    GrinTongueSquint,
    GrinTongueWink,
    GrinTongue,
    GrinWink,
    Grin,
    HandLizard,
    HandPaper,
    HandPeace,
    HandPointDown,
    HandPointLeft,
    HandPointRight,
    HandPointUp,
    HandPointer,
    HandRock,
    HandScissors,
    HandSpock,
    Handshake,
    Hdd,
    Heart,
    Hospital,
    Hourglass,
    IdBadge,
    IdCard,
    Image,
    Images,
    Keyboard,
    KissBeam,
    KissWinkHeart,
    Kiss,
    LaughBeam,
    LaughSquint,
    LaughWink,
    Laugh,
    Lemon,
    LifeRing,
    Lightbulb,
    ListAlt,
    Map,
    MehBlank,
    MehRollingEyes,
    Meh,
    MinusSquare,
    MoneyBillAlt,
    Moon,
    Newspaper,
    ObjectGroup,
    ObjectUngroup,
    PaperPlane,
    PauseCircle,
    PlayCircle,
    PlusSquare,
    QuestionCircle,
    Registered,
    SadCry,
    SadTear,
    Save,
    ShareSquare,
    SmileBeam,
    SmileWink,
    Smile,
    Snowflake,
    Square,
    StarHalf,
    Star,
    StickyNote,
    StopCircle,
    Sun,
    Surprise,
    ThumbsDown,
    ThumbsUp,
    TimesCircle,
    Tired,
    TrashAlt,
    UserCircle,
    User,
    WindowClose,
    WindowMaximize,
    WindowMinimize,
    WindowRestore
};
