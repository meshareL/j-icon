/* THIS FILE IS GENERATED. DO NOT EDIT IT. */
import {CreateElement, VNode} from 'vue';
import {Icon} from '@tomoeed/j-icon';

declare const AccessibleIcon: Icon<[0, 0, 448, 512], 448, 512>;
declare const Accusoft: Icon<[0, 0, 640, 512], 640, 512>;
declare const AcquisitionsIncorporated: Icon<[0, 0, 384, 512], 384, 512>;
declare const Adn: Icon<[0, 0, 496, 512], 496, 512>;
declare const Adobe: Icon<[0, 0, 512, 512], 512, 512>;
declare const Adversal: Icon<[0, 0, 512, 512], 512, 512>;
declare const Affiliatetheme: Icon<[0, 0, 512, 512], 512, 512>;
declare const Airbnb: Icon<[0, 0, 448, 512], 448, 512>;
declare const Algolia: Icon<[0, 0, 448, 512], 448, 512>;
declare const Alipay: Icon<[0, 0, 448, 512], 448, 512>;
declare const AmazonPay: Icon<[0, 0, 640, 512], 640, 512>;
declare const Amazon: Icon<[0, 0, 448, 512], 448, 512>;
declare const Amilia: Icon<[0, 0, 448, 512], 448, 512>;
declare const Android: Icon<[0, 0, 576, 512], 576, 512>;
declare const Angellist: Icon<[0, 0, 448, 512], 448, 512>;
declare const Angrycreative: Icon<[0, 0, 640, 512], 640, 512>;
declare const Angular: Icon<[0, 0, 448, 512], 448, 512>;
declare const AppStoreIos: Icon<[0, 0, 448, 512], 448, 512>;
declare const AppStore: Icon<[0, 0, 512, 512], 512, 512>;
declare const Apper: Icon<[0, 0, 640, 512], 640, 512>;
declare const ApplePay: Icon<[0, 0, 640, 512], 640, 512>;
declare const Apple: Icon<[0, 0, 384, 512], 384, 512>;
declare const Artstation: Icon<[0, 0, 512, 512], 512, 512>;
declare const Asymmetrik: Icon<[0, 0, 576, 512], 576, 512>;
declare const Atlassian: Icon<[0, 0, 512, 512], 512, 512>;
declare const Audible: Icon<[0, 0, 640, 512], 640, 512>;
declare const Autoprefixer: Icon<[0, 0, 640, 512], 640, 512>;
declare const Avianex: Icon<[0, 0, 512, 512], 512, 512>;
declare const Aviato: Icon<[0, 0, 640, 512], 640, 512>;
declare const Aws: Icon<[0, 0, 640, 512], 640, 512>;
declare const Bandcamp: Icon<[0, 0, 496, 512], 496, 512>;
declare const BattleNet: Icon<[0, 0, 512, 512], 512, 512>;
declare const BehanceSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Behance: Icon<[0, 0, 576, 512], 576, 512>;
declare const Bimobject: Icon<[0, 0, 448, 512], 448, 512>;
declare const Bitbucket: Icon<[0, 0, 512, 512], 512, 512>;
declare const Bitcoin: Icon<[0, 0, 512, 512], 512, 512>;
declare const Bity: Icon<[0, 0, 496, 512], 496, 512>;
declare const BlackTie: Icon<[0, 0, 448, 512], 448, 512>;
declare const Blackberry: Icon<[0, 0, 512, 512], 512, 512>;
declare const BloggerB: Icon<[0, 0, 448, 512], 448, 512>;
declare const Blogger: Icon<[0, 0, 448, 512], 448, 512>;
declare const BluetoothB: Icon<[0, 0, 320, 512], 320, 512>;
declare const Bluetooth: Icon<[0, 0, 448, 512], 448, 512>;
declare const Bootstrap: Icon<[0, 0, 448, 512], 448, 512>;
declare const Btc: Icon<[0, 0, 384, 512], 384, 512>;
declare const Buffer: Icon<[0, 0, 448, 512], 448, 512>;
declare const Buromobelexperte: Icon<[0, 0, 448, 512], 448, 512>;
declare const BuyNLarge: Icon<[0, 0, 576, 512], 576, 512>;
declare const Buysellads: Icon<[0, 0, 448, 512], 448, 512>;
declare const CanadianMapleLeaf: Icon<[0, 0, 512, 512], 512, 512>;
declare const CcAmazonPay: Icon<[0, 0, 576, 512], 576, 512>;
declare const CcAmex: Icon<[0, 0, 576, 512], 576, 512>;
declare const CcApplePay: Icon<[0, 0, 576, 512], 576, 512>;
declare const CcDinersClub: Icon<[0, 0, 576, 512], 576, 512>;
declare const CcDiscover: Icon<[0, 0, 576, 512], 576, 512>;
declare const CcJcb: Icon<[0, 0, 576, 512], 576, 512>;
declare const CcMastercard: Icon<[0, 0, 576, 512], 576, 512>;
declare const CcPaypal: Icon<[0, 0, 576, 512], 576, 512>;
declare const CcStripe: Icon<[0, 0, 576, 512], 576, 512>;
declare const CcVisa: Icon<[0, 0, 576, 512], 576, 512>;
declare const Centercode: Icon<[0, 0, 512, 512], 512, 512>;
declare const Centos: Icon<[0, 0, 448, 512], 448, 512>;
declare const Chrome: Icon<[0, 0, 496, 512], 496, 512>;
declare const Chromecast: Icon<[0, 0, 512, 512], 512, 512>;
declare const Cloudscale: Icon<[0, 0, 448, 512], 448, 512>;
declare const Cloudsmith: Icon<[0, 0, 332, 512], 332, 512>;
declare const Cloudversify: Icon<[0, 0, 616, 512], 616, 512>;
declare const Codepen: Icon<[0, 0, 512, 512], 512, 512>;
declare const Codiepie: Icon<[0, 0, 472, 512], 472, 512>;
declare const Confluence: Icon<[0, 0, 512, 512], 512, 512>;
declare const Connectdevelop: Icon<[0, 0, 576, 512], 576, 512>;
declare const Contao: Icon<[0, 0, 512, 512], 512, 512>;
declare const CottonBureau: Icon<[0, 0, 512, 512], 512, 512>;
declare const Cpanel: Icon<[0, 0, 640, 512], 640, 512>;
declare const CreativeCommonsBy: Icon<[0, 0, 496, 512], 496, 512>;
declare const CreativeCommonsNcEu: Icon<[0, 0, 496, 512], 496, 512>;
declare const CreativeCommonsNcJp: Icon<[0, 0, 496, 512], 496, 512>;
declare const CreativeCommonsNc: Icon<[0, 0, 496, 512], 496, 512>;
declare const CreativeCommonsNd: Icon<[0, 0, 496, 512], 496, 512>;
declare const CreativeCommonsPdAlt: Icon<[0, 0, 496, 512], 496, 512>;
declare const CreativeCommonsPd: Icon<[0, 0, 496, 512], 496, 512>;
declare const CreativeCommonsRemix: Icon<[0, 0, 496, 512], 496, 512>;
declare const CreativeCommonsSa: Icon<[0, 0, 496, 512], 496, 512>;
declare const CreativeCommonsSamplingPlus: Icon<[0, 0, 496, 512], 496, 512>;
declare const CreativeCommonsSampling: Icon<[0, 0, 496, 512], 496, 512>;
declare const CreativeCommonsShare: Icon<[0, 0, 496, 512], 496, 512>;
declare const CreativeCommonsZero: Icon<[0, 0, 496, 512], 496, 512>;
declare const CreativeCommons: Icon<[0, 0, 496, 512], 496, 512>;
declare const CriticalRole: Icon<[0, 0, 448, 512], 448, 512>;
declare const Css3Alt: Icon<[0, 0, 384, 512], 384, 512>;
declare const Css3: Icon<[0, 0, 512, 512], 512, 512>;
declare const Cuttlefish: Icon<[0, 0, 440, 512], 440, 512>;
declare const DAndDBeyond: Icon<[0, 0, 640, 512], 640, 512>;
declare const DAndD: Icon<[0, 0, 576, 512], 576, 512>;
declare const Dailymotion: Icon<[0, 0, 448, 512], 448, 512>;
declare const Dashcube: Icon<[0, 0, 448, 512], 448, 512>;
declare const Delicious: Icon<[0, 0, 448, 512], 448, 512>;
declare const Deploydog: Icon<[0, 0, 512, 512], 512, 512>;
declare const Deskpro: Icon<[0, 0, 480, 512], 480, 512>;
declare const Dev: Icon<[0, 0, 448, 512], 448, 512>;
declare const Deviantart: Icon<[0, 0, 320, 512], 320, 512>;
declare const Dhl: Icon<[0, 0, 640, 512], 640, 512>;
declare const Diaspora: Icon<[0, 0, 512, 512], 512, 512>;
declare const Digg: Icon<[0, 0, 512, 512], 512, 512>;
declare const DigitalOcean: Icon<[0, 0, 512, 512], 512, 512>;
declare const Discord: Icon<[0, 0, 448, 512], 448, 512>;
declare const Discourse: Icon<[0, 0, 448, 512], 448, 512>;
declare const Dochub: Icon<[0, 0, 416, 512], 416, 512>;
declare const Docker: Icon<[0, 0, 640, 512], 640, 512>;
declare const Draft2digital: Icon<[0, 0, 480, 512], 480, 512>;
declare const DribbbleSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Dribbble: Icon<[0, 0, 512, 512], 512, 512>;
declare const Dropbox: Icon<[0, 0, 528, 512], 528, 512>;
declare const Drupal: Icon<[0, 0, 448, 512], 448, 512>;
declare const Dyalog: Icon<[0, 0, 416, 512], 416, 512>;
declare const Earlybirds: Icon<[0, 0, 480, 512], 480, 512>;
declare const Ebay: Icon<[0, 0, 640, 512], 640, 512>;
declare const Edge: Icon<[0, 0, 512, 512], 512, 512>;
declare const Elementor: Icon<[0, 0, 448, 512], 448, 512>;
declare const Ello: Icon<[0, 0, 496, 512], 496, 512>;
declare const Ember: Icon<[0, 0, 640, 512], 640, 512>;
declare const Empire: Icon<[0, 0, 496, 512], 496, 512>;
declare const Envira: Icon<[0, 0, 448, 512], 448, 512>;
declare const Erlang: Icon<[0, 0, 640, 512], 640, 512>;
declare const Ethereum: Icon<[0, 0, 320, 512], 320, 512>;
declare const Etsy: Icon<[0, 0, 384, 512], 384, 512>;
declare const Evernote: Icon<[0, 0, 384, 512], 384, 512>;
declare const Expeditedssl: Icon<[0, 0, 496, 512], 496, 512>;
declare const FacebookF: Icon<[0, 0, 320, 512], 320, 512>;
declare const FacebookMessenger: Icon<[0, 0, 512, 512], 512, 512>;
declare const FacebookSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Facebook: Icon<[0, 0, 512, 512], 512, 512>;
declare const FantasyFlightGames: Icon<[0, 0, 512, 512], 512, 512>;
declare const Fedex: Icon<[0, 0, 640, 512], 640, 512>;
declare const Fedora: Icon<[0, 0, 448, 512], 448, 512>;
declare const Figma: Icon<[0, 0, 384, 512], 384, 512>;
declare const FirefoxBrowser: Icon<[0, 0, 512, 512], 512, 512>;
declare const Firefox: Icon<[0, 0, 512, 512], 512, 512>;
declare const FirstOrderAlt: Icon<[0, 0, 496, 512], 496, 512>;
declare const FirstOrder: Icon<[0, 0, 448, 512], 448, 512>;
declare const Firstdraft: Icon<[0, 0, 384, 512], 384, 512>;
declare const Flickr: Icon<[0, 0, 448, 512], 448, 512>;
declare const Flipboard: Icon<[0, 0, 448, 512], 448, 512>;
declare const Fly: Icon<[0, 0, 384, 512], 384, 512>;
declare const FontAwesomeAlt: Icon<[0, 0, 448, 512], 448, 512>;
declare const FontAwesomeFlag: Icon<[0, 0, 448, 512], 448, 512>;
declare const FontAwesomeLogoFull: Icon<[0, 0, 3992, 512], 3992, 512>;
declare const FontAwesome: Icon<[0, 0, 448, 512], 448, 512>;
declare const FonticonsFi: Icon<[0, 0, 384, 512], 384, 512>;
declare const Fonticons: Icon<[0, 0, 448, 512], 448, 512>;
declare const FortAwesomeAlt: Icon<[0, 0, 512, 512], 512, 512>;
declare const FortAwesome: Icon<[0, 0, 512, 512], 512, 512>;
declare const Forumbee: Icon<[0, 0, 448, 512], 448, 512>;
declare const Foursquare: Icon<[0, 0, 368, 512], 368, 512>;
declare const FreeCodeCamp: Icon<[0, 0, 576, 512], 576, 512>;
declare const Freebsd: Icon<[0, 0, 448, 512], 448, 512>;
declare const Fulcrum: Icon<[0, 0, 320, 512], 320, 512>;
declare const GalacticRepublic: Icon<[0, 0, 496, 512], 496, 512>;
declare const GalacticSenate: Icon<[0, 0, 512, 512], 512, 512>;
declare const GetPocket: Icon<[0, 0, 448, 512], 448, 512>;
declare const GgCircle: Icon<[0, 0, 512, 512], 512, 512>;
declare const Gg: Icon<[0, 0, 512, 512], 512, 512>;
declare const GitAlt: Icon<[0, 0, 448, 512], 448, 512>;
declare const GitSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Git: Icon<[0, 0, 512, 512], 512, 512>;
declare const GithubAlt: Icon<[0, 0, 480, 512], 480, 512>;
declare const GithubSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Github: Icon<[0, 0, 496, 512], 496, 512>;
declare const Gitkraken: Icon<[0, 0, 592, 512], 592, 512>;
declare const Gitlab: Icon<[0, 0, 512, 512], 512, 512>;
declare const Gitter: Icon<[0, 0, 384, 512], 384, 512>;
declare const GlideG: Icon<[0, 0, 448, 512], 448, 512>;
declare const Glide: Icon<[0, 0, 448, 512], 448, 512>;
declare const Gofore: Icon<[0, 0, 400, 512], 400, 512>;
declare const GoodreadsG: Icon<[0, 0, 384, 512], 384, 512>;
declare const Goodreads: Icon<[0, 0, 448, 512], 448, 512>;
declare const GoogleDrive: Icon<[0, 0, 512, 512], 512, 512>;
declare const GooglePlay: Icon<[0, 0, 512, 512], 512, 512>;
declare const GooglePlusG: Icon<[0, 0, 640, 512], 640, 512>;
declare const GooglePlusSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const GooglePlus: Icon<[0, 0, 496, 512], 496, 512>;
declare const GoogleWallet: Icon<[0, 0, 448, 512], 448, 512>;
declare const Google: Icon<[0, 0, 488, 512], 488, 512>;
declare const Gratipay: Icon<[0, 0, 496, 512], 496, 512>;
declare const Grav: Icon<[0, 0, 512, 512], 512, 512>;
declare const Gripfire: Icon<[0, 0, 384, 512], 384, 512>;
declare const Grunt: Icon<[0, 0, 384, 512], 384, 512>;
declare const Gulp: Icon<[0, 0, 256, 512], 256, 512>;
declare const HackerNewsSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const HackerNews: Icon<[0, 0, 448, 512], 448, 512>;
declare const Hackerrank: Icon<[0, 0, 512, 512], 512, 512>;
declare const Hips: Icon<[0, 0, 640, 512], 640, 512>;
declare const HireAHelper: Icon<[0, 0, 512, 512], 512, 512>;
declare const Hooli: Icon<[0, 0, 640, 512], 640, 512>;
declare const Hornbill: Icon<[0, 0, 512, 512], 512, 512>;
declare const Hotjar: Icon<[0, 0, 448, 512], 448, 512>;
declare const Houzz: Icon<[0, 0, 448, 512], 448, 512>;
declare const Html5: Icon<[0, 0, 384, 512], 384, 512>;
declare const Hubspot: Icon<[0, 0, 512, 512], 512, 512>;
declare const Ideal: Icon<[0, 0, 576, 512], 576, 512>;
declare const Imdb: Icon<[0, 0, 448, 512], 448, 512>;
declare const InstagramSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Instagram: Icon<[0, 0, 448, 512], 448, 512>;
declare const Intercom: Icon<[0, 0, 448, 512], 448, 512>;
declare const InternetExplorer: Icon<[0, 0, 512, 512], 512, 512>;
declare const Invision: Icon<[0, 0, 448, 512], 448, 512>;
declare const Ioxhost: Icon<[0, 0, 640, 512], 640, 512>;
declare const ItchIo: Icon<[0, 0, 512, 512], 512, 512>;
declare const ItunesNote: Icon<[0, 0, 384, 512], 384, 512>;
declare const Itunes: Icon<[0, 0, 448, 512], 448, 512>;
declare const Java: Icon<[0, 0, 384, 512], 384, 512>;
declare const JediOrder: Icon<[0, 0, 448, 512], 448, 512>;
declare const Jenkins: Icon<[0, 0, 512, 512], 512, 512>;
declare const Jira: Icon<[0, 0, 496, 512], 496, 512>;
declare const Joget: Icon<[0, 0, 496, 512], 496, 512>;
declare const Joomla: Icon<[0, 0, 448, 512], 448, 512>;
declare const JsSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Js: Icon<[0, 0, 448, 512], 448, 512>;
declare const Jsfiddle: Icon<[0, 0, 576, 512], 576, 512>;
declare const Kaggle: Icon<[0, 0, 320, 512], 320, 512>;
declare const Keybase: Icon<[0, 0, 448, 512], 448, 512>;
declare const Keycdn: Icon<[0, 0, 512, 512], 512, 512>;
declare const KickstarterK: Icon<[0, 0, 384, 512], 384, 512>;
declare const Kickstarter: Icon<[0, 0, 448, 512], 448, 512>;
declare const Korvue: Icon<[0, 0, 446, 512], 446, 512>;
declare const Laravel: Icon<[0, 0, 512, 512], 512, 512>;
declare const LastfmSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Lastfm: Icon<[0, 0, 512, 512], 512, 512>;
declare const Leanpub: Icon<[0, 0, 576, 512], 576, 512>;
declare const Less: Icon<[0, 0, 640, 512], 640, 512>;
declare const Line: Icon<[0, 0, 448, 512], 448, 512>;
declare const LinkedinIn: Icon<[0, 0, 448, 512], 448, 512>;
declare const Linkedin: Icon<[0, 0, 448, 512], 448, 512>;
declare const Linode: Icon<[0, 0, 448, 512], 448, 512>;
declare const Linux: Icon<[0, 0, 448, 512], 448, 512>;
declare const Lyft: Icon<[0, 0, 512, 512], 512, 512>;
declare const Magento: Icon<[0, 0, 448, 512], 448, 512>;
declare const Mailchimp: Icon<[0, 0, 448, 512], 448, 512>;
declare const Mandalorian: Icon<[0, 0, 448, 512], 448, 512>;
declare const Markdown: Icon<[0, 0, 640, 512], 640, 512>;
declare const Mastodon: Icon<[0, 0, 448, 512], 448, 512>;
declare const Maxcdn: Icon<[0, 0, 512, 512], 512, 512>;
declare const Mdb: Icon<[0, 0, 576, 512], 576, 512>;
declare const Medapps: Icon<[0, 0, 320, 512], 320, 512>;
declare const MediumM: Icon<[0, 0, 512, 512], 512, 512>;
declare const Medium: Icon<[0, 0, 448, 512], 448, 512>;
declare const Medrt: Icon<[0, 0, 544, 512], 544, 512>;
declare const Meetup: Icon<[0, 0, 512, 512], 512, 512>;
declare const Megaport: Icon<[0, 0, 496, 512], 496, 512>;
declare const Mendeley: Icon<[0, 0, 640, 512], 640, 512>;
declare const Microblog: Icon<[0, 0, 448, 512], 448, 512>;
declare const Microsoft: Icon<[0, 0, 448, 512], 448, 512>;
declare const Mix: Icon<[0, 0, 448, 512], 448, 512>;
declare const Mixcloud: Icon<[0, 0, 640, 512], 640, 512>;
declare const Mixer: Icon<[0, 0, 512, 512], 512, 512>;
declare const Mizuni: Icon<[0, 0, 496, 512], 496, 512>;
declare const Modx: Icon<[0, 0, 448, 512], 448, 512>;
declare const Monero: Icon<[0, 0, 496, 512], 496, 512>;
declare const Napster: Icon<[0, 0, 496, 512], 496, 512>;
declare const Neos: Icon<[0, 0, 512, 512], 512, 512>;
declare const Nimblr: Icon<[0, 0, 384, 512], 384, 512>;
declare const NodeJs: Icon<[0, 0, 448, 512], 448, 512>;
declare const Node: Icon<[0, 0, 640, 512], 640, 512>;
declare const Npm: Icon<[0, 0, 576, 512], 576, 512>;
declare const Ns8: Icon<[0, 0, 640, 512], 640, 512>;
declare const Nutritionix: Icon<[0, 0, 400, 512], 400, 512>;
declare const OdnoklassnikiSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Odnoklassniki: Icon<[0, 0, 320, 512], 320, 512>;
declare const OldRepublic: Icon<[0, 0, 496, 512], 496, 512>;
declare const Opencart: Icon<[0, 0, 640, 512], 640, 512>;
declare const Openid: Icon<[0, 0, 448, 512], 448, 512>;
declare const Opera: Icon<[0, 0, 496, 512], 496, 512>;
declare const OptinMonster: Icon<[0, 0, 576, 512], 576, 512>;
declare const Orcid: Icon<[0, 0, 512, 512], 512, 512>;
declare const Osi: Icon<[0, 0, 512, 512], 512, 512>;
declare const Page4: Icon<[0, 0, 496, 512], 496, 512>;
declare const Pagelines: Icon<[0, 0, 384, 512], 384, 512>;
declare const Palfed: Icon<[0, 0, 576, 512], 576, 512>;
declare const Patreon: Icon<[0, 0, 512, 512], 512, 512>;
declare const Paypal: Icon<[0, 0, 384, 512], 384, 512>;
declare const PennyArcade: Icon<[0, 0, 640, 512], 640, 512>;
declare const Periscope: Icon<[0, 0, 448, 512], 448, 512>;
declare const Phabricator: Icon<[0, 0, 496, 512], 496, 512>;
declare const PhoenixFramework: Icon<[0, 0, 640, 512], 640, 512>;
declare const PhoenixSquadron: Icon<[0, 0, 512, 512], 512, 512>;
declare const Php: Icon<[0, 0, 640, 512], 640, 512>;
declare const PiedPiperAlt: Icon<[0, 0, 576, 512], 576, 512>;
declare const PiedPiperHat: Icon<[0, 0, 640, 512], 640, 512>;
declare const PiedPiperPp: Icon<[0, 0, 448, 512], 448, 512>;
declare const PiedPiperSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const PiedPiper: Icon<[0, 0, 480, 512], 480, 512>;
declare const PinterestP: Icon<[0, 0, 384, 512], 384, 512>;
declare const PinterestSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Pinterest: Icon<[0, 0, 496, 512], 496, 512>;
declare const Playstation: Icon<[0, 0, 576, 512], 576, 512>;
declare const ProductHunt: Icon<[0, 0, 512, 512], 512, 512>;
declare const Pushed: Icon<[0, 0, 432, 512], 432, 512>;
declare const Python: Icon<[0, 0, 448, 512], 448, 512>;
declare const Qq: Icon<[0, 0, 448, 512], 448, 512>;
declare const Quinscape: Icon<[0, 0, 512, 512], 512, 512>;
declare const Quora: Icon<[0, 0, 448, 512], 448, 512>;
declare const RProject: Icon<[0, 0, 581, 512], 581, 512>;
declare const RaspberryPi: Icon<[0, 0, 407, 512], 407, 512>;
declare const Ravelry: Icon<[0, 0, 512, 512], 512, 512>;
declare const React: Icon<[0, 0, 512, 512], 512, 512>;
declare const Reacteurope: Icon<[0, 0, 576, 512], 576, 512>;
declare const Readme: Icon<[0, 0, 576, 512], 576, 512>;
declare const Rebel: Icon<[0, 0, 512, 512], 512, 512>;
declare const RedRiver: Icon<[0, 0, 448, 512], 448, 512>;
declare const RedditAlien: Icon<[0, 0, 512, 512], 512, 512>;
declare const RedditSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Reddit: Icon<[0, 0, 512, 512], 512, 512>;
declare const Redhat: Icon<[0, 0, 512, 512], 512, 512>;
declare const Renren: Icon<[0, 0, 512, 512], 512, 512>;
declare const Replyd: Icon<[0, 0, 448, 512], 448, 512>;
declare const Researchgate: Icon<[0, 0, 448, 512], 448, 512>;
declare const Resolving: Icon<[0, 0, 496, 512], 496, 512>;
declare const Rev: Icon<[0, 0, 448, 512], 448, 512>;
declare const Rocketchat: Icon<[0, 0, 576, 512], 576, 512>;
declare const Rockrms: Icon<[0, 0, 496, 512], 496, 512>;
declare const Safari: Icon<[0, 0, 512, 512], 512, 512>;
declare const Salesforce: Icon<[0, 0, 640, 512], 640, 512>;
declare const Sass: Icon<[0, 0, 640, 512], 640, 512>;
declare const Schlix: Icon<[0, 0, 448, 512], 448, 512>;
declare const Scribd: Icon<[0, 0, 384, 512], 384, 512>;
declare const Searchengin: Icon<[0, 0, 460, 512], 460, 512>;
declare const Sellcast: Icon<[0, 0, 448, 512], 448, 512>;
declare const Sellsy: Icon<[0, 0, 640, 512], 640, 512>;
declare const Servicestack: Icon<[0, 0, 496, 512], 496, 512>;
declare const Shirtsinbulk: Icon<[0, 0, 448, 512], 448, 512>;
declare const Shopify: Icon<[0, 0, 448, 512], 448, 512>;
declare const Shopware: Icon<[0, 0, 512, 512], 512, 512>;
declare const Simplybuilt: Icon<[0, 0, 512, 512], 512, 512>;
declare const Sistrix: Icon<[0, 0, 448, 512], 448, 512>;
declare const Sith: Icon<[0, 0, 448, 512], 448, 512>;
declare const Sketch: Icon<[0, 0, 512, 512], 512, 512>;
declare const Skyatlas: Icon<[0, 0, 640, 512], 640, 512>;
declare const Skype: Icon<[0, 0, 448, 512], 448, 512>;
declare const SlackHash: Icon<[0, 0, 448, 512], 448, 512>;
declare const Slack: Icon<[0, 0, 448, 512], 448, 512>;
declare const Slideshare: Icon<[0, 0, 512, 512], 512, 512>;
declare const SnapchatGhost: Icon<[0, 0, 512, 512], 512, 512>;
declare const SnapchatSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Snapchat: Icon<[0, 0, 496, 512], 496, 512>;
declare const Soundcloud: Icon<[0, 0, 640, 512], 640, 512>;
declare const Sourcetree: Icon<[0, 0, 448, 512], 448, 512>;
declare const Speakap: Icon<[0, 0, 448, 512], 448, 512>;
declare const SpeakerDeck: Icon<[0, 0, 512, 512], 512, 512>;
declare const Spotify: Icon<[0, 0, 496, 512], 496, 512>;
declare const Squarespace: Icon<[0, 0, 512, 512], 512, 512>;
declare const StackExchange: Icon<[0, 0, 448, 512], 448, 512>;
declare const StackOverflow: Icon<[0, 0, 384, 512], 384, 512>;
declare const Stackpath: Icon<[0, 0, 448, 512], 448, 512>;
declare const Staylinked: Icon<[0, 0, 440, 512], 440, 512>;
declare const SteamSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const SteamSymbol: Icon<[0, 0, 448, 512], 448, 512>;
declare const Steam: Icon<[0, 0, 496, 512], 496, 512>;
declare const StickerMule: Icon<[0, 0, 576, 512], 576, 512>;
declare const Strava: Icon<[0, 0, 384, 512], 384, 512>;
declare const StripeS: Icon<[0, 0, 384, 512], 384, 512>;
declare const Stripe: Icon<[0, 0, 640, 512], 640, 512>;
declare const Studiovinari: Icon<[0, 0, 512, 512], 512, 512>;
declare const StumbleuponCircle: Icon<[0, 0, 496, 512], 496, 512>;
declare const Stumbleupon: Icon<[0, 0, 512, 512], 512, 512>;
declare const Superpowers: Icon<[0, 0, 448, 512], 448, 512>;
declare const Supple: Icon<[0, 0, 640, 512], 640, 512>;
declare const Suse: Icon<[0, 0, 640, 512], 640, 512>;
declare const Swift: Icon<[0, 0, 448, 512], 448, 512>;
declare const Symfony: Icon<[0, 0, 512, 512], 512, 512>;
declare const Teamspeak: Icon<[0, 0, 512, 512], 512, 512>;
declare const TelegramPlane: Icon<[0, 0, 448, 512], 448, 512>;
declare const Telegram: Icon<[0, 0, 496, 512], 496, 512>;
declare const TencentWeibo: Icon<[0, 0, 384, 512], 384, 512>;
declare const TheRedYeti: Icon<[0, 0, 512, 512], 512, 512>;
declare const Themeco: Icon<[0, 0, 448, 512], 448, 512>;
declare const Themeisle: Icon<[0, 0, 512, 512], 512, 512>;
declare const ThinkPeaks: Icon<[0, 0, 576, 512], 576, 512>;
declare const TradeFederation: Icon<[0, 0, 496, 512], 496, 512>;
declare const Trello: Icon<[0, 0, 448, 512], 448, 512>;
declare const Tripadvisor: Icon<[0, 0, 576, 512], 576, 512>;
declare const TumblrSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Tumblr: Icon<[0, 0, 320, 512], 320, 512>;
declare const Twitch: Icon<[0, 0, 512, 512], 512, 512>;
declare const TwitterSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Twitter: Icon<[0, 0, 512, 512], 512, 512>;
declare const Typo3: Icon<[0, 0, 448, 512], 448, 512>;
declare const Uber: Icon<[0, 0, 448, 512], 448, 512>;
declare const Ubuntu: Icon<[0, 0, 496, 512], 496, 512>;
declare const Uikit: Icon<[0, 0, 448, 512], 448, 512>;
declare const Umbraco: Icon<[0, 0, 510, 512], 510, 512>;
declare const Uniregistry: Icon<[0, 0, 384, 512], 384, 512>;
declare const Unity: Icon<[0, 0, 576, 512], 576, 512>;
declare const Untappd: Icon<[0, 0, 640, 512], 640, 512>;
declare const Ups: Icon<[0, 0, 384, 512], 384, 512>;
declare const Usb: Icon<[0, 0, 640, 512], 640, 512>;
declare const Usps: Icon<[0, 0, 576, 512], 576, 512>;
declare const Ussunnah: Icon<[0, 0, 512, 512], 512, 512>;
declare const Vaadin: Icon<[0, 0, 448, 512], 448, 512>;
declare const Viacoin: Icon<[0, 0, 384, 512], 384, 512>;
declare const ViadeoSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Viadeo: Icon<[0, 0, 448, 512], 448, 512>;
declare const Viber: Icon<[0, 0, 512, 512], 512, 512>;
declare const VimeoSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const VimeoV: Icon<[0, 0, 448, 512], 448, 512>;
declare const Vimeo: Icon<[0, 0, 448, 512], 448, 512>;
declare const Vine: Icon<[0, 0, 384, 512], 384, 512>;
declare const Vk: Icon<[0, 0, 576, 512], 576, 512>;
declare const Vnv: Icon<[0, 0, 640, 512], 640, 512>;
declare const Vuejs: Icon<[0, 0, 448, 512], 448, 512>;
declare const Waze: Icon<[0, 0, 512, 512], 512, 512>;
declare const Weebly: Icon<[0, 0, 512, 512], 512, 512>;
declare const Weibo: Icon<[0, 0, 512, 512], 512, 512>;
declare const Weixin: Icon<[0, 0, 576, 512], 576, 512>;
declare const WhatsappSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Whatsapp: Icon<[0, 0, 448, 512], 448, 512>;
declare const Whmcs: Icon<[0, 0, 448, 512], 448, 512>;
declare const WikipediaW: Icon<[0, 0, 640, 512], 640, 512>;
declare const Windows: Icon<[0, 0, 448, 512], 448, 512>;
declare const Wix: Icon<[0, 0, 640, 512], 640, 512>;
declare const WizardsOfTheCoast: Icon<[0, 0, 640, 512], 640, 512>;
declare const WolfPackBattalion: Icon<[0, 0, 512, 512], 512, 512>;
declare const WordpressSimple: Icon<[0, 0, 512, 512], 512, 512>;
declare const Wordpress: Icon<[0, 0, 512, 512], 512, 512>;
declare const Wpbeginner: Icon<[0, 0, 512, 512], 512, 512>;
declare const Wpexplorer: Icon<[0, 0, 512, 512], 512, 512>;
declare const Wpforms: Icon<[0, 0, 448, 512], 448, 512>;
declare const Wpressr: Icon<[0, 0, 496, 512], 496, 512>;
declare const Xbox: Icon<[0, 0, 512, 512], 512, 512>;
declare const XingSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Xing: Icon<[0, 0, 384, 512], 384, 512>;
declare const YCombinator: Icon<[0, 0, 448, 512], 448, 512>;
declare const Yahoo: Icon<[0, 0, 448, 512], 448, 512>;
declare const Yammer: Icon<[0, 0, 512, 512], 512, 512>;
declare const YandexInternational: Icon<[0, 0, 320, 512], 320, 512>;
declare const Yandex: Icon<[0, 0, 256, 512], 256, 512>;
declare const Yarn: Icon<[0, 0, 496, 512], 496, 512>;
declare const Yelp: Icon<[0, 0, 384, 512], 384, 512>;
declare const Yoast: Icon<[0, 0, 448, 512], 448, 512>;
declare const YoutubeSquare: Icon<[0, 0, 448, 512], 448, 512>;
declare const Youtube: Icon<[0, 0, 576, 512], 576, 512>;
declare const Zhihu: Icon<[0, 0, 640, 512], 640, 512>;

type Icons = {
    'accessible-icon': Icon<[0, 0, 448, 512], 448, 512>,
    'accusoft': Icon<[0, 0, 640, 512], 640, 512>,
    'acquisitions-incorporated': Icon<[0, 0, 384, 512], 384, 512>,
    'adn': Icon<[0, 0, 496, 512], 496, 512>,
    'adobe': Icon<[0, 0, 512, 512], 512, 512>,
    'adversal': Icon<[0, 0, 512, 512], 512, 512>,
    'affiliatetheme': Icon<[0, 0, 512, 512], 512, 512>,
    'airbnb': Icon<[0, 0, 448, 512], 448, 512>,
    'algolia': Icon<[0, 0, 448, 512], 448, 512>,
    'alipay': Icon<[0, 0, 448, 512], 448, 512>,
    'amazon-pay': Icon<[0, 0, 640, 512], 640, 512>,
    'amazon': Icon<[0, 0, 448, 512], 448, 512>,
    'amilia': Icon<[0, 0, 448, 512], 448, 512>,
    'android': Icon<[0, 0, 576, 512], 576, 512>,
    'angellist': Icon<[0, 0, 448, 512], 448, 512>,
    'angrycreative': Icon<[0, 0, 640, 512], 640, 512>,
    'angular': Icon<[0, 0, 448, 512], 448, 512>,
    'app-store-ios': Icon<[0, 0, 448, 512], 448, 512>,
    'app-store': Icon<[0, 0, 512, 512], 512, 512>,
    'apper': Icon<[0, 0, 640, 512], 640, 512>,
    'apple-pay': Icon<[0, 0, 640, 512], 640, 512>,
    'apple': Icon<[0, 0, 384, 512], 384, 512>,
    'artstation': Icon<[0, 0, 512, 512], 512, 512>,
    'asymmetrik': Icon<[0, 0, 576, 512], 576, 512>,
    'atlassian': Icon<[0, 0, 512, 512], 512, 512>,
    'audible': Icon<[0, 0, 640, 512], 640, 512>,
    'autoprefixer': Icon<[0, 0, 640, 512], 640, 512>,
    'avianex': Icon<[0, 0, 512, 512], 512, 512>,
    'aviato': Icon<[0, 0, 640, 512], 640, 512>,
    'aws': Icon<[0, 0, 640, 512], 640, 512>,
    'bandcamp': Icon<[0, 0, 496, 512], 496, 512>,
    'battle-net': Icon<[0, 0, 512, 512], 512, 512>,
    'behance-square': Icon<[0, 0, 448, 512], 448, 512>,
    'behance': Icon<[0, 0, 576, 512], 576, 512>,
    'bimobject': Icon<[0, 0, 448, 512], 448, 512>,
    'bitbucket': Icon<[0, 0, 512, 512], 512, 512>,
    'bitcoin': Icon<[0, 0, 512, 512], 512, 512>,
    'bity': Icon<[0, 0, 496, 512], 496, 512>,
    'black-tie': Icon<[0, 0, 448, 512], 448, 512>,
    'blackberry': Icon<[0, 0, 512, 512], 512, 512>,
    'blogger-b': Icon<[0, 0, 448, 512], 448, 512>,
    'blogger': Icon<[0, 0, 448, 512], 448, 512>,
    'bluetooth-b': Icon<[0, 0, 320, 512], 320, 512>,
    'bluetooth': Icon<[0, 0, 448, 512], 448, 512>,
    'bootstrap': Icon<[0, 0, 448, 512], 448, 512>,
    'btc': Icon<[0, 0, 384, 512], 384, 512>,
    'buffer': Icon<[0, 0, 448, 512], 448, 512>,
    'buromobelexperte': Icon<[0, 0, 448, 512], 448, 512>,
    'buy-n-large': Icon<[0, 0, 576, 512], 576, 512>,
    'buysellads': Icon<[0, 0, 448, 512], 448, 512>,
    'canadian-maple-leaf': Icon<[0, 0, 512, 512], 512, 512>,
    'cc-amazon-pay': Icon<[0, 0, 576, 512], 576, 512>,
    'cc-amex': Icon<[0, 0, 576, 512], 576, 512>,
    'cc-apple-pay': Icon<[0, 0, 576, 512], 576, 512>,
    'cc-diners-club': Icon<[0, 0, 576, 512], 576, 512>,
    'cc-discover': Icon<[0, 0, 576, 512], 576, 512>,
    'cc-jcb': Icon<[0, 0, 576, 512], 576, 512>,
    'cc-mastercard': Icon<[0, 0, 576, 512], 576, 512>,
    'cc-paypal': Icon<[0, 0, 576, 512], 576, 512>,
    'cc-stripe': Icon<[0, 0, 576, 512], 576, 512>,
    'cc-visa': Icon<[0, 0, 576, 512], 576, 512>,
    'centercode': Icon<[0, 0, 512, 512], 512, 512>,
    'centos': Icon<[0, 0, 448, 512], 448, 512>,
    'chrome': Icon<[0, 0, 496, 512], 496, 512>,
    'chromecast': Icon<[0, 0, 512, 512], 512, 512>,
    'cloudscale': Icon<[0, 0, 448, 512], 448, 512>,
    'cloudsmith': Icon<[0, 0, 332, 512], 332, 512>,
    'cloudversify': Icon<[0, 0, 616, 512], 616, 512>,
    'codepen': Icon<[0, 0, 512, 512], 512, 512>,
    'codiepie': Icon<[0, 0, 472, 512], 472, 512>,
    'confluence': Icon<[0, 0, 512, 512], 512, 512>,
    'connectdevelop': Icon<[0, 0, 576, 512], 576, 512>,
    'contao': Icon<[0, 0, 512, 512], 512, 512>,
    'cotton-bureau': Icon<[0, 0, 512, 512], 512, 512>,
    'cpanel': Icon<[0, 0, 640, 512], 640, 512>,
    'creative-commons-by': Icon<[0, 0, 496, 512], 496, 512>,
    'creative-commons-nc-eu': Icon<[0, 0, 496, 512], 496, 512>,
    'creative-commons-nc-jp': Icon<[0, 0, 496, 512], 496, 512>,
    'creative-commons-nc': Icon<[0, 0, 496, 512], 496, 512>,
    'creative-commons-nd': Icon<[0, 0, 496, 512], 496, 512>,
    'creative-commons-pd-alt': Icon<[0, 0, 496, 512], 496, 512>,
    'creative-commons-pd': Icon<[0, 0, 496, 512], 496, 512>,
    'creative-commons-remix': Icon<[0, 0, 496, 512], 496, 512>,
    'creative-commons-sa': Icon<[0, 0, 496, 512], 496, 512>,
    'creative-commons-sampling-plus': Icon<[0, 0, 496, 512], 496, 512>,
    'creative-commons-sampling': Icon<[0, 0, 496, 512], 496, 512>,
    'creative-commons-share': Icon<[0, 0, 496, 512], 496, 512>,
    'creative-commons-zero': Icon<[0, 0, 496, 512], 496, 512>,
    'creative-commons': Icon<[0, 0, 496, 512], 496, 512>,
    'critical-role': Icon<[0, 0, 448, 512], 448, 512>,
    'css3-alt': Icon<[0, 0, 384, 512], 384, 512>,
    'css3': Icon<[0, 0, 512, 512], 512, 512>,
    'cuttlefish': Icon<[0, 0, 440, 512], 440, 512>,
    'd-and-d-beyond': Icon<[0, 0, 640, 512], 640, 512>,
    'd-and-d': Icon<[0, 0, 576, 512], 576, 512>,
    'dailymotion': Icon<[0, 0, 448, 512], 448, 512>,
    'dashcube': Icon<[0, 0, 448, 512], 448, 512>,
    'delicious': Icon<[0, 0, 448, 512], 448, 512>,
    'deploydog': Icon<[0, 0, 512, 512], 512, 512>,
    'deskpro': Icon<[0, 0, 480, 512], 480, 512>,
    'dev': Icon<[0, 0, 448, 512], 448, 512>,
    'deviantart': Icon<[0, 0, 320, 512], 320, 512>,
    'dhl': Icon<[0, 0, 640, 512], 640, 512>,
    'diaspora': Icon<[0, 0, 512, 512], 512, 512>,
    'digg': Icon<[0, 0, 512, 512], 512, 512>,
    'digital-ocean': Icon<[0, 0, 512, 512], 512, 512>,
    'discord': Icon<[0, 0, 448, 512], 448, 512>,
    'discourse': Icon<[0, 0, 448, 512], 448, 512>,
    'dochub': Icon<[0, 0, 416, 512], 416, 512>,
    'docker': Icon<[0, 0, 640, 512], 640, 512>,
    'draft2digital': Icon<[0, 0, 480, 512], 480, 512>,
    'dribbble-square': Icon<[0, 0, 448, 512], 448, 512>,
    'dribbble': Icon<[0, 0, 512, 512], 512, 512>,
    'dropbox': Icon<[0, 0, 528, 512], 528, 512>,
    'drupal': Icon<[0, 0, 448, 512], 448, 512>,
    'dyalog': Icon<[0, 0, 416, 512], 416, 512>,
    'earlybirds': Icon<[0, 0, 480, 512], 480, 512>,
    'ebay': Icon<[0, 0, 640, 512], 640, 512>,
    'edge': Icon<[0, 0, 512, 512], 512, 512>,
    'elementor': Icon<[0, 0, 448, 512], 448, 512>,
    'ello': Icon<[0, 0, 496, 512], 496, 512>,
    'ember': Icon<[0, 0, 640, 512], 640, 512>,
    'empire': Icon<[0, 0, 496, 512], 496, 512>,
    'envira': Icon<[0, 0, 448, 512], 448, 512>,
    'erlang': Icon<[0, 0, 640, 512], 640, 512>,
    'ethereum': Icon<[0, 0, 320, 512], 320, 512>,
    'etsy': Icon<[0, 0, 384, 512], 384, 512>,
    'evernote': Icon<[0, 0, 384, 512], 384, 512>,
    'expeditedssl': Icon<[0, 0, 496, 512], 496, 512>,
    'facebook-f': Icon<[0, 0, 320, 512], 320, 512>,
    'facebook-messenger': Icon<[0, 0, 512, 512], 512, 512>,
    'facebook-square': Icon<[0, 0, 448, 512], 448, 512>,
    'facebook': Icon<[0, 0, 512, 512], 512, 512>,
    'fantasy-flight-games': Icon<[0, 0, 512, 512], 512, 512>,
    'fedex': Icon<[0, 0, 640, 512], 640, 512>,
    'fedora': Icon<[0, 0, 448, 512], 448, 512>,
    'figma': Icon<[0, 0, 384, 512], 384, 512>,
    'firefox-browser': Icon<[0, 0, 512, 512], 512, 512>,
    'firefox': Icon<[0, 0, 512, 512], 512, 512>,
    'first-order-alt': Icon<[0, 0, 496, 512], 496, 512>,
    'first-order': Icon<[0, 0, 448, 512], 448, 512>,
    'firstdraft': Icon<[0, 0, 384, 512], 384, 512>,
    'flickr': Icon<[0, 0, 448, 512], 448, 512>,
    'flipboard': Icon<[0, 0, 448, 512], 448, 512>,
    'fly': Icon<[0, 0, 384, 512], 384, 512>,
    'font-awesome-alt': Icon<[0, 0, 448, 512], 448, 512>,
    'font-awesome-flag': Icon<[0, 0, 448, 512], 448, 512>,
    'font-awesome-logo-full': Icon<[0, 0, 3992, 512], 3992, 512>,
    'font-awesome': Icon<[0, 0, 448, 512], 448, 512>,
    'fonticons-fi': Icon<[0, 0, 384, 512], 384, 512>,
    'fonticons': Icon<[0, 0, 448, 512], 448, 512>,
    'fort-awesome-alt': Icon<[0, 0, 512, 512], 512, 512>,
    'fort-awesome': Icon<[0, 0, 512, 512], 512, 512>,
    'forumbee': Icon<[0, 0, 448, 512], 448, 512>,
    'foursquare': Icon<[0, 0, 368, 512], 368, 512>,
    'free-code-camp': Icon<[0, 0, 576, 512], 576, 512>,
    'freebsd': Icon<[0, 0, 448, 512], 448, 512>,
    'fulcrum': Icon<[0, 0, 320, 512], 320, 512>,
    'galactic-republic': Icon<[0, 0, 496, 512], 496, 512>,
    'galactic-senate': Icon<[0, 0, 512, 512], 512, 512>,
    'get-pocket': Icon<[0, 0, 448, 512], 448, 512>,
    'gg-circle': Icon<[0, 0, 512, 512], 512, 512>,
    'gg': Icon<[0, 0, 512, 512], 512, 512>,
    'git-alt': Icon<[0, 0, 448, 512], 448, 512>,
    'git-square': Icon<[0, 0, 448, 512], 448, 512>,
    'git': Icon<[0, 0, 512, 512], 512, 512>,
    'github-alt': Icon<[0, 0, 480, 512], 480, 512>,
    'github-square': Icon<[0, 0, 448, 512], 448, 512>,
    'github': Icon<[0, 0, 496, 512], 496, 512>,
    'gitkraken': Icon<[0, 0, 592, 512], 592, 512>,
    'gitlab': Icon<[0, 0, 512, 512], 512, 512>,
    'gitter': Icon<[0, 0, 384, 512], 384, 512>,
    'glide-g': Icon<[0, 0, 448, 512], 448, 512>,
    'glide': Icon<[0, 0, 448, 512], 448, 512>,
    'gofore': Icon<[0, 0, 400, 512], 400, 512>,
    'goodreads-g': Icon<[0, 0, 384, 512], 384, 512>,
    'goodreads': Icon<[0, 0, 448, 512], 448, 512>,
    'google-drive': Icon<[0, 0, 512, 512], 512, 512>,
    'google-play': Icon<[0, 0, 512, 512], 512, 512>,
    'google-plus-g': Icon<[0, 0, 640, 512], 640, 512>,
    'google-plus-square': Icon<[0, 0, 448, 512], 448, 512>,
    'google-plus': Icon<[0, 0, 496, 512], 496, 512>,
    'google-wallet': Icon<[0, 0, 448, 512], 448, 512>,
    'google': Icon<[0, 0, 488, 512], 488, 512>,
    'gratipay': Icon<[0, 0, 496, 512], 496, 512>,
    'grav': Icon<[0, 0, 512, 512], 512, 512>,
    'gripfire': Icon<[0, 0, 384, 512], 384, 512>,
    'grunt': Icon<[0, 0, 384, 512], 384, 512>,
    'gulp': Icon<[0, 0, 256, 512], 256, 512>,
    'hacker-news-square': Icon<[0, 0, 448, 512], 448, 512>,
    'hacker-news': Icon<[0, 0, 448, 512], 448, 512>,
    'hackerrank': Icon<[0, 0, 512, 512], 512, 512>,
    'hips': Icon<[0, 0, 640, 512], 640, 512>,
    'hire-a-helper': Icon<[0, 0, 512, 512], 512, 512>,
    'hooli': Icon<[0, 0, 640, 512], 640, 512>,
    'hornbill': Icon<[0, 0, 512, 512], 512, 512>,
    'hotjar': Icon<[0, 0, 448, 512], 448, 512>,
    'houzz': Icon<[0, 0, 448, 512], 448, 512>,
    'html5': Icon<[0, 0, 384, 512], 384, 512>,
    'hubspot': Icon<[0, 0, 512, 512], 512, 512>,
    'ideal': Icon<[0, 0, 576, 512], 576, 512>,
    'imdb': Icon<[0, 0, 448, 512], 448, 512>,
    'instagram-square': Icon<[0, 0, 448, 512], 448, 512>,
    'instagram': Icon<[0, 0, 448, 512], 448, 512>,
    'intercom': Icon<[0, 0, 448, 512], 448, 512>,
    'internet-explorer': Icon<[0, 0, 512, 512], 512, 512>,
    'invision': Icon<[0, 0, 448, 512], 448, 512>,
    'ioxhost': Icon<[0, 0, 640, 512], 640, 512>,
    'itch-io': Icon<[0, 0, 512, 512], 512, 512>,
    'itunes-note': Icon<[0, 0, 384, 512], 384, 512>,
    'itunes': Icon<[0, 0, 448, 512], 448, 512>,
    'java': Icon<[0, 0, 384, 512], 384, 512>,
    'jedi-order': Icon<[0, 0, 448, 512], 448, 512>,
    'jenkins': Icon<[0, 0, 512, 512], 512, 512>,
    'jira': Icon<[0, 0, 496, 512], 496, 512>,
    'joget': Icon<[0, 0, 496, 512], 496, 512>,
    'joomla': Icon<[0, 0, 448, 512], 448, 512>,
    'js-square': Icon<[0, 0, 448, 512], 448, 512>,
    'js': Icon<[0, 0, 448, 512], 448, 512>,
    'jsfiddle': Icon<[0, 0, 576, 512], 576, 512>,
    'kaggle': Icon<[0, 0, 320, 512], 320, 512>,
    'keybase': Icon<[0, 0, 448, 512], 448, 512>,
    'keycdn': Icon<[0, 0, 512, 512], 512, 512>,
    'kickstarter-k': Icon<[0, 0, 384, 512], 384, 512>,
    'kickstarter': Icon<[0, 0, 448, 512], 448, 512>,
    'korvue': Icon<[0, 0, 446, 512], 446, 512>,
    'laravel': Icon<[0, 0, 512, 512], 512, 512>,
    'lastfm-square': Icon<[0, 0, 448, 512], 448, 512>,
    'lastfm': Icon<[0, 0, 512, 512], 512, 512>,
    'leanpub': Icon<[0, 0, 576, 512], 576, 512>,
    'less': Icon<[0, 0, 640, 512], 640, 512>,
    'line': Icon<[0, 0, 448, 512], 448, 512>,
    'linkedin-in': Icon<[0, 0, 448, 512], 448, 512>,
    'linkedin': Icon<[0, 0, 448, 512], 448, 512>,
    'linode': Icon<[0, 0, 448, 512], 448, 512>,
    'linux': Icon<[0, 0, 448, 512], 448, 512>,
    'lyft': Icon<[0, 0, 512, 512], 512, 512>,
    'magento': Icon<[0, 0, 448, 512], 448, 512>,
    'mailchimp': Icon<[0, 0, 448, 512], 448, 512>,
    'mandalorian': Icon<[0, 0, 448, 512], 448, 512>,
    'markdown': Icon<[0, 0, 640, 512], 640, 512>,
    'mastodon': Icon<[0, 0, 448, 512], 448, 512>,
    'maxcdn': Icon<[0, 0, 512, 512], 512, 512>,
    'mdb': Icon<[0, 0, 576, 512], 576, 512>,
    'medapps': Icon<[0, 0, 320, 512], 320, 512>,
    'medium-m': Icon<[0, 0, 512, 512], 512, 512>,
    'medium': Icon<[0, 0, 448, 512], 448, 512>,
    'medrt': Icon<[0, 0, 544, 512], 544, 512>,
    'meetup': Icon<[0, 0, 512, 512], 512, 512>,
    'megaport': Icon<[0, 0, 496, 512], 496, 512>,
    'mendeley': Icon<[0, 0, 640, 512], 640, 512>,
    'microblog': Icon<[0, 0, 448, 512], 448, 512>,
    'microsoft': Icon<[0, 0, 448, 512], 448, 512>,
    'mix': Icon<[0, 0, 448, 512], 448, 512>,
    'mixcloud': Icon<[0, 0, 640, 512], 640, 512>,
    'mixer': Icon<[0, 0, 512, 512], 512, 512>,
    'mizuni': Icon<[0, 0, 496, 512], 496, 512>,
    'modx': Icon<[0, 0, 448, 512], 448, 512>,
    'monero': Icon<[0, 0, 496, 512], 496, 512>,
    'napster': Icon<[0, 0, 496, 512], 496, 512>,
    'neos': Icon<[0, 0, 512, 512], 512, 512>,
    'nimblr': Icon<[0, 0, 384, 512], 384, 512>,
    'node-js': Icon<[0, 0, 448, 512], 448, 512>,
    'node': Icon<[0, 0, 640, 512], 640, 512>,
    'npm': Icon<[0, 0, 576, 512], 576, 512>,
    'ns8': Icon<[0, 0, 640, 512], 640, 512>,
    'nutritionix': Icon<[0, 0, 400, 512], 400, 512>,
    'odnoklassniki-square': Icon<[0, 0, 448, 512], 448, 512>,
    'odnoklassniki': Icon<[0, 0, 320, 512], 320, 512>,
    'old-republic': Icon<[0, 0, 496, 512], 496, 512>,
    'opencart': Icon<[0, 0, 640, 512], 640, 512>,
    'openid': Icon<[0, 0, 448, 512], 448, 512>,
    'opera': Icon<[0, 0, 496, 512], 496, 512>,
    'optin-monster': Icon<[0, 0, 576, 512], 576, 512>,
    'orcid': Icon<[0, 0, 512, 512], 512, 512>,
    'osi': Icon<[0, 0, 512, 512], 512, 512>,
    'page4': Icon<[0, 0, 496, 512], 496, 512>,
    'pagelines': Icon<[0, 0, 384, 512], 384, 512>,
    'palfed': Icon<[0, 0, 576, 512], 576, 512>,
    'patreon': Icon<[0, 0, 512, 512], 512, 512>,
    'paypal': Icon<[0, 0, 384, 512], 384, 512>,
    'penny-arcade': Icon<[0, 0, 640, 512], 640, 512>,
    'periscope': Icon<[0, 0, 448, 512], 448, 512>,
    'phabricator': Icon<[0, 0, 496, 512], 496, 512>,
    'phoenix-framework': Icon<[0, 0, 640, 512], 640, 512>,
    'phoenix-squadron': Icon<[0, 0, 512, 512], 512, 512>,
    'php': Icon<[0, 0, 640, 512], 640, 512>,
    'pied-piper-alt': Icon<[0, 0, 576, 512], 576, 512>,
    'pied-piper-hat': Icon<[0, 0, 640, 512], 640, 512>,
    'pied-piper-pp': Icon<[0, 0, 448, 512], 448, 512>,
    'pied-piper-square': Icon<[0, 0, 448, 512], 448, 512>,
    'pied-piper': Icon<[0, 0, 480, 512], 480, 512>,
    'pinterest-p': Icon<[0, 0, 384, 512], 384, 512>,
    'pinterest-square': Icon<[0, 0, 448, 512], 448, 512>,
    'pinterest': Icon<[0, 0, 496, 512], 496, 512>,
    'playstation': Icon<[0, 0, 576, 512], 576, 512>,
    'product-hunt': Icon<[0, 0, 512, 512], 512, 512>,
    'pushed': Icon<[0, 0, 432, 512], 432, 512>,
    'python': Icon<[0, 0, 448, 512], 448, 512>,
    'qq': Icon<[0, 0, 448, 512], 448, 512>,
    'quinscape': Icon<[0, 0, 512, 512], 512, 512>,
    'quora': Icon<[0, 0, 448, 512], 448, 512>,
    'r-project': Icon<[0, 0, 581, 512], 581, 512>,
    'raspberry-pi': Icon<[0, 0, 407, 512], 407, 512>,
    'ravelry': Icon<[0, 0, 512, 512], 512, 512>,
    'react': Icon<[0, 0, 512, 512], 512, 512>,
    'reacteurope': Icon<[0, 0, 576, 512], 576, 512>,
    'readme': Icon<[0, 0, 576, 512], 576, 512>,
    'rebel': Icon<[0, 0, 512, 512], 512, 512>,
    'red-river': Icon<[0, 0, 448, 512], 448, 512>,
    'reddit-alien': Icon<[0, 0, 512, 512], 512, 512>,
    'reddit-square': Icon<[0, 0, 448, 512], 448, 512>,
    'reddit': Icon<[0, 0, 512, 512], 512, 512>,
    'redhat': Icon<[0, 0, 512, 512], 512, 512>,
    'renren': Icon<[0, 0, 512, 512], 512, 512>,
    'replyd': Icon<[0, 0, 448, 512], 448, 512>,
    'researchgate': Icon<[0, 0, 448, 512], 448, 512>,
    'resolving': Icon<[0, 0, 496, 512], 496, 512>,
    'rev': Icon<[0, 0, 448, 512], 448, 512>,
    'rocketchat': Icon<[0, 0, 576, 512], 576, 512>,
    'rockrms': Icon<[0, 0, 496, 512], 496, 512>,
    'safari': Icon<[0, 0, 512, 512], 512, 512>,
    'salesforce': Icon<[0, 0, 640, 512], 640, 512>,
    'sass': Icon<[0, 0, 640, 512], 640, 512>,
    'schlix': Icon<[0, 0, 448, 512], 448, 512>,
    'scribd': Icon<[0, 0, 384, 512], 384, 512>,
    'searchengin': Icon<[0, 0, 460, 512], 460, 512>,
    'sellcast': Icon<[0, 0, 448, 512], 448, 512>,
    'sellsy': Icon<[0, 0, 640, 512], 640, 512>,
    'servicestack': Icon<[0, 0, 496, 512], 496, 512>,
    'shirtsinbulk': Icon<[0, 0, 448, 512], 448, 512>,
    'shopify': Icon<[0, 0, 448, 512], 448, 512>,
    'shopware': Icon<[0, 0, 512, 512], 512, 512>,
    'simplybuilt': Icon<[0, 0, 512, 512], 512, 512>,
    'sistrix': Icon<[0, 0, 448, 512], 448, 512>,
    'sith': Icon<[0, 0, 448, 512], 448, 512>,
    'sketch': Icon<[0, 0, 512, 512], 512, 512>,
    'skyatlas': Icon<[0, 0, 640, 512], 640, 512>,
    'skype': Icon<[0, 0, 448, 512], 448, 512>,
    'slack-hash': Icon<[0, 0, 448, 512], 448, 512>,
    'slack': Icon<[0, 0, 448, 512], 448, 512>,
    'slideshare': Icon<[0, 0, 512, 512], 512, 512>,
    'snapchat-ghost': Icon<[0, 0, 512, 512], 512, 512>,
    'snapchat-square': Icon<[0, 0, 448, 512], 448, 512>,
    'snapchat': Icon<[0, 0, 496, 512], 496, 512>,
    'soundcloud': Icon<[0, 0, 640, 512], 640, 512>,
    'sourcetree': Icon<[0, 0, 448, 512], 448, 512>,
    'speakap': Icon<[0, 0, 448, 512], 448, 512>,
    'speaker-deck': Icon<[0, 0, 512, 512], 512, 512>,
    'spotify': Icon<[0, 0, 496, 512], 496, 512>,
    'squarespace': Icon<[0, 0, 512, 512], 512, 512>,
    'stack-exchange': Icon<[0, 0, 448, 512], 448, 512>,
    'stack-overflow': Icon<[0, 0, 384, 512], 384, 512>,
    'stackpath': Icon<[0, 0, 448, 512], 448, 512>,
    'staylinked': Icon<[0, 0, 440, 512], 440, 512>,
    'steam-square': Icon<[0, 0, 448, 512], 448, 512>,
    'steam-symbol': Icon<[0, 0, 448, 512], 448, 512>,
    'steam': Icon<[0, 0, 496, 512], 496, 512>,
    'sticker-mule': Icon<[0, 0, 576, 512], 576, 512>,
    'strava': Icon<[0, 0, 384, 512], 384, 512>,
    'stripe-s': Icon<[0, 0, 384, 512], 384, 512>,
    'stripe': Icon<[0, 0, 640, 512], 640, 512>,
    'studiovinari': Icon<[0, 0, 512, 512], 512, 512>,
    'stumbleupon-circle': Icon<[0, 0, 496, 512], 496, 512>,
    'stumbleupon': Icon<[0, 0, 512, 512], 512, 512>,
    'superpowers': Icon<[0, 0, 448, 512], 448, 512>,
    'supple': Icon<[0, 0, 640, 512], 640, 512>,
    'suse': Icon<[0, 0, 640, 512], 640, 512>,
    'swift': Icon<[0, 0, 448, 512], 448, 512>,
    'symfony': Icon<[0, 0, 512, 512], 512, 512>,
    'teamspeak': Icon<[0, 0, 512, 512], 512, 512>,
    'telegram-plane': Icon<[0, 0, 448, 512], 448, 512>,
    'telegram': Icon<[0, 0, 496, 512], 496, 512>,
    'tencent-weibo': Icon<[0, 0, 384, 512], 384, 512>,
    'the-red-yeti': Icon<[0, 0, 512, 512], 512, 512>,
    'themeco': Icon<[0, 0, 448, 512], 448, 512>,
    'themeisle': Icon<[0, 0, 512, 512], 512, 512>,
    'think-peaks': Icon<[0, 0, 576, 512], 576, 512>,
    'trade-federation': Icon<[0, 0, 496, 512], 496, 512>,
    'trello': Icon<[0, 0, 448, 512], 448, 512>,
    'tripadvisor': Icon<[0, 0, 576, 512], 576, 512>,
    'tumblr-square': Icon<[0, 0, 448, 512], 448, 512>,
    'tumblr': Icon<[0, 0, 320, 512], 320, 512>,
    'twitch': Icon<[0, 0, 512, 512], 512, 512>,
    'twitter-square': Icon<[0, 0, 448, 512], 448, 512>,
    'twitter': Icon<[0, 0, 512, 512], 512, 512>,
    'typo3': Icon<[0, 0, 448, 512], 448, 512>,
    'uber': Icon<[0, 0, 448, 512], 448, 512>,
    'ubuntu': Icon<[0, 0, 496, 512], 496, 512>,
    'uikit': Icon<[0, 0, 448, 512], 448, 512>,
    'umbraco': Icon<[0, 0, 510, 512], 510, 512>,
    'uniregistry': Icon<[0, 0, 384, 512], 384, 512>,
    'unity': Icon<[0, 0, 576, 512], 576, 512>,
    'untappd': Icon<[0, 0, 640, 512], 640, 512>,
    'ups': Icon<[0, 0, 384, 512], 384, 512>,
    'usb': Icon<[0, 0, 640, 512], 640, 512>,
    'usps': Icon<[0, 0, 576, 512], 576, 512>,
    'ussunnah': Icon<[0, 0, 512, 512], 512, 512>,
    'vaadin': Icon<[0, 0, 448, 512], 448, 512>,
    'viacoin': Icon<[0, 0, 384, 512], 384, 512>,
    'viadeo-square': Icon<[0, 0, 448, 512], 448, 512>,
    'viadeo': Icon<[0, 0, 448, 512], 448, 512>,
    'viber': Icon<[0, 0, 512, 512], 512, 512>,
    'vimeo-square': Icon<[0, 0, 448, 512], 448, 512>,
    'vimeo-v': Icon<[0, 0, 448, 512], 448, 512>,
    'vimeo': Icon<[0, 0, 448, 512], 448, 512>,
    'vine': Icon<[0, 0, 384, 512], 384, 512>,
    'vk': Icon<[0, 0, 576, 512], 576, 512>,
    'vnv': Icon<[0, 0, 640, 512], 640, 512>,
    'vuejs': Icon<[0, 0, 448, 512], 448, 512>,
    'waze': Icon<[0, 0, 512, 512], 512, 512>,
    'weebly': Icon<[0, 0, 512, 512], 512, 512>,
    'weibo': Icon<[0, 0, 512, 512], 512, 512>,
    'weixin': Icon<[0, 0, 576, 512], 576, 512>,
    'whatsapp-square': Icon<[0, 0, 448, 512], 448, 512>,
    'whatsapp': Icon<[0, 0, 448, 512], 448, 512>,
    'whmcs': Icon<[0, 0, 448, 512], 448, 512>,
    'wikipedia-w': Icon<[0, 0, 640, 512], 640, 512>,
    'windows': Icon<[0, 0, 448, 512], 448, 512>,
    'wix': Icon<[0, 0, 640, 512], 640, 512>,
    'wizards-of-the-coast': Icon<[0, 0, 640, 512], 640, 512>,
    'wolf-pack-battalion': Icon<[0, 0, 512, 512], 512, 512>,
    'wordpress-simple': Icon<[0, 0, 512, 512], 512, 512>,
    'wordpress': Icon<[0, 0, 512, 512], 512, 512>,
    'wpbeginner': Icon<[0, 0, 512, 512], 512, 512>,
    'wpexplorer': Icon<[0, 0, 512, 512], 512, 512>,
    'wpforms': Icon<[0, 0, 448, 512], 448, 512>,
    'wpressr': Icon<[0, 0, 496, 512], 496, 512>,
    'xbox': Icon<[0, 0, 512, 512], 512, 512>,
    'xing-square': Icon<[0, 0, 448, 512], 448, 512>,
    'xing': Icon<[0, 0, 384, 512], 384, 512>,
    'y-combinator': Icon<[0, 0, 448, 512], 448, 512>,
    'yahoo': Icon<[0, 0, 448, 512], 448, 512>,
    'yammer': Icon<[0, 0, 512, 512], 512, 512>,
    'yandex-international': Icon<[0, 0, 320, 512], 320, 512>,
    'yandex': Icon<[0, 0, 256, 512], 256, 512>,
    'yarn': Icon<[0, 0, 496, 512], 496, 512>,
    'yelp': Icon<[0, 0, 384, 512], 384, 512>,
    'yoast': Icon<[0, 0, 448, 512], 448, 512>,
    'youtube-square': Icon<[0, 0, 448, 512], 448, 512>,
    'youtube': Icon<[0, 0, 576, 512], 576, 512>,
    'zhihu': Icon<[0, 0, 640, 512], 640, 512>
};

declare const icons: Icons;

export default icons;
export {
    AccessibleIcon,
    Accusoft,
    AcquisitionsIncorporated,
    Adn,
    Adobe,
    Adversal,
    Affiliatetheme,
    Airbnb,
    Algolia,
    Alipay,
    AmazonPay,
    Amazon,
    Amilia,
    Android,
    Angellist,
    Angrycreative,
    Angular,
    AppStoreIos,
    AppStore,
    Apper,
    ApplePay,
    Apple,
    Artstation,
    Asymmetrik,
    Atlassian,
    Audible,
    Autoprefixer,
    Avianex,
    Aviato,
    Aws,
    Bandcamp,
    BattleNet,
    BehanceSquare,
    Behance,
    Bimobject,
    Bitbucket,
    Bitcoin,
    Bity,
    BlackTie,
    Blackberry,
    BloggerB,
    Blogger,
    BluetoothB,
    Bluetooth,
    Bootstrap,
    Btc,
    Buffer,
    Buromobelexperte,
    BuyNLarge,
    Buysellads,
    CanadianMapleLeaf,
    CcAmazonPay,
    CcAmex,
    CcApplePay,
    CcDinersClub,
    CcDiscover,
    CcJcb,
    CcMastercard,
    CcPaypal,
    CcStripe,
    CcVisa,
    Centercode,
    Centos,
    Chrome,
    Chromecast,
    Cloudscale,
    Cloudsmith,
    Cloudversify,
    Codepen,
    Codiepie,
    Confluence,
    Connectdevelop,
    Contao,
    CottonBureau,
    Cpanel,
    CreativeCommonsBy,
    CreativeCommonsNcEu,
    CreativeCommonsNcJp,
    CreativeCommonsNc,
    CreativeCommonsNd,
    CreativeCommonsPdAlt,
    CreativeCommonsPd,
    CreativeCommonsRemix,
    CreativeCommonsSa,
    CreativeCommonsSamplingPlus,
    CreativeCommonsSampling,
    CreativeCommonsShare,
    CreativeCommonsZero,
    CreativeCommons,
    CriticalRole,
    Css3Alt,
    Css3,
    Cuttlefish,
    DAndDBeyond,
    DAndD,
    Dailymotion,
    Dashcube,
    Delicious,
    Deploydog,
    Deskpro,
    Dev,
    Deviantart,
    Dhl,
    Diaspora,
    Digg,
    DigitalOcean,
    Discord,
    Discourse,
    Dochub,
    Docker,
    Draft2digital,
    DribbbleSquare,
    Dribbble,
    Dropbox,
    Drupal,
    Dyalog,
    Earlybirds,
    Ebay,
    Edge,
    Elementor,
    Ello,
    Ember,
    Empire,
    Envira,
    Erlang,
    Ethereum,
    Etsy,
    Evernote,
    Expeditedssl,
    FacebookF,
    FacebookMessenger,
    FacebookSquare,
    Facebook,
    FantasyFlightGames,
    Fedex,
    Fedora,
    Figma,
    FirefoxBrowser,
    Firefox,
    FirstOrderAlt,
    FirstOrder,
    Firstdraft,
    Flickr,
    Flipboard,
    Fly,
    FontAwesomeAlt,
    FontAwesomeFlag,
    FontAwesomeLogoFull,
    FontAwesome,
    FonticonsFi,
    Fonticons,
    FortAwesomeAlt,
    FortAwesome,
    Forumbee,
    Foursquare,
    FreeCodeCamp,
    Freebsd,
    Fulcrum,
    GalacticRepublic,
    GalacticSenate,
    GetPocket,
    GgCircle,
    Gg,
    GitAlt,
    GitSquare,
    Git,
    GithubAlt,
    GithubSquare,
    Github,
    Gitkraken,
    Gitlab,
    Gitter,
    GlideG,
    Glide,
    Gofore,
    GoodreadsG,
    Goodreads,
    GoogleDrive,
    GooglePlay,
    GooglePlusG,
    GooglePlusSquare,
    GooglePlus,
    GoogleWallet,
    Google,
    Gratipay,
    Grav,
    Gripfire,
    Grunt,
    Gulp,
    HackerNewsSquare,
    HackerNews,
    Hackerrank,
    Hips,
    HireAHelper,
    Hooli,
    Hornbill,
    Hotjar,
    Houzz,
    Html5,
    Hubspot,
    Ideal,
    Imdb,
    InstagramSquare,
    Instagram,
    Intercom,
    InternetExplorer,
    Invision,
    Ioxhost,
    ItchIo,
    ItunesNote,
    Itunes,
    Java,
    JediOrder,
    Jenkins,
    Jira,
    Joget,
    Joomla,
    JsSquare,
    Js,
    Jsfiddle,
    Kaggle,
    Keybase,
    Keycdn,
    KickstarterK,
    Kickstarter,
    Korvue,
    Laravel,
    LastfmSquare,
    Lastfm,
    Leanpub,
    Less,
    Line,
    LinkedinIn,
    Linkedin,
    Linode,
    Linux,
    Lyft,
    Magento,
    Mailchimp,
    Mandalorian,
    Markdown,
    Mastodon,
    Maxcdn,
    Mdb,
    Medapps,
    MediumM,
    Medium,
    Medrt,
    Meetup,
    Megaport,
    Mendeley,
    Microblog,
    Microsoft,
    Mix,
    Mixcloud,
    Mixer,
    Mizuni,
    Modx,
    Monero,
    Napster,
    Neos,
    Nimblr,
    NodeJs,
    Node,
    Npm,
    Ns8,
    Nutritionix,
    OdnoklassnikiSquare,
    Odnoklassniki,
    OldRepublic,
    Opencart,
    Openid,
    Opera,
    OptinMonster,
    Orcid,
    Osi,
    Page4,
    Pagelines,
    Palfed,
    Patreon,
    Paypal,
    PennyArcade,
    Periscope,
    Phabricator,
    PhoenixFramework,
    PhoenixSquadron,
    Php,
    PiedPiperAlt,
    PiedPiperHat,
    PiedPiperPp,
    PiedPiperSquare,
    PiedPiper,
    PinterestP,
    PinterestSquare,
    Pinterest,
    Playstation,
    ProductHunt,
    Pushed,
    Python,
    Qq,
    Quinscape,
    Quora,
    RProject,
    RaspberryPi,
    Ravelry,
    React,
    Reacteurope,
    Readme,
    Rebel,
    RedRiver,
    RedditAlien,
    RedditSquare,
    Reddit,
    Redhat,
    Renren,
    Replyd,
    Researchgate,
    Resolving,
    Rev,
    Rocketchat,
    Rockrms,
    Safari,
    Salesforce,
    Sass,
    Schlix,
    Scribd,
    Searchengin,
    Sellcast,
    Sellsy,
    Servicestack,
    Shirtsinbulk,
    Shopify,
    Shopware,
    Simplybuilt,
    Sistrix,
    Sith,
    Sketch,
    Skyatlas,
    Skype,
    SlackHash,
    Slack,
    Slideshare,
    SnapchatGhost,
    SnapchatSquare,
    Snapchat,
    Soundcloud,
    Sourcetree,
    Speakap,
    SpeakerDeck,
    Spotify,
    Squarespace,
    StackExchange,
    StackOverflow,
    Stackpath,
    Staylinked,
    SteamSquare,
    SteamSymbol,
    Steam,
    StickerMule,
    Strava,
    StripeS,
    Stripe,
    Studiovinari,
    StumbleuponCircle,
    Stumbleupon,
    Superpowers,
    Supple,
    Suse,
    Swift,
    Symfony,
    Teamspeak,
    TelegramPlane,
    Telegram,
    TencentWeibo,
    TheRedYeti,
    Themeco,
    Themeisle,
    ThinkPeaks,
    TradeFederation,
    Trello,
    Tripadvisor,
    TumblrSquare,
    Tumblr,
    Twitch,
    TwitterSquare,
    Twitter,
    Typo3,
    Uber,
    Ubuntu,
    Uikit,
    Umbraco,
    Uniregistry,
    Unity,
    Untappd,
    Ups,
    Usb,
    Usps,
    Ussunnah,
    Vaadin,
    Viacoin,
    ViadeoSquare,
    Viadeo,
    Viber,
    VimeoSquare,
    VimeoV,
    Vimeo,
    Vine,
    Vk,
    Vnv,
    Vuejs,
    Waze,
    Weebly,
    Weibo,
    Weixin,
    WhatsappSquare,
    Whatsapp,
    Whmcs,
    WikipediaW,
    Windows,
    Wix,
    WizardsOfTheCoast,
    WolfPackBattalion,
    WordpressSimple,
    Wordpress,
    Wpbeginner,
    Wpexplorer,
    Wpforms,
    Wpressr,
    Xbox,
    XingSquare,
    Xing,
    YCombinator,
    Yahoo,
    Yammer,
    YandexInternational,
    Yandex,
    Yarn,
    Yelp,
    Yoast,
    YoutubeSquare,
    Youtube,
    Zhihu
};
